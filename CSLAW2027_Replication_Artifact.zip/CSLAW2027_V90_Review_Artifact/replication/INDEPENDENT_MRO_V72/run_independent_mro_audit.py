#!/usr/bin/env python3
"""Independent source-bounded 2026-10-19 MRO five-supplier audit.
IMPORTANT: This script verifies calculations against manually transcribed PRIMARY DOCUMENT
observations and cannot independently authenticate remote PDFs or certify complete revisions.
"""
from pathlib import Path
import csv, json, sqlite3, hashlib

OUT=Path(__file__).resolve().parent
DATE='2026-10-19'
CAT=set(range(1,16))
S=[
('Fastenal Co.','MA 758 2500000414',set(range(1,16)),set(range(1,16)),set(range(1,16)),'https://www.naspovaluepoint.org/suppliers/fastenal-co/','https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/Fastenal%20Co./Fastenal%20Master%20Agreement.pdf','PDF p.36, Exhibit 1'),
('Lawson Products, Inc.','MA 758 2500000412',set(range(1,15)),set(range(1,15)),set(range(1,15)),'https://www.naspovaluepoint.org/suppliers/lawson-products-inc/','https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/Lawson%20Products,%20Inc.(1)/Lawson%20Master%20Agreement.pdf','PDF p.36, Exhibit 1'),
('MSC Industrial Supply','MA 758 2500000411',set(range(1,16)),set(range(1,16)),set(range(1,16)),'https://www.naspovaluepoint.org/suppliers/msc-industrial-direct-co-dba-msc-industrial-supply/','https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/MSC%20Industrial%20Direct%20Co.,%20DBA%20MSC%20Industrial%20Supply/MSC%20Master%20Agreement.pdf','PDF p.36, Exhibit 1'),
('Global Industrial','MA 758 2500000416',set(range(1,16)),set(range(1,16)),set(range(1,16)),'https://www.naspovaluepoint.org/suppliers/global-equipment-co-inc-dba-global-industrial/','https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/Global%20Equipment%20Company%20Inc.%20DBA%20Global%20Industrial/Global%20Master%20Agreement.pdf','PDF p.31, Exhibit 1'),
('HD Supply','MA 758 2500000415',{1,6,8,15},{1,15},{1,6,8,15},'https://www.naspovaluepoint.org/suppliers/hd-supply-inc-dba-hd-supply-facilities-maintenance-ltd/','https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/HD%20Supply,%20Inc.%20DBA%20HD%20Supply%20Facilities%20Maintenance,%20LTD/HD%20Supply%20Master%20Agreement.pdf','PDF p.34 original Exhibit 1; vendor-hosted Addendum 1 PDF pp.2,32')]
ADDENDUM='https://images.hdsupplysolutions.com/image/upload/v1734552888/MarketingAssets/onsite/HD-Supply-Signed-MA-758_2500000415-Addendum-1.pdf?iid=ba_all_aem_res_btm_naspo-contract'
RENEWAL='https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/HD%20Supply,%20Inc.%20DBA%20HD%20Supply%20Facilities%20Maintenance,%20LTD/HD%20Supply%20Renewal%201.pdf'
rows=[]
for name,ma,profile,initial,corrected,purl,murl,pages in S:
    for cat in range(1,16):
        rows.append(dict(supplier=name,master_id=ma,category=cat,profile_tag=int(cat in profile),original_exhibit=int(cat in initial),operative_addendum_exhibit=int(cat in corrected),snapshot_date=DATE,source_profile=purl,source_original_master=murl,source_page=pages,source_signed_addendum=ADDENDUM if name=='HD Supply' else '',source_renewal=RENEWAL if name=='HD Supply' else ''))
with (OUT/'INDEPENDENT_MRO_75_QUERY_CELLS.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
original_diff=[r for r in rows if r['profile_tag']!=r['original_exhibit']]
resolved_diff=[r for r in rows if r['profile_tag']!=r['operative_addendum_exhibit']]
assert len(S)==5 and len(rows)==75
assert {(r['supplier'],r['category']) for r in original_diff}=={('HD Supply',6),('HD Supply',8)}
assert not resolved_diff
assert sum(r['profile_tag'] for r in rows)==63
assert sum(r['original_exhibit'] for r in rows)==61
assert sum(r['operative_addendum_exhibit'] for r in rows)==63
cx=sqlite3.connect(':memory:')
cx.execute('create table checks (supplier text,category integer, profile integer,original integer,amended integer)')
cx.executemany('insert into checks values(?,?,?,?,?)',[(r['supplier'],r['category'],r['profile_tag'],r['original_exhibit'],r['operative_addendum_exhibit']) for r in rows])
assert cx.execute('select count(*) from checks where profile <> original').fetchone()[0]==2
assert cx.execute('select count(*) from checks where profile <> amended').fetchone()[0]==0
assert cx.execute('select sum(profile),sum(original),sum(amended) from checks').fetchone()==(63,61,63)
summary={'observation_date':DATE,'program':'NASPO Facilities MRO and Industrial Supplies, Kentucky-led MA 758 2500000411-0416 except 0413 Grainger','independent_suppliers':len(S),'candidate_queries':len(rows),'website_positive_cells':63,'original_master_positive_cells':61,'source_bounded_original_disagreements':[{'supplier':r['supplier'],'category':r['category']} for r in original_diff],'operative_correction_positive_cells':63,'disagreements_after_linking_signed_addendum':len(resolved_diff),'method':'manually sourced category membership; standard-library independent SQLite count cross-check','important_limits':['No prior preregistration or blind holdout: audit chosen during exploration','No current PDFs/HTML bytes bundled due environment network limitations; cite direct URLs and exact pages','Public NASPO documents list renewal but omit the vendor-hosted signed 2024 Addendum 1 from supplier page links inspected','Addendum signed Sept 30 and Oct 1 2024; no assumption of legal effect before execution','The test concerns master award categories, not any PA, item price, actual order or purchase authorization','No assertion that NASPO structured category display itself is incorrect','Checks do not independently authenticate remote PDFs or prove exhaustive amendment inventory']}
summary['data_csv_sha256']=hashlib.sha256((OUT/'INDEPENDENT_MRO_75_QUERY_CELLS.csv').read_bytes()).hexdigest()
(OUT/'INDEPENDENT_MRO_RESULT.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2)); print('PASS: Python and independent SQLite comparisons')
