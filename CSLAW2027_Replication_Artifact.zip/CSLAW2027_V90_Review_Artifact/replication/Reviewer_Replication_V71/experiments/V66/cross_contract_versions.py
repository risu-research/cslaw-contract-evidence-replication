#!/usr/bin/env python3
"""Auditable source-bounded test for three non-RADcube public contracts.

All contract labels are manual, narrow clause-presence judgments with government
PDF page anchors in official_contract_worlds.json. The hypothetical operation
ERASES the version/date key from a record; the source itself states the dates.
All calculations concern DOCUMENTED TEXTUAL STATES, not court judgments.
"""
from pathlib import Path
from itertools import product, combinations
import csv, json, sqlite3
ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'official_contract_worlds.json').read_text())['cases']

def verdict(vals):
    s=set(vals)
    return 'YES' if s=={True} else 'NO' if s=={False} else 'REVIEW'

def inspect_case(c):
    n=len(c['labels']); version_vectors={v['id']:tuple(v['values']) for v in c['versions']}
    assert len(version_vectors)==len(c['versions']) and len(version_vectors)>=2
    assert all(len(w)==n and all(x in (0,1) for x in w) for w in version_vectors.values())
    exact=set(version_vectors.values()); independent=set(product((0,1),repeat=n))
    assert exact.issubset(independent)
    # Assert source encoded values match directly observable stipulated characteristics.
    if c['id']=='ID_ALLSTEEL_PA_2023_2024':assert list(version_vectors.values())==[(0,0,0),(1,1,0),(1,1,1)]
    else: assert list(version_vectors.values())==[(0,0),(1,1)]
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE version_fact (instrument TEXT, version TEXT, claim TEXT, value INT, PRIMARY KEY(instrument,version,claim))')
    db.executemany('INSERT INTO version_fact VALUES (?,?,?,?)',[(c['id'],ver,c['labels'][i],vec[i]) for ver,vec in version_vectors.items() for i in range(n)])
    # SQL independently recovers the complete documented version vectors, keyed by version.
    reconstructed=set()
    for ver in version_vectors:
        got=dict(db.execute('SELECT claim, value FROM version_fact WHERE instrument=? AND version=?',(c['id'],ver)))
        reconstructed.add(tuple(got[label] for label in c['labels']))
    assert reconstructed==exact
    # Use actual SQL rather than python sum to check all version-specific category totals.
    sql_counts=sorted(row[0] for row in db.execute('SELECT SUM(value) FROM version_fact GROUP BY version'))
    assert sql_counts==sorted(sum(w) for w in exact)
    tested=extra=0
    examples=[]
    # Check ALL Boolean functions on all two-claim projections (3*16 for 3-field case).
    for i,j in combinations(range(n),2):
        eq=lambda w:w[i]==w[j]
        examples.append({'query':f'{c["labels"][i]} and {c["labels"][j]} have equal clause status','coherent':verdict(eq(w) for w in exact),'independent':verdict(eq(w) for w in independent)})
        for table in product((False,True),repeat=4):
            g=lambda w:table[2*w[i]+w[j]]
            tested+=1
            if verdict(g(w) for w in exact)!='REVIEW' and verdict(g(w) for w in independent)=='REVIEW':extra+=1
    return {
        'id':c['id'],'versions':list(version_vectors),'labels':c['labels'],
        'documented_vectors':{key:list(val) for key,val in version_vectors.items()},
        'documented_world_count':len(exact),'row_independent_world_count':len(independent),
        'unattested_mixed_world_count':len(independent-exact),
        'documented_possible_positive_counts':sorted({sum(v) for v in exact}),
        'independent_possible_positive_counts':sorted({sum(v) for v in independent}),
        'joint_status_examples':examples,
        'pair_truth_functions_tested':tested,'pair_truth_functions_newly_decisive':extra,
        'sql_crosscheck':sql_counts,'official_url':c['official_url'],
        'source_pages_1based':c['source_pages_1based'],
        'scope':'Only the explicitly coded contract clause/category text in officially posted versioned instruments. Version metadata erasure is a constructed input loss, not a claim of currently contested legal priority.'
    }

def main():
    result=[inspect_case(c) for c in DATA]
    summary={'case_count':len(result),'external_contracts':len(result),
             'case_local_source_vectors':sum(x['documented_world_count'] for x in result),
             'case_local_independent_vectors':sum(x['row_independent_world_count'] for x in result),
             'case_local_unattested_vectors':sum(x['unattested_mixed_world_count'] for x in result),
             'pair_truth_functions_checked':sum(x['pair_truth_functions_tested'] for x in result),
             'pair_truth_functions_newly_decisive':sum(x['pair_truth_functions_newly_decisive'] for x in result),
             'cases':result,
             'limitation':'Counts sum diagnostics over three independently modeled contracts, NOT supplier prevalence, observed ambiguous cases, or live procurement judgments.'}
    (ROOT/'results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with (ROOT/'source_world_results.csv').open('w',newline='',encoding='utf-8') as f:
        names=['id','documented_world_count','row_independent_world_count','unattested_mixed_world_count','pair_truth_functions_tested','pair_truth_functions_newly_decisive','official_url']
        w=csv.DictWriter(f,fieldnames=names);w.writeheader();w.writerows({k:c[k] for k in names} for c in result)
    print(f"PASS three official instruments; coherent {summary['case_local_source_vectors']} vs independent {summary['case_local_independent_vectors']}; mixed {summary['case_local_unattested_vectors']}; {summary['pair_truth_functions_newly_decisive']}/{summary['pair_truth_functions_checked']} indexed Boolean diagnostics; SQLite confirms all documented vectors")
    return summary
if __name__=='__main__':main()
