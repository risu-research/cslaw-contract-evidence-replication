import unittest
from cross_contract_versions import DATA,inspect_case,verdict

class ContractCoherenceTests(unittest.TestCase):
    def test_three_actual_instrument_ids(self):
        self.assertEqual({c['id'] for c in DATA},{'ID_ALLSTEEL_PA_2023_2024','WA_MILLERKNOLL_PA_21422','WA_LANDSCAPE_PA_15122'})
    def test_versions_source_limited(self):
        for c in DATA:
            r=inspect_case(c)
            with self.subTest(id=c['id']):
                self.assertGreater(r['row_independent_world_count'],r['documented_world_count'])
                self.assertEqual(r['unattested_mixed_world_count'],r['row_independent_world_count']-r['documented_world_count'])
    def test_allsteel_exact_lineage(self):
        c=next(c for c in DATA if c['id']=='ID_ALLSTEEL_PA_2023_2024')
        r=inspect_case(c)
        self.assertEqual([list(v['values']) for v in c['versions']],[[0,0,0],[1,1,0],[1,1,1]])
        self.assertEqual([r['documented_world_count'],r['row_independent_world_count'],r['unattested_mixed_world_count']],[3,8,5])
        self.assertEqual(r['documented_possible_positive_counts'],[0,2,3])
    def test_wa_joint_additions(self):
        for c in (c for c in DATA if c['jurisdiction']=='Washington'):
            r=inspect_case(c)
            with self.subTest(id=c['id']):
                self.assertEqual((r['documented_world_count'],r['row_independent_world_count'],r['unattested_mixed_world_count']),(2,4,2))
                self.assertEqual(r['documented_possible_positive_counts'],[0,2])
                self.assertEqual(r['joint_status_examples'][0]['coherent'],'YES')
                self.assertEqual(r['joint_status_examples'][0]['independent'],'REVIEW')
    def test_soundness_monotonicity(self):
        from itertools import product,combinations
        for c in DATA:
            n=len(c['labels']);exact={tuple(x['values']) for x in c['versions']}; independent=set(product((0,1),repeat=n))
            for i,j in combinations(range(n),2):
                for table in product((False,True),repeat=4):
                    q=lambda w:table[2*w[i]+w[j]]
                    if verdict(q(w) for w in independent)!='REVIEW':
                        self.assertEqual(verdict(q(w) for w in independent),verdict(q(w) for w in exact))
    def test_sql_matches_all_version_vectors(self):
        for c in DATA:
            r=inspect_case(c)
            self.assertEqual(r['sql_crosscheck'],sorted(sum(v['values']) for v in c['versions']))
    def test_no_outcome_claims(self):
        for c in DATA:
            self.assertIn('original bytes not locally archived',c['evidence_grade'])
            self.assertTrue(c['official_url'].startswith('https://'))
    def test_true_versions_only(self):
        for c in DATA:
            self.assertEqual(len({tuple(v['values']) for v in c['versions']}),len(c['versions']))
    def test_sources_nonblank(self):
        for c in DATA:
            self.assertTrue(c['source_pages_1based'])
    def test_positive_count_constraints(self):
        for c in DATA:
            r=inspect_case(c)
            self.assertLessEqual(set(r['documented_possible_positive_counts']),set(r['independent_possible_positive_counts']))
    def test_version_information_is_explicit(self):
        for c in DATA:
            if c['jurisdiction']=='Washington':
                self.assertIn('effective_',c['versions'][-1]['id'])
                self.assertIn('Signed',c['versions'][-1]['note'])
            else:
                self.assertIn('2024',c['versions'][-1]['note'])
    def test_known_version_fixes_every_clause(self):
        for c in DATA:
            for v in c['versions']:
                for k in v['values']:
                    self.assertNotEqual(verdict([bool(k)]),'REVIEW')
    def test_full_hypercube_has_no_spurious_states(self):
        from itertools import product
        for n in (2,3,4):
            all_worlds=set(product((0,1),repeat=n))
            self.assertEqual(len(all_worlds-all_worlds),0)

if __name__=='__main__':unittest.main()
