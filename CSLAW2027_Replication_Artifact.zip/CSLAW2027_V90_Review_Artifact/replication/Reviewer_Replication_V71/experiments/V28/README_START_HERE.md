# CSLAW 2027 V28 — Legal Query Determinacy

The **recommended manuscript** is `manuscript/CSLAW2027_V28_CORE_FIRST_APPENDIX.pdf` with matching `.tex` (15 main-text pages, references begin late on page 15, appendices after references; final submission preflight pending). `manuscript/CSLAW2027_V28_LEGAL_QUERY_DETERMINACY.pdf` retains an extended narrative, not the page-limited draft. `prior/` preserves V27. The intellectual contribution is *claim-specific legally operative distinctions*, not a new determinacy theorem or a novel algorithm.

## Replication

```bash
python src/claim_determinacy.py
python src/build_tables.py
python src/sql_counterpart.py
python -m unittest discover -s tests -v
```

Expected: 22 hypothetical worlds across five narrow source-grounded claim families, 22/22 SQLite matches and 19/19 Python test methods. These are not 22 independently observed cases or empirical accuracy estimates. `src/source_role_warrant.py` illustrates the **separate** source-role warrant decision. The public PDF contracts were read from original official host URLs but their bytes could not be archived locally in this run. URLs and clause/page locations are in `docs/V28_RESEARCH_AUDIT_KO.md`, with source refs in `src/claim_determinacy.py`.

## Regenerate LaTeX

Full integration: `python docs/build_v28_paper.py` (this regenerates the narrative from prior V27 and NEW_CORE_SECTION, and may overwrite small manual manuscript refinements). The core-first version is retained verbatim. Build either with two `pdflatex -interaction=nonstopmode -halt-on-error <name>.tex` passes in `manuscript/`.

## Cautions

- All legal-world scenarios are **stipulated, not actual purchases**.
- WA/SC were examined before rule encoding. This is a **new jurisdiction external document challenge**, not prospective double-blind holdout, not independent human annotation.
- Claim-specific YES/NO does **not** authorize an order or prove that all other procurement duties were met.
- SQL is a strong comparator; identical facts produce identical correct outputs.
- Information sufficiency depends on a fixed, controlling rule set and finite modeled domain; **source authority, operative version, and undiscovered amendments are separate**.
- Final source audit, typography and venue page-cap review are still required before submission.
