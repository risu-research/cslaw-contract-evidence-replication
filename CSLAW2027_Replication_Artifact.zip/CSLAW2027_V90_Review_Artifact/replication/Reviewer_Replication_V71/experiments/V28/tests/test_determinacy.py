import sys,unittest
from pathlib import Path
from itertools import combinations
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'src'))
from claim_determinacy import make_cases,counterexamples,certain,minimal_determining_sets,minimal_decision_certificates

class FiniteModelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.c={x.key:x for x in make_cases()}
 def test_washington_local_without_cua(self):
  c=self.c['WA_BUYER'];self.assertEqual(certain(c,{'buyer':'municipality'}),'UNKNOWN')
  self.assertEqual(certain(c,{'buyer':'municipality','cua_executed':True}),'YES')
  self.assertEqual(certain(c,{'buyer':'municipality','cua_executed':False}),'NO')
 def test_wa_state_does_not_require_cua(self):self.assertEqual(certain(self.c['WA_BUYER'],{'buyer':'state_agency'}),'YES')
 def test_wa_noneligible_does_not_need_cua(self):self.assertEqual(certain(self.c['WA_BUYER'],{'buyer':'unlisted_private_firm'}),'NO')
 def test_service_is_not_category(self):
  c=self.c['WA_ADDED_SERVICES'];self.assertEqual(certain(c,{'service':'installation'}),'NO')
  self.assertEqual(certain(c,{'service':'inventory_management'}),'YES')
 def test_sc_high_price_is_disqualifying_without_other_contract_field(self):
  c=self.c['SC_ITEM'];self.assertEqual(certain(c,{'unit_price':25000}),'NO')
  self.assertEqual(certain(c,{'unit_price':30000}),'NO')
 def test_sc_known_other_contract_exclusion_dominates(self):
  self.assertEqual(certain(self.c['SC_ITEM'],{'on_other_sc_term_contract':True}),'NO')
 def test_sc_low_price_not_enough(self):
  c=self.c['SC_ITEM'];self.assertEqual(certain(c,{'unit_price':24999}),'UNKNOWN')
  self.assertEqual(certain(c,{'unit_price':24999,'on_other_sc_term_contract':False}),'YES')
 def test_sc_threshold_exact(self):
  c=self.c['SC_ITEM'];self.assertFalse(c.q({'unit_price':25000,'on_other_sc_term_contract':False}))
  self.assertTrue(c.q({'unit_price':24999,'on_other_sc_term_contract':False}))
 def test_temporal_cutover(self):
  c=self.c['ID_TEMPORAL'];self.assertEqual(certain(c,{}),'UNKNOWN')
  self.assertEqual(certain(c,{'date':'2026-10-01'}),'YES')
  self.assertEqual(certain(c,{'date':'2026-09-30'}),'NO')
 def test_wi_no_exclusion_not_authorization(self):
  self.assertEqual(self.c['WI_CHANNEL'].claim,'application of a particular exclusion to municipality')
 def test_discriminating_counterexamples(self):
  expected={'WA_BUYER':{'buyer':7,'cua_executed':1},'WA_ADDED_SERVICES':{'service':3},
      'SC_ITEM':{'unit_price':2,'on_other_sc_term_contract':1},'ID_TEMPORAL':{'date':1},'WI_CHANNEL':{'channel':1}}
  for k,ab in expected.items():
   c=self.c[k]
   for field,v in ab.items():
    self.assertEqual(len(counterexamples(c,tuple(x for x in c.fields if x!=field))),v)
 def test_global_minimal(self):
  for c in self.c.values():
   for fields in minimal_determining_sets(c):
    self.assertEqual(counterexamples(c,fields),[])
    for f in fields:
     self.assertTrue(counterexamples(c,tuple(k for k in fields if k!=f)))
 def test_local_certificate_all_worlds(self):
  for c in self.c.values():
   for w in c.worlds:
    gold='YES' if c.q(w) else 'NO'
    for fields in minimal_decision_certificates(c,w):
     self.assertEqual(certain(c,{k:w[k] for k in fields}),gold)
     for f in fields:
      self.assertNotEqual(certain(c,{k:w[k] for k in fields if k!=f}),gold)
 def test_more_evidence_never_changes_decisive_answer(self):
  for c in self.c.values():
   for w in c.worlds:
    for n in range(len(c.fields)+1):
     for ks in combinations(c.fields,n):
      a=certain(c,{k:w[k] for k in ks})
      if a in ('YES','NO'):
       for x in c.fields:
        ext=dict((k,w[k]) for k in ks);ext[x]=w[x]
        self.assertEqual(certain(c,ext),a)
 def test_contradictory_observations_not_vacuously_true(self):
  self.assertEqual(certain(self.c['SC_ITEM'],{'unit_price':-100}),'INCONSISTENT')
 def test_full_view_decides_every_world(self):
  for c in self.c.values():
   for w in c.worlds:
    self.assertEqual(certain(c,{k:w[k] for k in c.fields}), 'YES' if c.q(w) else 'NO')

if __name__=='__main__':unittest.main()

class SourceRoleTests(unittest.TestCase):
 def test_same_text_different_source_role(self):
  from source_role_warrant import Record,can_warrant_executed_pa_scope as w
  self.assertEqual(w(Record('category_included','official_portal_summary',True)), 'UNKNOWN')
  self.assertEqual(w(Record('category_included','signed_pa',True)),'YES_ON_THIS_PA_CLAIM')
 def test_signed_but_not_operative(self):
  from source_role_warrant import Record,can_warrant_executed_pa_scope as w
  self.assertEqual(w(Record('category_included','signed_pa',False)),'UNKNOWN')

class AmendmentChainTests(unittest.TestCase):
 def test_amendment_alone_not_sufficient(self):
  from source_role_warrant import Record,can_warrant_executed_pa_scope as w
  self.assertEqual(w(Record('category_included','signed_amendment',True)), 'UNKNOWN')
  self.assertEqual(w(Record('category_included','signed_amendment',True,True)), 'YES_ON_THIS_PA_CLAIM')
