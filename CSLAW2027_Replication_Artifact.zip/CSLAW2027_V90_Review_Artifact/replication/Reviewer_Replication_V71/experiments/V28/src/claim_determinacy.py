"""Finite-model checks for source-bounded documentary legal claims.

Research artifact, not a legal eligibility tool.  The rules are manually
transcribed from signed PAs; each world is hypothetical, not an observed order.
We distinguish legal truth in a stipulated world from what a source-limited
observer can warrant. No new determinacy/hitting-set algorithm is claimed.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations, product
import json
from pathlib import Path
from typing import Callable, Iterable

@dataclass(frozen=True)
class Case:
    key: str
    jurisdiction: str
    claim: str
    fields: tuple[str, ...]
    worlds: tuple[dict, ...]
    source: str
    section: str
    note: str

    def q(self, w: dict) -> bool:
        """Narrow PA-defined proposition, conditional on PA's continued force."""
        if self.key == 'WA_BUYER':
            # WA PA 19922 sec 1.10, 4.1-4.3: agencies/HE directly,
            # other listed purchasers only if CUA executed.
            return w['buyer'] in ('state_agency','higher_ed') or (w['buyer']=='municipality' and w['cua_executed'])
        if self.key == 'WA_ADDED_SERVICES':
            # WA PA 19922 sec 3: installation, warehouse management,
            # disaster recovery excluded; inventory management retained.
            return w['service'] == 'inventory_management'
        if self.key == 'SC_ITEM':
            # SC PA 4400036060 p1 exclusion of goods on another SC
            # term contract & each individual item with unit cost >=25000.
            # This PA-scope claim presumes this class of items is otherwise
            # within the master scope and is not a purchase authorization.
            return (not w['on_other_sc_term_contract']) and w['unit_price'] < 25000
        if self.key == 'ID_TEMPORAL':
            # Idaho amendment 1 to PADD20256877 effective 2026-10-01,
            # removes PA category 1/12 exclusion. Query only category 1/12.
            return w['date'] >= '2026-10-01'
        if self.key == 'WI_CHANNEL':
            # Narrow WI category-exclusion proposition for municipality
            # sanitation chemicals, not affirmative procurement approval.
            return w['channel'] == 'non_WISBuy'
        raise ValueError(self.key)


def make_cases() -> tuple[Case, ...]:
    def grid(keys, domain):
        return tuple(dict(zip(keys, x)) for x in product(*(domain[k] for k in keys)))
    return (
        Case('WA_BUYER','WA','PA-level purchasing-entity eligibility',('buyer','cua_executed'),
             grid(('buyer','cua_executed'),{'buyer':('state_agency','higher_ed','municipality','unlisted_private_firm'), 'cua_executed':(False,True)}),
             'https://apps.des.wa.gov/contracting/19922%20Grainger%20NASPO%20PA.pdf', 'secs. 1.10, 4.1-4.3, pdf pp. 3,5',
             'CUA is a distinct relationship, not evidence of a purchase order.'),
        Case('WA_ADDED_SERVICES','WA','PA scope for named value-added service',('service',),
             ({'service':'installation'},{'service':'inventory_management'},{'service':'warehouse_management'},{'service':'disaster_recovery'}),
             'https://apps.des.wa.gov/contracting/19922%20Grainger%20NASPO%20PA.pdf','sec. 3, pdf p. 4',
             'Category 1-15 does not automatically include each value-added service.'),
        Case('SC_ITEM','SC','PA item-scope exclusions',('unit_price','on_other_sc_term_contract'),
             grid(('unit_price','on_other_sc_term_contract'),{'unit_price':(24999,25000,30000),'on_other_sc_term_contract':(False,True)}),
             'https://procurement.sc.gov/files/attach/Grainger_Final.pdf','p. 1 of 11, first scope page; clause 18 p. 6',
             'Assumes a product otherwise in master PA category, no other exception; price is per item.'),
        Case('ID_TEMPORAL','ID','PA category 1/12 inclusion',('date',),
             ({'date':'2026-09-30'},{'date':'2026-10-01'}),
             'https://purchasing.idaho.gov/wp-content/uploads/PADD20256877-Amendment-1.pdf', 'amendment 1 scope strikethrough, effective 2026-10-01',
             'Temporal claim assumes no independent suspension and proper documentary version.'),
        Case('WI_CHANNEL','WI','application of a particular exclusion to municipality',('channel',),
             ({'channel':'WISBuy'},{'channel':'non_WISBuy'}),
             'https://s3.us-west-2.amazonaws.com/naspovaluepoint/1734448345_State%20of%20Wisonsin%20Grainger%20PA.pdf','PA pp. 1-2, prior V27 clause coding',
             'Non-WISBuy means only that a named exclusion does not attach.'),
    )


def project(w: dict, attributes: tuple[str, ...]):
    return tuple((k, w[k]) for k in attributes)


def counterexamples(c: Case, attributes: tuple[str,...]):
    """Distinct legal-world pairs with identical visible projection and unequal Q."""
    return [(i,j) for i in range(len(c.worlds)) for j in range(i+1,len(c.worlds))
            if project(c.worlds[i],attributes)==project(c.worlds[j],attributes)
            and c.q(c.worlds[i])!=c.q(c.worlds[j])]


def certain(c: Case, evidence: dict) -> str:
    """Truth in ALL worlds consistent with stipulated observations.
    A real deployment must also establish governing rule source / operative version.
    """
    residual=[w for w in c.worlds if all(w.get(k)==v for k,v in evidence.items())]
    if not residual:
        return 'INCONSISTENT' # no possible world, never certify by vacuity
    truthset={c.q(w) for w in residual}
    return 'YES' if truthset == {True} else 'NO' if truthset == {False} else 'UNKNOWN'


def minimal_determining_sets(c: Case) -> list[tuple[str,...]]:
    """Inclusion-minimal globally sufficient feature sets in finite domain."""
    answers=[]
    for n in range(len(c.fields)+1):
        for cols in combinations(c.fields,n):
            if any(set(a).issubset(cols) for a in answers): continue
            if not counterexamples(c,cols): answers.append(cols)
    return answers


def minimal_decision_certificates(c: Case, world: dict) -> list[tuple[str,...]]:
    """Inclusion-minimal subset of known world fields fixing THIS claim answer."""
    answers=[]
    expected='YES' if c.q(world) else 'NO'
    for n in range(len(c.fields)+1):
        for cols in combinations(c.fields,n):
            if any(set(a).issubset(cols) for a in answers): continue
            if certain(c,{k:world[k] for k in cols}) == expected:
                answers.append(cols)
    return answers


def classify_ablation(c: Case):
    return {name: {'pairs':len(counterexamples(c,tuple(k for k in c.fields if k !=name))),
                   'example': [{'left':c.worlds[i],'right':c.worlds[j]}
                              for i,j in counterexamples(c,tuple(k for k in c.fields if k!=name))[:1]]}
            for name in c.fields}


def run():
    rows=[]
    for c in make_cases():
        determ=minimal_determining_sets(c)
        samples=[]
        for w in c.worlds:
            samples.append({'world':w,'truth':'YES' if c.q(w) else 'NO',
                    'certificates':[list(x) for x in minimal_decision_certificates(c,w)]})
        rows.append({'case':c.key,'source':c.source,'section':c.section,
          'claim':c.claim,'hypothetical_worlds':len(c.worlds),
          'minimal_global_views':[list(x) for x in determ],
          'empty_view':certain(c,{}),'single_field_ablation':classify_ablation(c),
          'worlds_and_minimal_certificates':samples,'note':c.note})
    return {'status':'hypothetical model-check evidence, manually encoded legal rules; not actual transactions',
            'new_jurisdictions':['WA','SC'], 'all_cases':rows}


if __name__=='__main__':
    result=run()
    target=Path(__file__).resolve().parent.parent/'results'/'V28_CERTIFICATE_AND_ABLATION.json'
    target.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print(target)
    for row in result['all_cases']:
        print(row['case'],row['hypothetical_worlds'],row['minimal_global_views'],{k:v['pairs'] for k,v in row['single_field_ablation'].items()})
