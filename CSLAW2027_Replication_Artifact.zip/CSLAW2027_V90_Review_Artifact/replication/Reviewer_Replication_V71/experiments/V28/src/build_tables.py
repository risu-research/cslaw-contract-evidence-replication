from claim_determinacy import make_cases,certain,minimal_determining_sets,minimal_decision_certificates,counterexamples
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]; c=make_cases()
with (ROOT/'results'/'CASE_SUMMARY.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,['case','jurisdiction','worlds','minimal_global_information','source','clause','one_attribute_pairs'])
 w.writeheader()
 for x in c:
  w.writerow({'case':x.key,'jurisdiction':x.jurisdiction,'worlds':len(x.worlds),
      'minimal_global_information':' | '.join('+'.join(z) for z in minimal_determining_sets(x)),
      'source':x.source,'clause':x.section,
      'one_attribute_pairs':'; '.join(f"{k}={len(counterexamples(x,tuple(z for z in x.fields if z!=k)))}" for k in x.fields)})
with (ROOT/'results'/'MINIMAL_DECISION_CERTIFICATES.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,['case','legal_world','narrow_pa_claim','minimal_decisive_certificate'])
 w.writeheader()
 for x in c:
  for world in x.worlds:
   w.writerow({'case':x.key,'legal_world':json.dumps(world,sort_keys=True),
      'narrow_pa_claim':'YES' if x.q(world) else 'NO',
      'minimal_decisive_certificate':' OR '.join('&'.join(f'{k}={world[k]}' for k in z) for z in minimal_decision_certificates(x,world))})
print('wrote two tables')
