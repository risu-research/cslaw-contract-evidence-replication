"""Equivalent SQL formulation. SQL is intentionally a strong comparator."""
from __future__ import annotations
import sqlite3
from claim_determinacy import make_cases

QUERIES={
 'WA_BUYER':'''SELECT CASE WHEN :buyer IN ('state_agency','higher_ed')
                   OR (:buyer='municipality' AND :cua_executed=1)
                   THEN 1 ELSE 0 END''',
 'WA_ADDED_SERVICES':'''SELECT CASE WHEN :service='inventory_management' THEN 1 ELSE 0 END''',
 'SC_ITEM':'''SELECT CASE WHEN :on_other_sc_term_contract=0 AND :unit_price<25000
                   THEN 1 ELSE 0 END''',
 'ID_TEMPORAL':'''SELECT CASE WHEN :date >= '2026-10-01' THEN 1 ELSE 0 END''',
 'WI_CHANNEL':'''SELECT CASE WHEN :channel='non_WISBuy' THEN 1 ELSE 0 END'''
}

def main():
    conn=sqlite3.connect(':memory:')
    mismatches=[]; total=0
    for c in make_cases():
        for w in c.worlds:
            q=conn.execute(QUERIES[c.key],w).fetchone()[0]
            total += 1
            if bool(q)!=c.q(w): mismatches.append((c.key,w,q,c.q(w)))
    conn.close()
    print({'worlds':total,'sql_disagreements':len(mismatches),'mismatches':mismatches})
    assert not mismatches

if __name__=='__main__':main()
