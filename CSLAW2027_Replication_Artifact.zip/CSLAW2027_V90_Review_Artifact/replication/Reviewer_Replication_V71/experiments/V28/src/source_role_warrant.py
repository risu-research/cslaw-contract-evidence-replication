"""Illustration of source authority as a separate, *evidentiary* predicate.

This is NOT a claim that source type alone renders an instrument legally operative:
signatures, effective dates, supersession and relevant conditions also matter.
"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class Record:
    text_claim: str
    role: str # 'official_portal_summary', 'signed_pa', 'signed_amendment'
    governing: bool # separately checked instrument authority and period
    base_pa_available: bool = False # amendments need the base chain too

def can_warrant_executed_pa_scope(record: Record):
    if record.text_claim != 'category_included':
        return 'UNKNOWN'
    if record.role == 'signed_pa' and record.governing:
        return 'YES_ON_THIS_PA_CLAIM'
    if record.role == 'signed_amendment' and record.governing and record.base_pa_available:
        return 'YES_ON_THIS_PA_CLAIM'
    return 'UNKNOWN'

if __name__=='__main__':
    for typ in ('official_portal_summary','signed_pa','signed_amendment'):
        print(typ,can_warrant_executed_pa_scope(Record('category_included',typ,True,True)))
