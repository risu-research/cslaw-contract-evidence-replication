import sys,unittest,itertools
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from scope_safe_proof import *
from ablation_audit import table
from independent_sql import compute
from master_lineage_audit import audit as lineage

class ClaimScopeTests(unittest.TestCase):
    def test_global_finds_indexed_signed_document(self):
        a=evaluate(CLAIMS['global_2025_bilateral_renewed_2028'])
        self.assertEqual(a.witness_ids,('FL_GLOBAL_RENEWAL_2026',))
    def test_grainger_no_signed_2026_document_in_corpus(self):
        self.assertEqual(evaluate(CLAIMS['grainger_2025_bilateral_renewed_2028']).status,'NOT_ESTABLISHED')
    def test_grainger_legal_state_never_inferred_false(self):
        self.assertNotIn('FALSE',evaluate(CLAIMS['grainger_2025_bilateral_renewed_2028']).status)
    def test_global_cannot_serve_as_grainger(self):
        c=CLAIMS['grainger_2025_bilateral_renewed_2028']
        self.assertEqual(evaluate(c,[next(r for r in RECORDS if r['id']=='FL_GLOBAL_RENEWAL_2026')]).witness_ids,())
    def test_program_only_wrongly_joins_global(self):
        self.assertEqual(unsafe_program_only(CLAIMS['grainger_2025_bilateral_renewed_2028']),('FL_GLOBAL_RENEWAL_2026',))
    def test_wrong_era_grainger_is_not_2025_witness(self):
        a=evaluate(CLAIMS['grainger_2025_bilateral_renewed_2028'])
        self.assertIn('FL_GRAINGER_OLD_AMENDMENT_2023',dict(a.rejected))
    def test_two_master_agreement_branches_under_same_state_id(self):
        a=lineage()
        self.assertEqual(len(a['distinct_master_contract_references']),2)
        self.assertEqual(len(a['spurious_join_pairs']),1)
    def test_old_grainger_renewal_recognized_only_old_era(self):
        self.assertEqual(evaluate(CLAIMS['grainger_2020_old_contract_2024']).witness_ids,('FL_GRAINGER_OLD_AMENDMENT_2023',))
    def test_county_summary_does_not_substitute_for_state_signature(self):
        self.assertEqual(evaluate(CLAIMS['grainger_2025_bilateral_renewed_2028'],[next(r for r in RECORDS if r['id']=='FL_LEE_2026_SUMMARY')]).witness_ids,())
    def test_kentucky_change_does_not_substitute_for_fl_sourcing(self):
        self.assertEqual(evaluate(CLAIMS['grainger_2025_dms_locally_adopted_sourcing']).witness_ids,())
    def test_strict_visual_check_does_not_credit_indexed_text(self):
        self.assertEqual(evaluate(CLAIMS['global_2025_strict_visual_renewal']).status,'NOT_ESTABLISHED')
    def test_visual_grainger_current_unknown(self):
        self.assertEqual(evaluate(CLAIMS['grainger_2025_strict_visual_renewal']).status,'NOT_ESTABLISHED')
    def test_vendor_scoped_noninterference_under_irrelevant_extra_records(self):
        c=CLAIMS['grainger_2025_bilateral_renewed_2028']
        base=evaluate(c,[r for r in RECORDS if r['vendor']==c.vendor]).witness_ids
        additions=[r for r in RECORDS if r['vendor']!=c.vendor]
        for n in range(len(additions)+1):
            for combo in itertools.combinations(additions,n):
                self.assertEqual(evaluate(c,[r for r in RECORDS if r['vendor']==c.vendor]+list(combo)).witness_ids,base)
    def test_document_not_available_prior_to_its_signature_date(self):
        q=replace(CLAIMS['global_2025_bilateral_renewed_2028'],as_of='2026-06-24')
        self.assertEqual(evaluate(q).status,'NOT_ESTABLISHED')
        q=replace(q,as_of='2026-06-25')
        self.assertEqual(evaluate(q).witness_ids,('FL_GLOBAL_RENEWAL_2026',))
    def test_metamorphic_all_attribute_ablations(self):
        audit=table()
        self.assertEqual(audit['field_combinations_checked'],127)
        g=next(x for x in audit['per_document_guard_failures'] if x['source_id']=='FL_GLOBAL_RENEWAL_2026')
        self.assertEqual(g['wrong_as_grainger_2025_if_fields_dropped'],['vendor'])
    def test_source_does_not_change_by_claim_request(self):
        for c in CLAIMS.values():
            r=evaluate(c)
            self.assertEqual(r.status,'WITNESS_PRESENT' if r.witness_ids else 'NOT_ESTABLISHED')
    def test_sql_parity(self):
        self.assertTrue(compute()['sql_python_parity'])
    def test_no_duplicate_ledger_ids(self):
        self.assertEqual(len({r['id'] for r in RECORDS}),len(RECORDS))
    def test_no_weak_proof_promoted_into_strong_proof(self):
        c=CLAIMS['global_2025_bilateral_renewed_2028']
        cv=CLAIMS['global_2025_strict_visual_renewal']
        self.assertEqual(evaluate(c).status,'WITNESS_PRESENT')
        self.assertEqual(evaluate(cv).status,'NOT_ESTABLISHED')
    def test_vendor_disambiguation_nonempty(self):
        self.assertTrue(all(r['vendor'] and r['contract_series'] for r in RECORDS))

if __name__=='__main__':unittest.main(verbosity=2)
