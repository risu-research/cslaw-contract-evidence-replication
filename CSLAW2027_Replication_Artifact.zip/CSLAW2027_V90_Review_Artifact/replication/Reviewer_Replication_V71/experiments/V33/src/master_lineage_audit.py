"""Observed branching master-PA lineage under one printed state procurement number."""
import json
from scope_safe_proof import ROOT,RECORDS

def audit():
    original=[r for r in RECORDS if r['program']=='FL-31160000-25-NASPO-ACS' and r['kind']=='bilateral_original_PA']
    amendment=[r for r in RECORDS if r['program']=='FL-31160000-25-NASPO-ACS' and r['kind']=='bilateral_renewal_amendment']
    direct=[(p['id'],a['id']) for p in original for a in amendment]
    vendor_safe=[(p['id'],a['id']) for p in original for a in amendment if p['vendor']==a['vendor']]
    roots={r['vendor']:r['referenced_kentucky_master'] for r in original}
    assert roots['Global Industrial Equipment Company Inc.']=='MA 758 2500000416'
    assert roots['W.W. Grainger, Inc.']=='MA 758 2500000413'
    assert len(direct)==2 and len(vendor_safe)==1
    return {'actual_original_PA_records':len(original),'observed_amendment_records':len(amendment),
            'program_only_join_pairs':direct,'program_plus_vendor_join_pairs':vendor_safe,
            'spurious_join_pairs':[p for p in direct if p not in vendor_safe],
            'distinct_master_contract_references':roots,
            'evidentiary_interpretation':'The same Florida ACS number denotes a multi-vendor program; different Florida PA instances refer to different Kentucky master agreements.',
            'not_measured':['No errors of any deployed state procurement system were observed','No court outcome or transaction legality inferred','No claimed Grainger 2026 bilateral renewal PDF was verified']}
if __name__=='__main__':
    out=ROOT/'results/V33_MASTER_LINEAGE_JOIN.json'
    out.write_text(json.dumps(audit(),indent=2,ensure_ascii=False)+'\n');print(out)
