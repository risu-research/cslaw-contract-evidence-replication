"""SQLite baseline independently expressing the scope-safe relation predicate."""
import json,sqlite3
from scope_safe_proof import CLAIMS,RECORDS,ROOT,evaluate

def compute():
    cx=sqlite3.connect(':memory:')
    cx.execute('CREATE TABLE evidence(id TEXT, program TEXT, series TEXT, vendor TEXT, relation TEXT, kind TEXT, topic TEXT, expires TEXT, doc_date TEXT, quality TEXT)')
    for r in RECORDS:
        cx.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?,?,?,?,?)',
          (r['id'],r['program'],r['contract_series'],r['vendor'],r['relation'],r['kind'],r['dimension'],r['stated_expires'],r['document_date'],r['proof_quality']))
    independent={}
    for name,claim in CLAIMS.items():
        rows=cx.execute('SELECT id FROM evidence WHERE program=? AND series=? AND vendor=? AND relation=? AND kind=? AND topic=? AND expires=? AND doc_date<=? AND quality IN (?,?,?,?)' +
                (' AND quality LIKE ?' if claim.evidence_level=='visual' else ''),
                (claim.program,claim.contract_series,claim.vendor,claim.relation,claim.required_kind,claim.dimension,claim.assertion,claim.as_of,
                 'official_pdf_text_docusign_dates_not_visually_rechecked', 'visually_checked_signed_original','V32_visually_checked_signed','official_pdf_indexed_text_date_not_verified') +
                 (('%visually_checked%',) if claim.evidence_level=='visual' else ())).fetchall()
        got=sorted(r[0] for r in rows)
        assert got==list(evaluate(claim).witness_ids),(name,got,evaluate(claim))
        independent[name]=got
    cx.close()
    return {'sql_python_parity':True,'comparisons':len(independent),'results':independent,
           'warning':'Same curated clause ledger and same rule meaning; SQL agreement is an implementation check, not external legal accuracy.'}

if __name__=='__main__':
    result=compute();out=ROOT/'results/V33_SQL_PARITY.json';out.write_text(json.dumps(result,indent=2)+'\n');print(out)
