"""Claim-scoped, fail-closed evaluation of documentary amendments.

This is a small formal-claim checker with hand-curated source records, NOT a legal
interpretation engine, signature verifier, or parser of external agreements.
Its novelty is not asserted. What is tested is whether scoped witness handling
prevents misleading joins and unsafe propagation in a real source collection.
"""
from __future__ import annotations
import dataclasses
import itertools
import json
from pathlib import Path
from typing import Iterable, Optional

ROOT = Path(__file__).resolve().parents[1]
RECORDS = json.loads((ROOT/'sources/V33_EVIDENCE_LEDGER.json').read_text())['records']

@dataclasses.dataclass(frozen=True)
class Claim:
    key: str
    program: str
    contract_series: str
    vendor: str
    relation: str
    dimension: str
    assertion: str
    required_kind: str
    evidence_level: str = 'text'    # text | visual, visual stricter
    as_of: str = '2026-10-18'       # queries concern documents available by this date

@dataclasses.dataclass(frozen=True)
class ProofResult:
    status: str  # WITNESS_PRESENT | NOT_ESTABLISHED (never NO)
    witness_ids: tuple[str,...]
    rejected: tuple[tuple[str,str], ...]

# Claim dimensions are not interchangeable: renew(term) != incorporate(sourcing).
# Entity identifiers include a vendor-specific instance, not merely shared DMS
# program numbering. There is intentionally no automatic master-to-state bridge.
def evaluate(claim:Claim, records:Iterable[dict]=RECORDS)->ProofResult:
    witnesses=[]
    rejected=[]
    for r in records:
        why=None
        if r['program']!=claim.program:why='program mismatch'
        elif r['contract_series']!=claim.contract_series:why='contract-generation mismatch'
        elif r['vendor']!=claim.vendor:why='vendor mismatch'
        elif r['relation']!=claim.relation:why='legal-relation mismatch'
        elif r['kind']!=claim.required_kind:why='document-role mismatch'
        elif claim.dimension!='term' or r['dimension']!='term':why='effect-topic mismatch'
        elif r['stated_expires']!=claim.assertion:why='asserted-effective-value mismatch'
        elif r['document_date'] > claim.as_of:why='document postdates query'
        elif claim.evidence_level=='visual' and not ('visually_checked' in r['proof_quality']):why='signature visual check missing'
        elif r['proof_quality'] not in ('official_pdf_text_docusign_dates_not_visually_rechecked','visually_checked_signed_original','V32_visually_checked_signed','official_pdf_indexed_text_date_not_verified'):why='not qualifying instrument evidence'
        if why:rejected.append((r['id'],why))
        else:witnesses.append(r['id'])
    return ProofResult('WITNESS_PRESENT' if witnesses else 'NOT_ESTABLISHED',tuple(sorted(witnesses)),tuple(rejected))

COMMON='FL-31160000-25-NASPO-ACS'
CLAIMS={
 'global_2025_bilateral_renewed_2028':Claim('global_2025_bilateral_renewed_2028',COMMON,'2025-FL-ACS','Global Industrial Equipment Company Inc.','FL-DMS-vendor','term','2028-08-31','bilateral_renewal_amendment'),
 'grainger_2025_bilateral_renewed_2028':Claim('grainger_2025_bilateral_renewed_2028',COMMON,'2025-FL-ACS','W.W. Grainger, Inc.','FL-DMS-vendor','term','2028-08-31','bilateral_renewal_amendment'),
 'grainger_2025_dms_locally_adopted_sourcing':Claim('grainger_2025_dms_locally_adopted_sourcing',COMMON,'2025-FL-ACS','W.W. Grainger, Inc.','FL-DMS-vendor','sourcing','2026-09-01','bilateral_sourcing_amendment'),
 'grainger_2020_old_contract_2024':Claim('grainger_2020_old_contract_2024','FL-31160000-20-NASPO-ACS','2020-FL-ACS','W.W. Grainger, Inc.','FL-DMS-vendor','term','2024-06-30','bilateral_renewal_amendment'),
 'grainger_2025_strict_visual_renewal':Claim('grainger_2025_strict_visual_renewal',COMMON,'2025-FL-ACS','W.W. Grainger, Inc.','FL-DMS-vendor','term','2028-08-31','bilateral_renewal_amendment','visual'),
 'global_2025_strict_visual_renewal':Claim('global_2025_strict_visual_renewal',COMMON,'2025-FL-ACS','Global Industrial Equipment Company Inc.','FL-DMS-vendor','term','2028-08-31','bilateral_renewal_amendment','visual'),
}

def unsafe_program_only(claim:Claim,records:Iterable[dict]=RECORDS)->tuple[str,...]:
    """Deliberately incorrect baseline: amendment + program ID + expiry only."""
    return tuple(sorted(r['id'] for r in records if r['program']==claim.program
                         and r['kind']=='bilateral_renewal_amendment'
                         and r['stated_expires']==claim.assertion))


def audit()->dict:
    rows=[]
    for k,claim in CLAIMS.items():
        right=evaluate(claim)
        wrong=unsafe_program_only(claim)
        rows.append({'claim':k,'program':claim.program,'vendor':claim.vendor,
                     'kind':claim.required_kind,'effect_topic':claim.dimension,'as_of':claim.as_of,
                     'query':'documentary_witness_presence',
                     'safe_status':right.status,'safe_witness_ids':list(right.witness_ids),
                     'program_only_baseline_witness_ids':list(wrong),
                     'program_only_unsafe_positive':bool(wrong and not right.witness_ids),
                     'non_witness_reasons':dict(right.rejected)})
    # A separate, intentionally short source-to-scope proof:
    global_doc=next(r for r in RECORDS if r['id']=='FL_GLOBAL_RENEWAL_2026')
    grainger_doc=next(r for r in RECORDS if r['id']=='FL_GRAINGER_PA_2024')
    assert global_doc['program']==grainger_doc['program']
    assert global_doc['vendor']!=grainger_doc['vendor']
    return {'evaluation_scope':'DOCUMENT WITNESS existence for scoped claim, NOT negative legal truth, not verified signature validity',
            'actual_2026_DMS_bilateral_renewal_doc_found':'Global Industrial, not W.W. Grainger',
            'shared_program_id_in_two_official_documents':global_doc['program'],
            'source_pair_vendor_collision':[global_doc['id'],grainger_doc['id']],
            'claim_audit':rows,
            'limitations':['2026 Global DMS signature dates in official PDF search extraction; visual signature reinspection blocked by source HTTP 403',
                           'absence of 2026 Grainger bilateral DMS instrument in inspected corpus does NOT prove no renewal exists',
                           'county report of Grainger term is a different evidentiary claim, not contradicted by failure to locate signed DMS amendment',
                           'vendor, generation, relation, topic, and document authority are mandatory; program ID alone is insufficient']}

if __name__=='__main__':
    p=ROOT/'results/V33_SCOPED_WITNESS_RESULTS.json';p.write_text(json.dumps(audit(),indent=2,ensure_ascii=False)+'\n');print(p)
