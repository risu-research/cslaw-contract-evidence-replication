"""Exact, finite field-elision audit of sourced contract records.

It checks which attribute checks must be omitted for *each actual document*
to be incorrectly accepted as a witness for a Grainger 2025 bilateral renewal.
This is not a classifier accuracy or jurisdictional error frequency result.
"""
from __future__ import annotations
import itertools,json
from pathlib import Path
from scope_safe_proof import RECORDS,CLAIMS,ROOT

FIELDS=('program','contract_series','vendor','relation','kind','dimension','stated_expires')
def signature(row):
    return {k:row[k] for k in FIELDS}
def asdict(q):
    return {'program':q.program,'contract_series':q.contract_series,'vendor':q.vendor,
            'relation':q.relation,'kind':q.required_kind,'dimension':q.dimension,'stated_expires':q.assertion}
def table():
    q=asdict(CLAIMS['grainger_2025_bilateral_renewed_2028'])
    data=[]
    for r in RECORDS:
        delta=tuple(k for k in FIELDS if q[k]!=r[k])
        data.append({'source_id':r['id'],'wrong_as_grainger_2025_if_fields_dropped':list(delta),
                     'num_fields_to_drop':len(delta),'program_only_join_accepts':r['program']==q['program']})
    # For every column subset exact observed collision witnesses.
    perturb=[]
    for n in range(len(FIELDS)+1):
        for kept in itertools.combinations(FIELDS,n):
            if not kept:continue
            witness=[r['id'] for r in RECORDS if all(r[k]==q[k] for k in kept)]
            if witness:
                perturb.append({'kept_fields':list(kept),'witness_ids':witness,'any_false':True})
    return {'reference_claim':'2025 FL DMS/Grainger bilateral renewal to 2028, signed instrument as described in original contract',
            'total_actual_source_documents':len(RECORDS),'field_combinations_checked':2**len(FIELDS)-1,
            'closest_spurious_record':min(data,key=lambda row:row['num_fields_to_drop']),
            'per_document_guard_failures':data,'nonempty_coarse_collisions':perturb,
            'scope':'descriptive exact projections of a tiny curated corpus; cannot estimate incidence in public contracting'}

if __name__=='__main__':
    out=ROOT/'results/V33_ATTRIBUTE_ABLATION.json'
    out.write_text(json.dumps(table(),ensure_ascii=False,indent=2)+'\n')
    print(out)
