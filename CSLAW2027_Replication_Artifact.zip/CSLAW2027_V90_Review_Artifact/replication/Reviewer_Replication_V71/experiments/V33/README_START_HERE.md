# CSLAW V33 – Scope-safe vendor-specific amendment evidence

Research date: 2026-10-18. Author manuscript working draft, not submission-ready and not legal advice.

## Main finding
The common Florida DMS procurement number `31160000-25-NASPO-ACS` occurs on two supplier-specific original participating addenda: Grainger identifies Kentucky master agreement `MA 758 2500000413`, Global Industrial identifies `MA 758 2500000416`. An official Florida DMS search-indexed June 2026 document separately amends the Global contract term until 2028. Joining that document to Grainger by the umbrella program number alone would attribute another supplier's signed amendment to Grainger. The documents do **not** establish that Grainger failed to renew, and the Global signature image could not be independently retrieved owing to the server's HTTP 403 response. See `docs/V33_RESEARCH_AUDIT_KO.md` for exact facts, legal limits and links.

## Contents
- `manuscript/CSLAW2027_V33_ScopeSafe_Updates_Working.pdf` and `.tex`: ACM journal format working paper (body <= 15 pages, references start p.16, appendix follows).
- `manuscript/V33_SCOPE_SAFE_UPDATES_APPENDIX.tex`: independent new study appendix.
- `src/scope_safe_proof.py`: claim-specific documentary witness checker. Missing evidence never evaluates to legal FALSE.
- `src/master_lineage_audit.py`: actual original-PA -> master and original-PA -> vendor-amendment joins.
- `src/ablation_audit.py`: 127 nonempty retained-field combinations on 8 hand-coded real records.
- `src/independent_sql.py`: independent SQL selection for 6 documentary witness claims.
- `tests/test_scope_safe.py`: 20 unit/metamorphic tests including time cut, wrong generation/vendor/role, noninterference and SQL parity.
- `results/*.json`: computed artifact results, not independent legal adjudication.
- `sources/V33_EVIDENCE_LEDGER.json`: URL, page, role, verification grade, unsupported claims for each of 8 records.
- `prior/V29_PROTOCOL_UNCHANGED.md`: preregistration preserved, SHA256 in `SHA256_MANIFEST.txt`.
- `prior/V32_BASELINE_RESEARCH.zip`: complete original V32 package.

## Reproduction
```
cd CSLAW_V33_SCOPE_SAFE_UPDATES_20261018
python src/scope_safe_proof.py
python src/master_lineage_audit.py
python src/ablation_audit.py
python src/independent_sql.py
python -m unittest discover -s tests -v
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error CSLAW2027_V33_ScopeSafe_Updates_Working.tex
pdflatex -interaction=nonstopmode -halt-on-error CSLAW2027_V33_ScopeSafe_Updates_Working.tex
```
No paid LLMs, external legal service, or internet access required for the saved, manually curated corpus.

## Interpretive limits
The archive holds URLs and source-specific transcriptions rather than binary copies of inaccessible official PDFs. All legal conclusions are bounded documentary assertions. `NOT_ESTABLISHED` does not mean nonexistence or invalidity. Primary source PDFs were not digitally authenticated. The March 2027 ACM CSLAW 15-page text limit may exclude front matter differently under the final template; final conference submission audit remains needed.
