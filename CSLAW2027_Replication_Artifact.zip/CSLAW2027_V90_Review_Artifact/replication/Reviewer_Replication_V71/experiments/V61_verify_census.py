#!/usr/bin/env python3
"""Current claim-bound census arithmetic; reruns only existing author-coded 560 ledger.
RADcube's five VAR classifications remain REVIEW rather than asserted legal negatives.
"""
import csv,json,collections,pathlib
p=pathlib.Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'V59/replication/source_input_560_V55_original.csv').open(newline='')))
assert len(rows)==560 and len(set((r['supplier_slug'],r['category']) for r in rows))==560
assert len({r['supplier_slug'] for r in rows})==56
rad=[r for r in rows if r['supplier_slug']=='radcube-llc']
assert len(rad)==10 and all(int(r['web_yes'])==1 for r in rad)
assert len([r for r in rad if r['category'].startswith('VAR ')])==5
assert all(r['signed_yes']=='0' for r in rad if r['category'].startswith('VAR ')) # historical coding only
other=[r for r in rows if r['supplier_slug']!='radcube-llc']
assert len(other)==550 and len({r['supplier_slug'] for r in other})==55
web=sum(int(r['web_yes']) for r in other)
signed=sum(int(r['signed_yes']) for r in other)
wo=sum(r['web_yes']=='1' and r['signed_yes']=='0' for r in other)
so=sum(r['web_yes']=='0' and r['signed_yes']=='1' for r in other)
assert (web,signed,wo,so)==(308,316,1,9)
assert len({r['supplier_slug'] for r in other if r['web_yes']!=r['signed_yes']})==5
url=list(csv.DictReader((p/'V55/RADcube_version_status.csv').open(newline='')))
assert len(url)==10
from collections import Counter
st=Counter(r['status_within_two_inspected_B_schedules'] for r in url)
assert st['YES']==5 and st['REVIEW']==5,st
assert all(r['five_category_B']==r['ten_category_B']=='1' for r in url if r['category'].startswith('DSP '))
assert all(r['five_category_B']=='0' and r['ten_category_B']=='1' for r in url if r['category'].startswith('VAR '))
assert sum(int(r['web_yes']) for r in rows)==318
five=sum(int(r['signed_yes']) for r in rows)
assert five==321
summary={
 'frame_total':560,'suppliers_total':56,'web_positive_total':318,'settled_cells':555,
 'radcube_review_cells':5,'uncontested_outside_radcube':550,
 'without_radcube':{'suppliers':55,'cells':550,'web_positives':web,'schedule_positives':signed,
                    'website_only':wo,'schedule_only':so,'differences':wo+so},
 'with_radcube_historical_five_B':{'schedule_positives':five,'differences':15},
 'with_radcube_ten_B':{'schedule_positives':five+5,'differences':10},
 'interpretation':'Coded source-display distinctions, not independent reinspection, later-amendment completeness or purchase legality'
}
(p/'V61_census_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
