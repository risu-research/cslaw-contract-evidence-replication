See the archive root `REVIEWER_EVIDENCE_MAP.md` for the ten original page and PDF locators.
