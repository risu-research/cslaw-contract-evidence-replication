#!/usr/bin/env python3
"""Finite, clause-specific counterexamples from cited public Grainger PAs.
This checks stipulated legal-clause models, not actual transactions or legal truth.
Run: python3 replication/verify_loss_witnesses.py
No external packages. Results are deterministic; the source text is cited in source_index.
"""
import json, csv, itertools, pathlib, sqlite3
ROOT=pathlib.Path(__file__).resolve().parent

SOURCES={
 'WA': {'instrument':'Washington-Grainger PA 19922', 'section':'4.3', 'page':'PDF p.5',
        'url':'https://apps.des.wa.gov/contracting/19922%20Grainger%20NASPO%20PA.pdf'},
 'SC': {'instrument':'South Carolina-Grainger PA 4400036060', 'section':'Exclusions', 'page':'PDF p.1',
        'url':'https://procurement.sc.gov/files/attach/Grainger_Final.pdf'},
 'ID': {'instrument':'Idaho-Grainger PADD20256877 Amendment 1', 'section':'Scope deletion / effective date', 'page':'PDF pp.1-2',
        'url':'https://purchasing.idaho.gov/wp-content/uploads/PADD20256877-Amendment-1.pdf'},
}

def answer(case, world):
    """Boolean answer to the NAMED CLAUSE question, not approval of an order."""
    if case=='WA':
        assert world['buyer_class']=='municipality'
        return bool(world['cua_executed'])  # meets section 4.3's CUA condition
    if case=='SC':
        return world['unit_price_usd']<25000 and not world['other_sc_term_contract']
    if case=='ID':
        assert world['category']==1
        return world['legal_date']<'2026-10-01'  # specific category exclusion still applies
    raise KeyError(case)

# Every pair shares supplier, participating addendum, buyer context and a
# contract-specific narrowed legal question. Each differs only in the field
# indicated. All purchase actions are hypothetical and unobserved.
CASES={
 'WA': {'question':'Is the section 4.3 CUA condition satisfied for this municipality?',
        'fixed':{'supplier':'Grainger','pa':'WA-19922','buyer_class':'municipality','category':1,'legal_date':'2026-09-30'},
        'varying_field':'cua_executed', 'values':[False, True],
        'projection':['supplier','pa','buyer_class','category','legal_date'],
        'answer_names':['NO','YES']},
 'SC': {'question':'Does the item pass the PA price and other-term-contract exclusions?',
        'fixed':{'supplier':'Grainger','pa':'SC-4400036060','buyer_class':'state agency','category':3,'other_sc_term_contract':False,'legal_date':'2026-09-30'},
        'varying_field':'unit_price_usd', 'values':[24999,25000],
        'projection':['supplier','pa','buyer_class','category','other_sc_term_contract','legal_date'],
        'answer_names':['YES','NO']},
 'ID': {'question':'Does the original Category 1 exclusion remain in effect under this PA?',
        'fixed':{'supplier':'Grainger','pa':'ID-PADD20256877','buyer_class':'state agency','category':1,'amendment_identified':True},
        'varying_field':'legal_date', 'values':['2026-09-30','2026-10-01'],
        'projection':['supplier','pa','buyer_class','category','amendment_identified'],
        'answer_names':['YES','NO']},
}

def get_status(case, values):
    """Evaluate partial inputs by enumerating relevant completions, if supported.
       A missing input is None, not evidence that it is false.
    """
    if case=='WA':
        choices=[False, True] if values.get('cua_executed') is None else [values['cua_executed']]
        completions=[dict(values,cua_executed=x) for x in choices]
    elif case=='SC':
        pvals=[24999,25000] if values.get('unit_price_usd') is None else [values['unit_price_usd']]
        ovals=[False,True] if values.get('other_sc_term_contract') is None else [values['other_sc_term_contract']]
        completions=[dict(values,unit_price_usd=p,other_sc_term_contract=o) for p,o in itertools.product(pvals,ovals)]
    elif case=='ID':
        tvals=['2026-09-30','2026-10-01'] if values.get('legal_date') is None else [values['legal_date']]
        completions=[dict(values,legal_date=t) for t in tvals]
    else: raise KeyError(case)
    labels={answer(case,w) for w in completions}
    return ('YES' if labels=={True} else 'NO' if labels=={False} else 'REVIEW'), len(completions)

def project(world, cols): return tuple((col,world[col]) for col in cols)

rows=[]
for case,c in CASES.items():
    x=dict(c['fixed'],**{c['varying_field']:c['values'][0]})
    y=dict(c['fixed'],**{c['varying_field']:c['values'][1]})
    qx=answer(case,x); qy=answer(case,y)
    assert qx != qy, (case, qx, qy)
    assert project(x,c['projection'])==project(y,c['projection']), case
    assert all(x[k]==y[k] for k in x if k!=c['varying_field']),case
    assert ['YES' if qx else 'NO','YES' if qy else 'NO']==c['answer_names'], case
    # Restore the single erased distinction; the two worlds become separable.
    assert project(x,c['projection']+[c['varying_field']])!=project(y,c['projection']+[c['varying_field']])
    missing=dict(x,**{c['varying_field']:None})
    status,count=get_status(case,missing)
    assert status=='REVIEW',(case,status)
    row={'case':case,'instrument':SOURCES[case]['instrument'],'section':SOURCES[case]['section'],
         'pdf_page':SOURCES[case]['page'],'source_url':SOURCES[case]['url'],
         'bounded_question':c['question'],'erased_field':c['varying_field'],
         'x_value':str(c['values'][0]), 'y_value':str(c['values'][1]),
         'answer_x':c['answer_names'][0], 'answer_y':c['answer_names'][1],
         'same_retained_projection':True,'projected_fields':'; '.join(c['projection']),
         'status_if_erased':status,'number_of_completions':count,
         'observed_transaction':False, 'source_interpretation':'author-coded clause reading'}
    rows.append(row)

# Asymmetric factual sufficiency under an AND of the two SC exclusions.
sc=dict(CASES['SC']['fixed'])
checks={
 'SC_high_price_other_term_unknown':get_status('SC',dict(sc,unit_price_usd=25000,other_sc_term_contract=None))[0],
 'SC_low_price_other_term_unknown':get_status('SC',dict(sc,unit_price_usd=24999,other_sc_term_contract=None))[0],
 'SC_low_price_no_other_term':get_status('SC',dict(sc,unit_price_usd=24999,other_sc_term_contract=False))[0],
 'WA_CUA_unverified':get_status('WA',dict(CASES['WA']['fixed'],cua_executed=None))[0],
 'ID_legal_date_missing':get_status('ID',dict(CASES['ID']['fixed'],legal_date=None))[0],
}
assert checks=={'SC_high_price_other_term_unknown':'NO','SC_low_price_other_term_unknown':'REVIEW',
                'SC_low_price_no_other_term':'YES','WA_CUA_unverified':'REVIEW','ID_legal_date_missing':'REVIEW'}

# Contract-source ambiguity: one bounded DSP membership is invariant across
# two candidate schedules; VAR membership is not. This is distinct from loss
# of an input column under a fixed instrument.
radcube={'DSP':{'five_category':True,'ten_category':True},
         'VAR':{'five_category':False,'ten_category':True}}
rad_status={k:('YES' if set(v.values())=={True} else 'NO' if set(v.values())=={False} else 'REVIEW') for k,v in radcube.items()}
assert rad_status=={'DSP':'YES','VAR':'REVIEW'}

# Florida: the identified Global instrument is unfit as the witness to a
# Grainger local amendment. The absence of a different Grainger instrument
# in a selected packet cannot prove universal legal nonexistence.
florida={'candidate_document_party':'Global Industrial Equipment Company',
         'target_claim_party':'W.W. Grainger, Inc.',
         'offered_witness_is_target_party':'NO',
         'some_other_qualifying_local_amendment_exists':'REVIEW'}
assert florida['candidate_document_party']!=florida['target_claim_party']

# A second implementation in SQLite verifies the six fully specified
# rule evaluations without relying on the Python answer() implementation.
connection=sqlite3.connect(':memory:')
connection.execute('CREATE TABLE contexts(case_id TEXT, label TEXT, cua INTEGER, price INTEGER, other_term INTEGER, legal_date TEXT)')
for case,c in CASES.items():
    for label,value in zip(('x','y'),c['values']):
        if case=='WA': row=(case,label,int(value),None,None,c['fixed']['legal_date'])
        elif case=='SC':row=(case,label,None,value,0,c['fixed']['legal_date'])
        else:row=(case,label,None,None,None,value)
        connection.execute('INSERT INTO contexts VALUES (?,?,?,?,?,?)',row)
sql_results=connection.execute('''SELECT case_id,label,CASE
 WHEN case_id='WA' THEN cua
 WHEN case_id='SC' THEN CASE WHEN price<25000 AND other_term=0 THEN 1 ELSE 0 END
 WHEN case_id='ID' THEN CASE WHEN legal_date<'2026-10-01' THEN 1 ELSE 0 END END
 FROM contexts ORDER BY case_id,label''').fetchall()
for case,label,sql_result in sql_results:
    c=CASES[case];value=c['values'][0 if label=='x' else 1]
    full=dict(c['fixed'],**{c['varying_field']:value})
    assert sql_result==int(answer(case,full)),(case,label,sql_result)
connection.close()

with (ROOT/'loss_collision_witnesses.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report={'model_scope':'3 clause-level paired hypothetical examples from authored readings of cited signed PAs',
        'pair_count':len(rows),'sqlite_independent_clause_checks':len(sql_results),'pairs':rows,'partial_input_tests':checks,
        'competing_governing_instrument_status':rad_status,
        'wrong_party_witness_vs_unknown_other_document':florida,
        'confidence_boundary':'No deployment errors, observed purchases, independent legal truth labels, or general performance accuracy measured.'}
(ROOT/'loss_collision_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('PASS: 3 exact projection collisions; 6 SQL clause outcomes agree with Python; 3 missing-field REVIEW outcomes; 5 partial-input tests; RADcube/Florida boundary checks.')
for r in rows: print(f" {r['case']}: R(x)=R(y), Q(x)={r['answer_x']}, Q(y)={r['answer_y']}, erasing {r['erased_field']} -> {r['status_if_erased']}")
for k,v in checks.items(): print(f' {k}: {v}')
