#!/usr/bin/env python3
"""Check self-contained transcriptions against the frozen V55 ledger.
NOT an independent download of government records or a legal adjudication.
"""
from pathlib import Path
import csv
here=Path(__file__).resolve().parent

def load(n):
    with open(here/n,encoding='utf8',newline='') as f:return list(csv.DictReader(f))
ledger=load('source_input_560_V55_original.csv')
cases=load('ten_discrepancies_rechecked.csv')
controls=load('five_supplier_50_cell_control.csv')
assert len(ledger)==560 and len(cases)==10 and len(controls)==50
key={(r['supplier_slug'],r['category']):r for r in ledger}
assert len(key)==560
assert sum(int(r['web_yes']) for r in ledger)==318
assert sum(int(r['signed_yes']) for r in ledger)==321
for case in cases:
    rec=key[(case['supplier_slug'],case['category'])]
    assert int(case['web_structured_value'])==int(rec['web_yes'])
    assert int(case['attachment_B_value'])==int(rec['signed_yes'])
    assert case['contract_id']==rec['contract_id']
    assert int(case['web_structured_value'])!=int(case['attachment_B_value'])
assert sum(c['direction']=='WEB_ONLY' for c in cases)==1
assert sum(c['direction']=='CONTRACT_ONLY' for c in cases)==9
assert len({c['supplier_slug'] for c in cases})==5
assert sum(int(c['web'])!=int(c['contract']) for c in controls)==10
for c in controls:
    rec=key[(next(x['supplier_slug'] for x in cases if x['supplier']==c['supplier']),c['category'])]
    assert int(c['web'])==int(rec['web_yes'])
    assert int(c['contract'])==int(rec['signed_yes'])
nonrad=[r for r in ledger if r['supplier_slug']!='radcube-llc']
assert len(nonrad)==550 and len({r['supplier_slug'] for r in nonrad})==55
assert sum(int(r['web_yes']) for r in nonrad)==308
assert sum(int(r['signed_yes']) for r in nonrad)==316
assert sum(int(r['web_yes'])!=int(r['signed_yes']) for r in nonrad)==10
print('PASS: 10 individually indexed discrepancies across 5 suppliers; all 50 selected supplier cells agree with V55 ledger; 550 non-RADcube cells have 10 differences (1 web-only, 9 contract-only).')
print('Scope: confirms author source transcriptions and arithmetic; to verify primary sources, open cited NASPO URLs and PDF pages in REVIEWER_EVIDENCE_MAP.md.')
