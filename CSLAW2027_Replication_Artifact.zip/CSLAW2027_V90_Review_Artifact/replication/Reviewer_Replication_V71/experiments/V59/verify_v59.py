#!/usr/bin/env python3
"""Offline checks of ten-cell source transcription. Not independent legal ground truth."""
import csv,json,pathlib,collections
p=pathlib.Path(__file__).parent
with (p/'replication/ten_discrepancies_rechecked.csv').open() as f: rows=list(csv.DictReader(f))
m=json.loads((p/'PRIMARY_SOURCES.json').read_text())
assert len(rows)==10 and len(m['sources'])==5
assert {x['case_id'] for x in rows}=={f'D{i:02}' for i in range(1,11)}
assert len({x['contract_id'] for x in rows})==5
assert all(int(r['web_structured_value'])!=int(r['attachment_B_value']) for r in rows)
counts=collections.Counter(r['direction'] for r in rows)
assert counts=={'CONTRACT_ONLY':9,'WEB_ONLY':1},counts
for r in rows:
 source=next(x for x in m['sources'] if x['contract_id']==r['contract_id'])
 assert int(r['pdf_page_number_1based'])==int(source['verified_pdf_page_1based'])
 assert source['website_url']==r['web_page_url'] and source['contract_pdf_url']==r['contract_pdf_url']
 assert r['category'] in (source['website_categories_observed'] if r['web_structured_value']=='1' else source['attachment_B_categories_observed'])
 print(r['case_id'],r['contract_id'],r['category'],r['direction'])
print('PASS 10 verified transcriptions; 9 contract-only / 1 web-only, 5 masters')
