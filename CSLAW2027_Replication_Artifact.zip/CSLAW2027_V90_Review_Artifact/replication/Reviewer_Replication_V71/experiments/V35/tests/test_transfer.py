import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from transfer_audit import *
from independent_sql import sql_results

class TransferAudit(unittest.TestCase):
 def q(self,id):return next(q for q in benchmark() if q.id==id)
 def test_panel_unique(self):
  self.assertEqual(len(benchmark()),66)
  self.assertEqual(len({q.id for q in benchmark()}),66)
 def test_cross_program_mfp_original_signed_scope(self):
  for v,m,k in [('Canon','187646',13),('HP','187822',10),('Lexmark','188733',7)]:
   questions=[q for q in benchmark() if q.kind=='original_category' and q.vendor==v]
   self.assertEqual(sum(evaluate(q).status==YES for q in questions),k)
 def test_lexmark_internal_date_conflict(self):
  for d in ('2024-11-01','2024-11-14'):self.assertEqual(evaluate(self.q(f'MFP.amend.Lexmark.{d}')).status,AMBIG)
  self.assertEqual(evaluate(self.q('MFP.amend.Lexmark.2024-11-15')).status,YES)
 def test_hp_amendment(self):
  self.assertEqual(evaluate(self.q('MFP.amend.HP.2024-10-31')).status,EARLY)
  self.assertEqual(evaluate(self.q('MFP.amend.HP.2024-11-01')).status,YES)
 def test_canon_no_amendment_witness(self):
  for q in benchmark():
   if q.vendor=='Canon' and q.kind=='local_amendment':self.assertEqual(evaluate(q).status,NONE)
 def test_florida_global_grade_and_alias(self):
  self.assertEqual(evaluate(self.q('MRO.renew.Global.2026-06-24')).status,EARLY)
  self.assertEqual(evaluate(self.q('MRO.renew.Global.2026-06-25')).status,LIMITED)
  self.assertEqual(evaluate(self.q('MRO.renew.Grainger.2026-09-01')).status,NONE)
  self.assertTrue(naive_program(self.q('MRO.renew.Grainger.2026-09-01')))
 def test_idaho_local_legal_effect_not_global(self):
  for c in ('1','12'):
   self.assertEqual(evaluate(self.q(f'MRO.idaho.{c}.2026-09-30')).status,EXCLUDED)
   self.assertEqual(evaluate(self.q(f'MRO.idaho.{c}.2026-10-01')).status,REMOVED)
 def test_master_change_does_not_satisfy_local_incorporation(self):
  for v in ('Grainger','Global'):
   self.assertEqual(evaluate(self.q(f'MRO.incorp.{v}')).status,NONE)
 def test_source_grade(self):
  for q in benchmark():
   if q.family=='IT':self.assertEqual(evaluate(q).status,LIMITED)
 def test_linked_parent_is_required(self):
  q=self.q('MFP.amend.HP.2024-11-15')
  amended=tuple(replace(d,parent='WA_LEX_PA') if d.id=='WA_HP_EQ' else d for d in DOCS)
  self.assertEqual(evaluate(q,amended).status,NONE)
 def test_date_not_document_order(self):
  q=self.q('MFP.amend.HP.2024-11-01')
  amended=tuple(replace(d,effective=D('2024-12-01')) if d.id=='WA_HP_EQ' else d for d in DOCS)
  self.assertEqual(evaluate(q,amended).status,EARLY)
 def test_source_downgrade_preserved(self):
  q=self.q('MFP.amend.HP.2024-11-15')
  amended=tuple(replace(d,grade='INDEXED_ONLY') if d.id=='WA_HP_EQ' else d for d in DOCS)
  self.assertEqual(evaluate(q,amended).status,LIMITED)
 def test_no_evidence_after_removing_actual(self):
  q=self.q('MFP.amend.HP.2024-11-15')
  amended=tuple(d for d in DOCS if d.id!='WA_HP_EQ')
  self.assertEqual(evaluate(q,amended).status,NONE)
 def test_same_program_other_vendor_cannot_interfere(self):
  o=metamorphic_results();self.assertEqual(o['passed'],o['checks']);self.assertEqual(o['checks'],81)
 def test_benchmark_counts(self):
  r=evaluate_bench();self.assertEqual(r['total_queries'],66)
  self.assertEqual(r['baseline']['program_broadcast']['unsupported_positive'],19)
  self.assertEqual(r['baseline']['vendor_and_signed_only']['unsupported_positive'],16)
  self.assertEqual(r['baseline']['typed_no_legal_gate']['unsupported_positive'],12)
 def test_independent_sql_shared_facts(self):
  r=sql_results();self.assertEqual(len(r),66)
  self.assertEqual(r,{q.id:evaluate(q).status for q in benchmark()})

if __name__=='__main__':unittest.main()
