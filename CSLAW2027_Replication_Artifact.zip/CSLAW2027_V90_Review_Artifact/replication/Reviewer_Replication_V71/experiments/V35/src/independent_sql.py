"""Independently phrased SQL evidence-warrant rules against shared transcribed input.
NOT independent legal labeling, automatic PDF interpretation, or empirical model validation.
"""
from __future__ import annotations
import sqlite3,json,sys
from pathlib import Path
from datetime import date
sys.path.insert(0,str(Path(__file__).resolve().parent))
import transfer_audit as a

def sql_results():
 c=sqlite3.connect(':memory:'); c.row_factory=sqlite3.Row
 c.executescript('''CREATE TABLE docs(id TEXT, family TEXT, program TEXT, vendor TEXT, master TEXT,role TEXT,grade TEXT,parent TEXT,topic TEXT,signed TEXT,effective TEXT,alternate TEXT,scope_json TEXT,exclusion_json TEXT);''')
 for d in a.DOCS:
  c.execute('INSERT INTO docs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(
   d.id,d.family,d.program,d.vendor,d.master,d.role,d.grade,d.parent,d.topic,
   d.signed.isoformat() if d.signed else None,d.effective.isoformat() if d.effective else None,
   d.alternate_date.isoformat() if d.alternate_date else None,json.dumps(d.scope),json.dumps(d.excluded)))
 results={}
 for q in a.benchmark():
  day=q.asof.isoformat()
  if q.kind=='original_category':
   p=c.execute('SELECT * FROM docs WHERE role="SIGNED_PA" AND family=? AND program=? AND vendor=? AND master=? LIMIT 1',(q.family,q.program,q.vendor,q.master)).fetchone()
   if not p:status=a.NONE
   elif p['effective'] and p['effective']>day:status=a.EARLY
   elif q.category in json.loads(p['scope_json']):status=a.YES if p['grade']=='VISUAL' else a.LIMITED
   else:status=a.NOT_LISTED
  elif q.kind in ('local_amendment','renewal_document'):
   d=c.execute('''SELECT a.* FROM docs a JOIN docs p ON a.parent=p.id AND p.role='SIGNED_PA' AND a.vendor=p.vendor AND a.program=p.program AND a.master=p.master WHERE a.role='SIGNED_LOCAL_AMENDMENT' AND a.family=? AND a.program=? AND a.vendor=? AND a.master=? AND a.topic=? ORDER BY a.effective DESC,a.id DESC LIMIT 1''', (q.family,q.program,q.vendor,q.master,q.topic)).fetchone()
   if not d:status=a.NONE
   elif d['signed'] and day<d['signed']:status=a.EARLY
   elif d['alternate'] and d['effective'] and min(d['alternate'],d['effective'])<=day<max(d['alternate'],d['effective']):status=a.AMBIG
   elif d['effective'] and day<d['effective']:status=a.EARLY
   elif d['grade']=='VISUAL':status=a.YES
   else:status=a.LIMITED
  elif q.kind=='idaho_local_exclusion':
   p=c.execute('SELECT * FROM docs WHERE id="ID_PA"').fetchone()
   if p is None:status=a.NONE
   elif q.category not in json.loads(p['exclusion_json']):status=a.NONE
   else:
    am=c.execute('''SELECT a.id FROM docs a JOIN docs p ON a.parent=p.id AND p.role='SIGNED_PA' AND a.vendor=p.vendor AND a.master=p.master WHERE a.role='SIGNED_LOCAL_AMENDMENT' AND a.parent='ID_PA' AND a.topic='delete_category_exclusion' AND a.signed<=? AND a.effective<=? LIMIT 1''',(day,day)).fetchone()
    status=a.REMOVED if am else a.EXCLUDED
  elif q.kind=='clause_presence':
   d=c.execute('SELECT * FROM docs WHERE family=? AND vendor=? AND master=? AND role="SIGNED_PA"',(q.family,q.vendor,q.master)).fetchall()
   d=next((x for x in d if q.topic in x['topic'].split(';')),None)
   status=a.LIMITED if d and d['grade']=='INDEXED_ONLY' else a.YES if d else a.NONE
  elif q.kind=='master_change_incorporated':
   ds=c.execute('''SELECT a.grade FROM docs a JOIN docs p ON a.parent=p.id AND p.role='SIGNED_PA' AND a.vendor=p.vendor AND a.master=p.master AND a.program=p.program WHERE a.role='SIGNED_LOCAL_AMENDMENT' AND a.program=? AND a.vendor=? AND a.master=? AND a.topic=? AND (a.signed IS NULL OR a.signed<=?) AND (a.effective IS NULL OR a.effective<=?)''',(q.program,q.vendor,q.master,q.topic,day,day)).fetchall()
   status=(a.YES if all(d['grade']=='VISUAL' for d in ds) else a.LIMITED) if ds else a.NONE
  else:raise AssertionError(q.kind)
  results[q.id]=status
 return results

if __name__=='__main__':
 exp={q.id:a.evaluate(q).status for q in a.benchmark()}; actual=sql_results()
 problems={k:(v,actual.get(k)) for k,v in exp.items() if v!=actual.get(k)}
 out={'total':len(exp),'matching':len(exp)-len(problems),'disagreements':problems,'caveat':'Same hand-interpreted document ledger; SQL parity not independent legal annotation'}
 (a.BASE/'results/V35_SQL_PARITY.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(out,indent=2))
 if problems:raise SystemExit(1)
