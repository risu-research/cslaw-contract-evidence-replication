"""Manually encoded documentary expectations from prior source audits.
Separate table-based oracle; same human analyst, not independent legal ground truth.
"""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import transfer_audit as a
p=Path(__file__).resolve().parents[1]
status={}
wa_scopes={'Canon':set('A B C D E F G H I G1 C1 C2 D1'.split()),'HP':set('A B D E F G H I G1 D1'.split()),'Lexmark':set('B D G H I G1 D1'.split())}
for q in a.benchmark():
 if q.kind=='original_category':status[q.id]=a.YES if q.category in wa_scopes[q.vendor] else a.NOT_LISTED
 elif q.kind=='local_amendment':
  idx=q.asof.isoformat()
  if q.vendor=='Canon':status[q.id]=a.NONE
  elif q.vendor=='HP':status[q.id]=a.EARLY if idx<'2024-11-01' else a.YES
  elif q.vendor=='Lexmark':
   status[q.id]=a.EARLY if idx<'2024-11-01' else a.AMBIG if idx<'2024-11-15' else a.YES
 elif q.kind=='renewal_document':
  status[q.id]=a.NONE if q.vendor=='Grainger' else a.EARLY if q.asof.isoformat()<'2026-06-25' else a.LIMITED
 elif q.kind=='idaho_local_exclusion':status[q.id]=a.EXCLUDED if q.asof.isoformat()<'2026-10-01' else a.REMOVED
 elif q.kind=='clause_presence':status[q.id]=a.LIMITED
 elif q.kind=='master_change_incorporated':status[q.id]=a.NONE
 else:raise AssertionError(q)
computed={q.id:a.evaluate(q).status for q in a.benchmark()}
errors={k:{'manual':v,'engine':computed.get(k)} for k,v in status.items() if v!=computed.get(k)}
out={'total':len(status),'matched':len(status)-len(errors),'differences':errors,'oracle_limit':'Manually transcribed original contract clauses and fixed examples by SAME researcher. Not independent legal accuracy. Lexmark ambiguous flag is conservative author policy.'}
(p/'results/V35_MANUAL_LABEL_AUDIT.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
if errors:sys.exit(1)
