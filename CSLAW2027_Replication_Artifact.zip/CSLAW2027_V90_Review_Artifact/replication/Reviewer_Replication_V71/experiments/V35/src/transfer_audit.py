"""V35: typed documentary-warrant transfer audit, stdlib only.

An auditable specimen benchmark assembled from prior official-PDF clause transcriptions.
It predicts what the inspected packet can WARRANT, not ultimate legal truth.
It does not read PDFs, resolve ambiguous legal meaning, or verify signatures cryptographically.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from datetime import date
from pathlib import Path
from collections import Counter
import json, random
from typing import Optional

BASE=Path(__file__).resolve().parents[1]

def D(x): return date.fromisoformat(x) if isinstance(x,str) else x

@dataclass(frozen=True)
class Document:
    id:str; family:str; program:str; vendor:str; master:str
    role:str; grade:str; url:str
    parent:str=''; topic:str=''; signed:Optional[date]=None; effective:Optional[date]=None
    alternate_date:Optional[date]=None; scope:tuple[str,...]=(); excluded:tuple[str,...]=()

DOCS=(
 Document('WA_CANON_PA','MFP','WA26723','Canon','187646','SIGNED_PA','VISUAL','https://apps.des.wa.gov/contracting/PA_WA_State_Canon_signed.pdf',signed=D('2024-06-28'),effective=D('2024-08-01'),scope=('A','B','C','D','E','F','G','H','I','G1','C1','C2','D1')),
 Document('WA_HP_PA','MFP','WA26723','HP','187822','SIGNED_PA','VISUAL','https://apps.des.wa.gov/contracting/HP_Amd1andPA_11-8-2024.pdf',signed=None,effective=D('2024-08-01'),scope=('A','B','D','E','F','G','H','I','G1','D1')),
 Document('WA_LEX_PA','MFP','WA26723','Lexmark','188733','SIGNED_PA','VISUAL','https://apps.des.wa.gov/contracting/Lexmark_Amd1andPA_11-8-2024.pdf',signed=None,effective=D('2024-11-01'),scope=('B','D','G','H','I','G1','D1')),
 Document('WA_HP_EQ','MFP','WA26723','HP','187822','SIGNED_LOCAL_AMENDMENT','VISUAL','https://apps.des.wa.gov/contracting/HP_Amd1andPA_11-8-2024.pdf',parent='WA_HP_PA',topic='pay_equality_warranty',signed=D('2024-10-28'),effective=D('2024-11-01')),
 Document('WA_LEX_EQ','MFP','WA26723','Lexmark','188733','SIGNED_LOCAL_AMENDMENT','VISUAL','https://apps.des.wa.gov/contracting/Lexmark_Amd1andPA_11-8-2024.pdf',parent='WA_LEX_PA',topic='pay_equality_warranty',signed=D('2024-10-30'),effective=D('2024-11-15'),alternate_date=D('2024-11-01')),
 Document('FL_GRAINGER_PA','MRO','FL31160000-25','Grainger','758-2500000413','SIGNED_PA','VISUAL','https://www.leegov.com/procurement/Project%20Documents/Grainger%20Annual/State%20of%20Florida%20Grainger%20Participating%20Addendum.pdf',signed=D('2024-12-10'),effective=D('2025-01-01')),
 Document('FL_GLOBAL_PA','MRO','FL31160000-25','Global','758-2500000416','SIGNED_PA','INDEXED_ONLY','https://s3-us-west-2.amazonaws.com/naspovaluepoint/1734630127_FACILI_1.pdf',signed=D('2024-12-19'),effective=D('2025-01-01')),
 Document('FL_GLOBAL_RENEW','MRO','FL31160000-25','Global','758-2500000416','SIGNED_LOCAL_AMENDMENT','INDEXED_ONLY','https://www.dms.myflorida.com/content/download/460372/9737450?version=1',parent='FL_GLOBAL_PA',topic='renewal_executed',signed=D('2026-06-25'),effective=D('2026-06-25')),
 Document('FL_LEE_SUMMARY','MRO','FL31160000-25','Grainger','758-2500000413','ADMIN_STATUS','OFFICIAL_SUMMARY','https://www.leegov.com/procurement/Project%20Documents/Grainger%20Annual/PB250031CMJ%20-%20Contract%20Summary%20Information%20updated%2009.22.26.pdf',topic='renewal_executed',signed=None,effective=D('2026-09-22')),
 Document('KY_GRAINGER_MASTER_CHANGE','MRO','KY-MA-0413','Grainger','758-2500000413','SIGNED_MASTER_AMENDMENT','VISUAL_PRIOR_AUDIT','https://s3.us-east-1.amazonaws.com/nvp/Master%20Agreements/W.W.%20Grainger,%20Inc./Grainger%20Signed%20Renewal%201.pdf',topic='third_party_sourcing',signed=D('2026-05-26'),effective=D('2026-09-01')),
 Document('ID_PA','MRO','ID-PADD20256877','Grainger','758-2500000413','SIGNED_PA','VISUAL_PRIOR_AUDIT','https://purchasing.idaho.gov/wp-content/uploads/PADD20256877-Original-Contract.pdf',signed=None,effective=None,excluded=('1','12')),
 Document('ID_AMENDMENT','MRO','ID-PADD20256877','Grainger','758-2500000413','SIGNED_LOCAL_AMENDMENT','VISUAL_PRIOR_AUDIT','https://purchasing.idaho.gov/wp-content/uploads/PADD20256877-Amendment-1.pdf',parent='ID_PA',topic='delete_category_exclusion',signed=D('2026-09-24'),effective=D('2026-10-01'),scope=('1','12')),
 Document('ME_DELL_PA','IT','ME-DELL-230906','Dell','NASPO-23026','SIGNED_PA','INDEXED_ONLY','https://www.maine.gov/dafs/bbm/procurementservices/sites/maine.gov.dafs.bbm.procurementservices/files/inline-files/MA%20230906_0032%20Dell%20Computer%20Equipment%20Extension%202026.pdf',topic='entity_prior_approval;lease_prohibition;agent_receipt_restriction',signed=D('2024-02-02'),effective=D('2024-02-02')),
)

@dataclass(frozen=True)
class Query:
    family:str; kind:str; vendor:str; program:str; asof:date
    category:str=''; topic:str=''; master:str=''; id:str=''

@dataclass(frozen=True)
class Outcome:
    status:str; witnesses:tuple[str,...]=(); reason:str=''

# Status codes are legally restricted claims about the INSPECTED document packet.
YES='DIRECT_VISUAL_WITNESS'; LIMITED='INDEXED_TEXT_WITNESS'; NOT_LISTED='NOT_LISTED_IN_INSPECTED_ORIGINAL'
NONE='NO_INSPECTED_WITNESS'; EARLY='NOT_EFFECTIVE_UNDER_DOCUMENT'; AMBIG='TEXTUAL_DATE_TENSION'
EXCLUDED='ORIGINAL_EXCLUSION_APPLIES'; REMOVED='ORIGINAL_EXCLUSION_REMOVED'


def parent_for(doc:Document,docs:tuple[Document,...]):
    return next((p for p in docs if p.id==doc.parent and p.role=='SIGNED_PA' and p.vendor==doc.vendor and p.program==doc.program and p.master==doc.master),None)


def evaluate(q:Query,docs=DOCS)->Outcome:
    # Scope question explicitly about the enumerated ORIGINAL schedule; not current full legal authorization.
    if q.kind=='original_category':
        pa=next((d for d in docs if d.role=='SIGNED_PA' and d.family==q.family and d.program==q.program and d.vendor==q.vendor and d.master==q.master),None)
        if not pa: return Outcome(NONE,(),'No matching inspected original PA')
        if pa.effective and q.asof<pa.effective: return Outcome(EARLY,(pa.id,),'Original PA not yet effective')
        if q.category in pa.scope: return Outcome(YES if pa.grade=='VISUAL' else LIMITED,(pa.id,),'Category enumerated in this original PA')
        return Outcome(NOT_LISTED,(pa.id,),'Not enumerated in the specific closed schedule; other legal routes not assessed')
    if q.kind in ('local_amendment','renewal_document'):
        hits=[]
        for d in docs:
            if d.role!='SIGNED_LOCAL_AMENDMENT' or (d.family,d.program,d.vendor,d.master,d.topic)!=(q.family,q.program,q.vendor,q.master,q.topic):continue
            p=parent_for(d,docs)
            if p is None:continue
            hits.append(d)
        if not hits:return Outcome(NONE,(),'No inspected executed vendor/parent/topic-specific amendment; absence not proven')
        hits.sort(key=lambda d:(d.effective or date.min,d.id),reverse=True)
        d=hits[0]
        if d.signed and q.asof<d.signed:return Outcome(EARLY,(d.id,),'Not signed by question date')
        if d.alternate_date and d.effective and min(d.effective,d.alternate_date)<=q.asof<max(d.effective,d.alternate_date):
            return Outcome(AMBIG,(d.id,),'Face effective date and body dated-as are not reconciled')
        if d.effective and q.asof<d.effective:return Outcome(EARLY,(d.id,),'As-of date precedes effective date')
        if d.grade=='VISUAL':return Outcome(YES,(d.id,p.id),'Signed and effective document matched to PA and issue')
        return Outcome(LIMITED,(d.id,p.id),'Official indexed text; signature page not independently inspected')
    if q.kind=='idaho_local_exclusion':
        pa=next((d for d in docs if d.id=='ID_PA'),None)
        if not pa:return Outcome(NONE,(),'Idaho original not in inspected packet')
        if q.category not in pa.excluded:return Outcome(NONE,(pa.id,),'Outside stipulated original category-exclusion comparison')
        amendment=next((d for d in docs if d.role=='SIGNED_LOCAL_AMENDMENT' and d.parent=='ID_PA' and d.vendor==pa.vendor and d.master==pa.master and d.topic=='delete_category_exclusion'),None)
        if amendment and amendment.signed<=q.asof and amendment.effective<=q.asof:
            return Outcome(REMOVED,(pa.id,amendment.id),'Deleted exclusion; other purchasing conditions still open')
        return Outcome(EXCLUDED,(pa.id,),'Original PA excludes this category at this date, under inspected packet')
    if q.kind=='clause_presence':
        d=next((d for d in docs if d.role=='SIGNED_PA' and d.family==q.family and d.vendor==q.vendor and d.master==q.master and q.topic in d.topic.split(';')),None)
        if not d:return Outcome(NONE,(),'No inspected clause witness')
        return Outcome(LIMITED if d.grade=='INDEXED_ONLY' else YES,(d.id,),'Specific clause text documented, not compliance/approval in individual transactions')
    if q.kind=='master_change_incorporated':
        # A different jurisdiction's signed master change, report or county summary never suffices.
        specific=[d for d in docs if d.role=='SIGNED_LOCAL_AMENDMENT' and d.program==q.program and d.vendor==q.vendor and d.master==q.master and d.topic==q.topic and parent_for(d,docs) and (not d.signed or d.signed<=q.asof) and (not d.effective or d.effective<=q.asof)]
        if not specific:return Outcome(NONE,(),'Specific operative local incorporation evidence not in packet')
        return Outcome(YES if all(d.grade=='VISUAL' for d in specific) else LIMITED,tuple(d.id for d in specific),'Documented local incorporation')
    raise ValueError(q.kind)


def benchmark():
    out=[]
    cats=('A','B','C','D','E','F','G','H','I','G1','C1','C2','D1')
    for v,m in (('Canon','187646'),('HP','187822'),('Lexmark','188733')):
        for c in cats:
            out.append(Query('MFP','original_category',v,'WA26723',D('2024-11-16'),category=c,master=m,id=f'MFP.scope.{v}.{c}'))
        for d in ('2024-10-31','2024-11-01','2024-11-14','2024-11-15'):
            out.append(Query('MFP','local_amendment',v,'WA26723',D(d),topic='pay_equality_warranty',master=m,id=f'MFP.amend.{v}.{d}'))
    for v,m in (('Grainger','758-2500000413'),('Global','758-2500000416')):
        for d in ('2026-06-24','2026-06-25','2026-09-01'):
            out.append(Query('MRO','renewal_document',v,'FL31160000-25',D(d),topic='renewal_executed',master=m,id=f'MRO.renew.{v}.{d}'))
    for c in ('1','12'):
        for d in ('2026-09-30','2026-10-01'):
            out.append(Query('MRO','idaho_local_exclusion','Grainger','ID-PADD20256877',D(d),category=c,master='758-2500000413',id=f'MRO.idaho.{c}.{d}'))
    for topic in ('entity_prior_approval','lease_prohibition','agent_receipt_restriction'):
        out.append(Query('IT','clause_presence','Dell','ME-DELL-230906',D('2026-01-01'),topic=topic,master='NASPO-23026',id=f'IT.clause.{topic}'))
    for v,m in (('Grainger','758-2500000413'),('Global','758-2500000416')):
        out.append(Query('MRO','master_change_incorporated',v,'FL31160000-25',D('2026-10-18'),topic='third_party_sourcing',master=m,id=f'MRO.incorp.{v}'))
    return tuple(out)


def naive_program(q,docs=DOCS):
    if q.kind=='original_category':
        return any(d.role=='SIGNED_PA' and d.program==q.program and q.category in d.scope for d in docs)
    if q.kind in ('local_amendment','renewal_document'):
        return any(d.role=='SIGNED_LOCAL_AMENDMENT' and d.program==q.program and d.topic==q.topic and d.signed and d.signed<=q.asof and d.effective and d.effective<=q.asof for d in docs)
    if q.kind=='idaho_local_exclusion': return any(d.id=='ID_AMENDMENT' for d in docs) # uses current full document as of all times
    if q.kind=='master_change_incorporated':return any(d.role=='SIGNED_MASTER_AMENDMENT' and d.master==q.master for d in docs)
    return any(d.role=='SIGNED_PA' and q.topic in d.topic for d in docs)


def naive_vendor(q,docs=DOCS):
    if q.kind in ('local_amendment','renewal_document'):
        return any(d.role=='SIGNED_LOCAL_AMENDMENT' and d.program==q.program and d.vendor==q.vendor and d.signed and d.signed<=q.asof for d in docs)
    if q.kind=='master_change_incorporated':return any(d.role=='SIGNED_MASTER_AMENDMENT' and d.vendor==q.vendor for d in docs)
    return naive_program(q,docs)


def naive_typed_without_legal_gate(q,docs=DOCS):
    if q.kind in ('local_amendment','renewal_document'):
        return any(d.role=='SIGNED_LOCAL_AMENDMENT' and d.program==q.program and d.vendor==q.vendor and d.master==q.master and d.topic==q.topic and d.signed and d.signed<=q.asof and d.effective and d.effective<=q.asof and parent_for(d,docs) for d in docs)
    if q.kind=='master_change_incorporated':
        return any(d.role=='SIGNED_MASTER_AMENDMENT' and d.vendor==q.vendor and d.master==q.master for d in docs)
    return naive_vendor(q,docs)


def evaluate_bench():
    qs=benchmark()
    answer=[(q,evaluate(q)) for q in qs]
    # For this packet, only direct proof counts as high-confidence positive; 'LIMITED' is a positive but has restricted assurance.
    counts={}
    for family in ('MFP','MRO','IT'):
        rows=[(q,o) for q,o in answer if q.family==family]
        counts[family]={'queries':len(rows),'statuses':dict(Counter(o.status for _,o in rows))}
    baselines={}
    for name,fn in [('program_broadcast',naive_program),('vendor_and_signed_only',naive_vendor),('typed_no_legal_gate',naive_typed_without_legal_gate)]:
        problems=[{'query':q.id,'baseline_positive':True,'documentary_answer':o.status} for q,o in answer if fn(q) and o.status not in (YES,LIMITED,REMOVED)]
        # Also score unverified text as a separate proof-quality escalation, not a false legal yes.
        grade_escalations=[q.id for q,o in answer if fn(q) and o.status==LIMITED]
        baselines[name]={'unsupported_positive':len(problems),'examples':problems,'unverified_text_accepted_without_grade':grade_escalations}
    shared=[(q,o) for q,o in answer if q.kind in ('local_amendment','renewal_document')]
    shared_program={fam:{'queries':sum(q.family==fam for q,_ in shared),
         'documentary_positive':sum(q.family==fam and o.status in (YES,LIMITED) for q,o in shared),
         'strong_typed_binary_positive':sum(q.family==fam and naive_typed_without_legal_gate(q) for q,o in shared),
         'strong_typed_unsupported_positive':sum(q.family==fam and naive_typed_without_legal_gate(q) and o.status not in (YES,LIMITED) for q,o in shared)} for fam in ('MFP','MRO')}
    return {'shared_amendment_semantics':shared_program,'shared_amendment_finding':'On the shared 18-case signed-amendment witness task, a conventional typed parent/topic/effective-date join reproduces the SAME documentary-positive set; incremental benefit is explanation/grade/date tension, not predictive lift.', 'protocol':'retrospective cross-family structural audit, not blinded legal holdout','document_count':len(DOCS),'family_counts':counts,'total_queries':len(qs),'baseline':baselines,'query_outcomes':[{'id':q.id,'family':q.family,'kind':q.kind,'answer':o.status,'witnesses':o.witnesses,'reason':o.reason} for q,o in answer]}


def metamorphic_results():
    rng=random.Random(7312026)
    queries=benchmark()
    signatures=[]
    # For 3 families: adding 25 *different relationship* docs must not affect any fixed query.
    for fam in ('MFP','MRO','IT'):
        for i in range(25):
            dummy=Document(f'DISTRACTOR_{fam}_{i}',fam,{'MFP':'WA26723','MRO':'FL31160000-25','IT':'ME-DELL-230906'}[fam],f'Unrelated-{i}',f'MASTER-X-{i}','SIGNED_LOCAL_AMENDMENT','VISUAL','https://example.invalid/testing',parent=f'GHOST-{i}',topic='pay_equality_warranty' if fam=='MFP' else 'renewal_executed',signed=D('2024-01-01'),effective=D('2024-01-01'))
            cases=[q for q in queries if q.family==fam]
            checks=all(evaluate(q,DOCS+(dummy,))==evaluate(q,DOCS) for q in cases)
            signatures.append({'family':fam,'type':'unrelated_party_document_noninterference','pass':checks,'mutation':i})
    # For each actual positive local amendment, dropping it must remove its original positive witness.
    for amend_id in ('WA_HP_EQ','WA_LEX_EQ','FL_GLOBAL_RENEW'):
        removed=tuple(x for x in DOCS if x.id!=amend_id)
        affected=[q for q in queries if amend_id in evaluate(q).witnesses]
        signatures.append({'type':'delete_supporting_amendment','document':amend_id,'affected_queries':len(affected),'pass':bool(affected) and all(amend_id not in evaluate(q,removed).witnesses and evaluate(q,removed).status not in (YES,LIMITED) for q in affected)})
    # summary/doc role mutation: cannot prove a supplier-specific signed renewal merely by retagging packet with admin summary
    grainger=next(q for q in queries if q.id=='MRO.renew.Grainger.2026-09-01')
    signatures.append({'type':'official_summary_not_bilateral_signature','pass':evaluate(grainger).status==NONE and 'FL_LEE_SUMMARY' not in evaluate(grainger).witnesses})
    # Exact Lexmark date tension MUST remain open on Nov 1 and Nov 14.
    lex=[q for q in queries if q.id in ('MFP.amend.Lexmark.2024-11-01','MFP.amend.Lexmark.2024-11-14')]
    signatures.append({'type':'lexmark_date_tension','pass':len(lex)==2 and all(evaluate(q).status==AMBIG for q in lex)})
    # As-of before signed dates not provable.
    signatures.append({'type':'future_signature_nonretroactivity','pass':evaluate(next(q for q in queries if q.id=='MRO.renew.Global.2026-06-24')).status==EARLY})
    return {'checks':len(signatures),'passed':sum(x['pass'] for x in signatures),'failures':[x for x in signatures if not x['pass']],'checks_detail':signatures}


def main():
    a=evaluate_bench();m=metamorphic_results()
    (BASE/'results/V35_BENCHMARK.json').write_text(json.dumps(a,indent=2,ensure_ascii=False))
    (BASE/'results/V35_METAMORPHIC.json').write_text(json.dumps(m,indent=2,ensure_ascii=False))
    print(json.dumps({'docs':a['document_count'],'questions':a['total_queries'],'families':a['family_counts'],'baselines':{k:{'unsupported_positive':v['unsupported_positive'],'text_grade_escalations':len(v['unverified_text_accepted_without_grade'])} for k,v in a['baseline'].items()},'metamorphic':{'checks':m['checks'],'passed':m['passed']}},indent=2))

if __name__=='__main__':main()
