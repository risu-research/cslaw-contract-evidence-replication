# CSLAW V35 — Cross-program transfer and falsification audit

**Date:** October 18, 2026. **Research type:** retrospective structured transfer, not preregistered/blind human legal evaluation. V29 frozen protocol unchanged.

This packet is an extension of the V34 CSLAW paper. A 13-record source packet spans Washington DES multifunction device PAs, the Florida/Kentucky/Idaho MRO contracting chain, and Maine–Dell equipment. It contains 66 narrowly framed source-grounded questions. 18 supplier-specific PA amendment questions share the same generic link-evaluation method across WA and FL, and the strong typed SQL join matches the same six documentary-positive answers. No binary-accuracy advantage against that strong baseline was found. 16 unit tests, 81 metamorphic checks, 66 independent SQL computations, and 66 table-coded documentary expectations agree. **These are internal/documentary checks and NOT evidence of general legal accuracy or deployed-government software defects.**

## Start here

- `manuscript/CSLAW2027_V35_Cross_Family_Transfer_Working.pdf`: 38-page ACM working manuscript; body finishes on p.15 and references begin on p.15. Supplemental V35 transfer appendix follows old appendices, main body still subject to editorial review.
- `docs/V35_GENERALIZATION_AUDIT_KO.md`: rigorous Korean assessment, source links, question limits and limitations.
- `results/V35_BENCHMARK.json`: status of 66 fixed inspected-packet questions; three deliberately coarse controls.
- `results/V35_METAMORPHIC.json`: 81 document-perturbation checks.
- `results/V35_SQL_PARITY.json`: 66/66 independent SQLite query formulation vs Python, same human transcribed facts.
- `results/V35_MANUAL_LABEL_AUDIT.json`: separate table-coded oracle, *same researcher*.
- `src/transfer_audit.py`: source-typed documentary witness evaluator and controlled mutations.
- `src/independent_sql.py`: separate SQL query formulation.
- `src/gold_from_manual_clause_tables.py`: transparent human-coded document-expectation tables.
- `sources/V35_PRESERVED_PROVENANCE_LEDGER.json`: primary URLs, dates, document roles and source grades.
- `prior/V29_PROTOCOL_UNCHANGED.md` and `prior/V34_WORKING_UNMODIFIED.tex`: source states are never rescored/overwritten.

## Reproduce
```
python src/transfer_audit.py
python src/independent_sql.py
python src/gold_from_manual_clause_tables.py
python -m unittest discover -s tests -v
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error CSLAW2027_V35_Cross_Family_Transfer_Working.tex
pdflatex -interaction=nonstopmode -halt-on-error CSLAW2027_V35_Cross_Family_Transfer_Working.tex
```

## Key negative result
Proper supplier/master/parent/time linkage is NECESSARY for the narrow documentary questions but is not sufficient for general legal accuracy. Lexmark has an explicit November 15 effective date and a November 1 dated-as recital; Maine imposes buyer/lease/agent restrictions; Florida master change incorporation requires a local instrument. Automated source linking does not resolve these legal conditions.

## Prior art
OCDS identifiers, contract-suppliers and extendsContractID extensions; LegalRuleML; Nash-Segoufin-Vianu view determinacy; database provenance. We do not claim novelty of relational IDs, priority or provenance techniques.
