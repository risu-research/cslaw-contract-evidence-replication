"""Bounded, source-coherent scope choices from RADcube's two published Attachment Bs.

This is an authored interpretation of the two printed schedules in official PDF
at pages 2 and 62. It does NOT adjudicate contractual precedence, later amendments,
or whether any separate reseller activity is legally permitted. Input census is
used only to extract the five category names and original evidence URL; its historic
`signed_yes` labels are NOT used as an authoritative answer for RADcube.
"""
import csv, itertools, json, pathlib, sqlite3
ROOT=pathlib.Path(__file__).resolve().parent
IN=ROOT/'source_input_560.csv'
CATS=('VAR SaaS','VAR IaaS','VAR PaaS','VAR On-Premise','VAR Value Added Services')
DSP=('DSP SaaS','DSP IaaS','DSP PaaS','DSP On-Premise','DSP Value Added Services')

def inputs():
    with IN.open(newline='',encoding='utf-8') as f: records=list(csv.DictReader(f))
    selected={r['category']:r for r in records if r['supplier_slug']=='radcube-llc'}
    assert len(records)==560 and len(selected)==10
    assert set(selected)==set(CATS+DSP)
    assert {r['contract_id'] for r in selected.values()}=={'LS5017'}
    assert len({r['pdf_url'] for r in selected.values()})==1
    return selected

def worlds():
    _=inputs()
    # Restriction to the two printed B schedules *only*; shared instrument choice.
    coherent={'DSP_only':tuple([0]*5),'DSP_and_VAR':tuple([1]*5)}
    # Deliberately naive relaxation: independently unknown VAR entries.
    independent=set(itertools.product((0,1),repeat=5))
    return coherent, independent

def statuses(values):
    answers=set(values)
    return 'YES' if answers=={True} else 'NO' if answers=={False} else 'REVIEW'

def run():
    coherent, independent=worlds()
    exact=set(coherent.values())
    assert exact.issubset(independent)
    flags=[]
    for i,j in itertools.combinations(range(5),2):
        category_i,category_j=CATS[i],CATS[j]
        q=lambda world:world[i]==world[j]
        flags.append({'query':f'{category_i} and {category_j} have equal enumerated VAR-award status',
          'coherent':statuses(q(w) for w in exact), 'independent':statuses(q(w) for w in independent)})
    # Exhaust all 16 Boolean functions on each 2-category projection,
    # to avoid selecting only the easy equality illustration. Each indexed
    # pair+truth-table is a LOGICAL CHECK, not a distinct legal observation.
    all_pair_functions=0
    pair_functions_newly_decidable=0
    for i,j in itertools.combinations(range(5),2):
        for truth_table in itertools.product((False,True),repeat=4):
            fn=lambda w:truth_table[2*w[i]+w[j]]
            all_pair_functions+=1
            if statuses(fn(w) for w in exact)!='REVIEW' and statuses(fn(w) for w in independent)=='REVIEW':
                pair_functions_newly_decidable+=1
    out={
        'source': next(iter(inputs().values()))['pdf_url'],
        'scope_boundary': 'Only the two inspected Attachment B schedules, not a complete proof of governing legal scope or subsequent amendments',
        'coherent_source_versions': {label:list(w) for label,w in coherent.items()},
        'categories':list(CATS),
        'independent_status_cells':5,
        'source_coherent_assignment_count':len(exact),
        'independent_assignment_count':len(independent),
        'spurious_mixed_assignments':len(independent-exact),
        'source_coherent_possible_var_counts':sorted({sum(w) for w in exact}),
        'independent_possible_var_counts':sorted({sum(w) for w in independent}),
        'question_exactly_three_var_categories':{
            'source_coherent':statuses(sum(w)==3 for w in exact),
            'independent':statuses(sum(w)==3 for w in independent)},
        'question_all_five_have_equal_membership':{
            'source_coherent':statuses(len(set(w))==1 for w in exact),
            'independent':statuses(len(set(w))==1 for w in independent)},
        'pairwise_same_status_queries':flags,
        'pair_indexed_boolean_functions_checked':all_pair_functions,
        'pair_indexed_functions_definite_only_under_coherence':pair_functions_newly_decidable,
        'independence_relaxation_soundness': 'Each actual source-choice assignment is in the independent relaxation, so independent possible-answer sets can only be equal or wider for arbitrary Boolean questions.'
    }
    # Independent SQL implementation uses a common version ID, not 5 unrelated NULLs.
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE scope(version TEXT, category TEXT, in_var INT)')
    db.executemany('INSERT INTO scope VALUES (?,?,?)', ((v,CATS[i],w[i]) for v,w in coherent.items() for i in range(5)))
    sql_counts=sorted(t[0] for t in db.execute('SELECT SUM(in_var) FROM scope GROUP BY version'))
    assert sql_counts==out['source_coherent_possible_var_counts']
    out['sql_crosscheck_counts']=sql_counts
    out['sql_crosscheck_matches']=True
    return out

if __name__=='__main__':
    r=run()
    (ROOT/'results.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
    with (ROOT/'cross_claim_queries.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['query','coherent','independent']);w.writeheader();w.writerows(r['pairwise_same_status_queries'])
    print('PASS source coherent',r['source_coherent_assignment_count'],'vs marginal',r['independent_assignment_count'],'; spurious',r['spurious_mixed_assignments'],'; SQL counts',r['sql_crosscheck_counts'])
