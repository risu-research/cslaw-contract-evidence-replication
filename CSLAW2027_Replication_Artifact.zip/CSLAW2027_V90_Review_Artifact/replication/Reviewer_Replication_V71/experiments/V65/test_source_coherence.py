import unittest,itertools
from source_coherence import CATS,DSP,inputs,worlds,statuses,run
class TestSourceChoice(unittest.TestCase):
 def test_has_5_var_and_5_dsp(self): self.assertEqual(len(inputs()),10)
 def test_source_is_unique(self): self.assertEqual(len(set(r['pdf_url'] for r in inputs().values())),1)
 def test_two_versions(self): self.assertEqual(len(worlds()[0]),2)
 def test_32_marginal_combinations(self): self.assertEqual(len(worlds()[1]),32)
 def test_only_2_coherent(self): self.assertEqual(len(set(worlds()[0].values())),2)
 def test_subset(self): self.assertTrue(set(worlds()[0].values())<=worlds()[1])
 def test_spurious_30(self): self.assertEqual(len(worlds()[1]-set(worlds()[0].values())),30)
 def test_no_intermediate_count(self): self.assertEqual(sorted({sum(w) for w in worlds()[0].values()}),[0,5])
 def test_relaxed_counts(self): self.assertEqual(sorted({sum(w) for w in worlds()[1]}),list(range(6)))
 def test_joint_count_three(self): self.assertEqual(run()['question_exactly_three_var_categories'],{'source_coherent':'NO','independent':'REVIEW'})
 def test_all_equal_question(self): self.assertEqual(run()['question_all_five_have_equal_membership'],{'source_coherent':'YES','independent':'REVIEW'})
 def test_pairwise_ten(self): self.assertEqual(len(run()['pairwise_same_status_queries']),10)
 def test_each_pair_certain_only_coherent(self):
  for r in run()['pairwise_same_status_queries']:
   self.assertEqual(r['coherent'],'YES');self.assertEqual(r['independent'],'REVIEW')
 def test_all_pair_boolean_functions(self):self.assertEqual((run()['pair_indexed_boolean_functions_checked'],run()['pair_indexed_functions_definite_only_under_coherence']),(160,60))
 def test_sql(self):self.assertTrue(run()['sql_crosscheck_matches'])
 def test_no_probabilistic_interpretation(self):self.assertNotIn('probability',str(run()).lower())
if __name__=='__main__':unittest.main(verbosity=2)
