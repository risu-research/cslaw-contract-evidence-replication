#!/usr/bin/env python3
"""Independent cross-tabulation of V7 flat CSV, without importing V7 code or its summary."""
from pathlib import Path
import csv,json,collections,hashlib,re
P=Path(__file__).resolve().parent/'V7_PRIMARY_MINIMAL'
read=lambda f:list(csv.DictReader((P/f).open(encoding='utf-8-sig',newline='')))
ledger=read('FULL_560_SIGNED_VS_WEB.csv'); sources=read('SIGNED_56_VERIFIED_RECONCILIATION.csv'); query=read('BUYER_QUERY_TEN_CATEGORIES.csv')
assert len(ledger)==560 and len(sources)==56
assert len({x['supplier_slug'] for x in ledger})==56
cnt=collections.Counter();errors=[]; changes=collections.defaultdict(list); category=collections.defaultdict(lambda:{'web':set(),'signed':set()})
for x in ledger:
 a=int(x['web_yes']);b=int(x['signed_yes']);cls='match' if a==b else ('web_only' if a else 'signed_only');cnt[cls]+=1
 if a:category[x['category']]['web'].add(x['supplier_slug'])
 if b:category[x['category']]['signed'].add(x['supplier_slug'])
 if a!=b:changes[x['supplier_slug']].append((x['category'],cls))
for x in sources:
 vals=[l for l in ledger if l['supplier_slug']==x['supplier_slug']]
 assert len(vals)==10
 assert len([q for q in vals if q['decision']!='MATCH'])==int(x['web_vs_signed_disagreements'])
 assert x['source_transcribed_2026_signed_scope_mask']==x['frozen_2025_award_scope_mask'],x['supplier_slug']
assert cnt=={'match':545,'web_only':6,'signed_only':9}
for c,sets in category.items():
 assert len(sets['web']^sets['signed'])==len(sets['web']-sets['signed'])+len(sets['signed']-sets['web'])
result={'rows':len(ledger),'suppliers':len(sources),'record_type':'single-author coded source-anchored csv; this audit does NOT independently recode original PDFs','counts':dict(cnt),'affected_supplier_count':len(changes),'web_sum':sum(len(v['web']) for v in category.values()),'signed_sum':sum(len(v['signed']) for v in category.values()),'category_results':{k:{'web_n':len(v['web']),'signed_n':len(v['signed']),'listed_not_signed':sorted(v['web']-v['signed']),'signed_not_listed':sorted(v['signed']-v['web'])} for k,v in category.items()},'affected_suppliers':{k:v for k,v in changes.items()},'sums_equal_but_sets_differ':[k for k,v in category.items() if len(v['web'])==len(v['signed']) and v['web']!=v['signed']]}
assert len(result['sums_equal_but_sets_differ'])>=1
Path(__file__).with_name('INDEPENDENT_RECOUNT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['category_results','affected_suppliers']},indent=2))
for k in result['sums_equal_but_sets_differ']:
 print('SAME SIZE DIFFERENT IDENTITIES',k,result['category_results'][k])
