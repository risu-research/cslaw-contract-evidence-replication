# CSLAW V38: adversarial legal/CS/source audit

Primary manuscript: `manuscript/CSLAW2027_V38_Adversarial_Source_Review.pdf` and `.tex`.

**Scope:** Narrow primary-record reliability and final referee attack review. V37 full study + explicit V38 appendix retained. No outside blinded attorney participated; no independent visual reread of the extra five suppliers' signed PDFs is claimed.

New materials: `results/V38_ADDITIONAL_PORTAL_ONLY_50.csv` (five additional suppliers, 50 current web tags), `results/V38_VALIDATION_SUMMARY.json`, `results/V38_RERUN_NUMERIC_CHECK.json`, `docs/V38_REFEREE_AND_PRIMARY_SOURCE_AUDIT_KO.md`.

Retained materials: V37 core signed-vs-web ledger, 90-cell paired-source review, review scripts, unit tests, and earlier source register. V29 preregistration content is unmodified and not mixed into this retrospective audit.

Reproduce from root:
```
python src/reverify.py
python -m unittest discover -s tests -v
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error CSLAW2027_V38_Adversarial_Source_Review.tex
pdflatex -interaction=nonstopmode -halt-on-error CSLAW2027_V38_Adversarial_Source_Review.tex
```

Primary findings: 56 supplier profiles, 560 cells, 15 discrepancies (6 page-only/9 signed-only) across 6 suppliers. Five webpage-only controls match 50/50 frozen web labels. The shared amendment-linking task reaches the same result as strong SQL. This is not an end-to-end legal accuracy benchmark.
