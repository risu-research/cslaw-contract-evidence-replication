import csv,json,pathlib
p=pathlib.Path(__file__).resolve().parents[1]
main=list(csv.DictReader((p/'prior/V24/V7_PRIMARY_MINIMAL/FULL_560_SIGNED_VS_WEB.csv').open()))
by={}
for x in main:by[x['supplier_slug']]=x
anchors={'radcube-llc':'Attachment B, PDF p.2; signed Amendment 1 cover PDF p.1','trace3-government-llc':'Attachment B, PDF p.54','accenture-llp-4':'Attachment B, PDF p.60','carahsoft-technology-corp-2':'Attachment B, PDF p.54','genesis-consulting-partners-llc-2':'Attachment B, PDF p.53','att-enterprises-llc':'Attachment B, PDF p.54','grant-street-group-llc':'Attachment B, PDF p.57','softchoice-corp-2':'Attachment B, PDF p.57','peraton-inc':'Attachment B, per source locator in V24 positive-control ledger'}
rows=[]
for slug,anchor in anchors.items():
 d=by[slug];rows.append({'supplier_slug':slug,'master_number':d['contract_id'],'source_webpage':'https://www.naspovaluepoint.org/suppliers/'+slug+'/','source_executed_pdf_url':d['pdf_url'],'inspected_anchor':anchor,'source_status':'reinspected public scope listing & posted signed Attachment B by SAME investigator','is_preselected_matching_control':str(slug in ('grant-street-group-llc','softchoice-corp-2','peraton-inc')),'audited_cells':'10','limitation':'No third-party blinded recoding; no signed source-byte archival/hash'})
f=p/'evidence/REINSPECTED_PRIMARY_SOURCE_REGISTER.csv';w=csv.DictWriter(f.open('w',newline=''),fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(f)
