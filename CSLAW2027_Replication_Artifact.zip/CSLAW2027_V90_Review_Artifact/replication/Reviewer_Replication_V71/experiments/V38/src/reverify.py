#!/usr/bin/env python3
"""Independent code path for numeric recount, plus explicitly manual documentary recoding.
The 9-source recoding is an author reinspection, NOT second-human legal annotation.
"""
import csv,json,collections,hashlib,pathlib
P=pathlib.Path(__file__).resolve().parents[1]
F=P/'prior/V24/V7_PRIMARY_MINIMAL/FULL_560_SIGNED_VS_WEB.csv'
rows=list(csv.DictReader(F.open(newline='')))
assert len(rows)==560
assert len(set((r['supplier_slug'],r['category']) for r in rows))==560
categories=['DSP SaaS','DSP IaaS','DSP PaaS','DSP On-Premise','DSP Value Added Services','VAR SaaS','VAR IaaS','VAR PaaS','VAR On-Premise','VAR Value Added Services']
by=collections.defaultdict(dict)
for r in rows:
 assert r['category'] in categories
 assert r['web_yes'] in ('0','1') and r['signed_yes'] in ('0','1')
 by[r['supplier_slug']][r['category']]=(int(r['web_yes']),int(r['signed_yes']))
assert len(by)==56 and all(set(v)==set(categories) for v in by.values())
match=sum(int(r['web_yes']==r['signed_yes']) for r in rows)
wo=sum(int(r['web_yes']=='1' and r['signed_yes']=='0') for r in rows)
so=sum(int(r['web_yes']=='0' and r['signed_yes']=='1') for r in rows)
assert (match,wo,so)==(545,6,9)
assert (sum(int(r['web_yes']) for r in rows),sum(int(r['signed_yes']) for r in rows))==(318,321)
assert sum(int(r['web_yes']=='1' and r['signed_yes']=='1') for r in rows)==312
assert {r['supplier_slug'] for r in rows if r['web_yes']!=r['signed_yes']}=={'radcube-llc','trace3-government-llc','accenture-llp-4','carahsoft-technology-corp-2','genesis-consulting-partners-llc-2','att-enterprises-llc'}

# Freshly keyed after opening each official supplier profile and agreement's Attachment B.
# Strings contain the ordered 5 DSP and 5 VAR category membership booleans.
# Cannot justify wider accuracy inference or call this independent ground truth.
manual={
 'radcube-llc':('1111111111','1111100000'),
 'trace3-government-llc':('1111101111','1111111111'),
 'accenture-llp-4':('1110111101','1111111111'),
 'carahsoft-technology-corp-2':('1110111111','1111111111'),
 'genesis-consulting-partners-llc-2':('1110111101','1111111111'),
 'att-enterprises-llc':('0000011101','1100111001'),
 'grant-street-group-llc':('1111100000','1111100000'),
 'softchoice-corp-2':('0000011111','0000011111'),
 'peraton-inc':('1111100000','1111100000'),
}
rows90=[]
for supplier,(web,signed) in manual.items():
 assert len(web)==len(signed)==10
 for i,c in enumerate(categories):
  prev=by[supplier][c]
  obs=(int(web[i]),int(signed[i]))
  rows90.append({'supplier':supplier,'category':c,'prior_web':prev[0],'prior_signed':prev[1], 'reinspected_web':obs[0],'reinspected_signed':obs[1], 'agreement': ('consistent' if prev==obs else 'DISCREPANCY')})
with (P/'results/PRIMARY_DOCUMENT_RECHECK_90.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows90[0].keys());w.writeheader();w.writerows(rows90)
findings=[x for x in rows90 if x['agreement']=='DISCREPANCY']
output={'census':{'suppliers':56,'cells':560,'matching':match,'web_only':wo,'signed_only':so,'affected_suppliers':6,'web_yes':318,'signed_yes':321,'overlap':312},'source_reinspection':{'suppliers':len(manual),'cells':len(rows90),'discrepant_suppliers':6,'matching_controls':3,'historical_coding_disagreements':len(findings),'disagreements':findings,'design':'purposive, same-investigator visual/text primary-source reinspection; NOT randomly sampled, blind, or independently expert-labeled'},'documentary_scope':'structured Products & Services Scope entries compared to the listed categories of executed Attachment B at source observation time; legal purchase eligibility not tested','input_csv_sha256':hashlib.sha256(F.read_bytes()).hexdigest()}
(P/'results/INDEPENDENT_NUMERIC_AND_SOURCE_RECHECK.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(output,indent=2,ensure_ascii=False))
