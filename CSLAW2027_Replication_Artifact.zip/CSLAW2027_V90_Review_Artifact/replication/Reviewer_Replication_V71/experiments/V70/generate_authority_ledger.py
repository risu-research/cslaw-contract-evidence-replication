#!/usr/bin/env python3
"""Typed provenance ledger kept outside the finite Boolean relation synthesis."""
import json,csv
from pathlib import Path
root=Path(__file__).resolve().parent
cases=json.loads((root/'input_version_vectors.json').read_text())['cases']
source_pages={
('UT_RADCUBE_LS5017','2026_front_attachment_b'):('2','Official combined master/amendment packet; front five-category Attachment B','priority between Attachment B schedules unresolved','amendment signed Apr 9 / May 5 2026; Attachment C expressly corrected'),
('UT_RADCUBE_LS5017','2025_original_attachment_b'):('62','Original executed master Attachment B in later combined packet','priority between Attachment B schedules unresolved','original master signed Nov 19-20 2025'),
('ID_ALLSTEEL_PA_2023_2024','original_PA'):('5','Original PA scope text','documented historical text, subject to effective date','original PA exclusions'),
('ID_ALLSTEEL_PA_2023_2024','amendment_1'):('3','Official compiled signed amendment scope text','documented historical text, subject to effective date','first amendment replaces PA section 1'),
('ID_ALLSTEEL_PA_2023_2024','amendment_2'):('1-2','Official signed amendment scope text','documented historical text, subject to effective date','Apr 30 2024 signed amendment 2'),
('WA_MILLERKNOLL_PA_21422','before_amendment_2'):('4-5','Earlier-text state inferred from description of clauses added by amendment','constructed pre-amendment textual comparator','no independent statutory-duty conclusion'),
('WA_MILLERKNOLL_PA_21422','amendment_2_effective_2024_10_01'):('4-7','Official compiled signed amendment text','dated insertion of the named clauses','effective Oct 1 2024'),
('WA_LANDSCAPE_PA_15122','before_amendment_4'):('8-10','Earlier-text state inferred from description of clauses added by amendment','constructed pre-amendment textual comparator','no independent statutory-duty conclusion'),
('WA_LANDSCAPE_PA_15122','amendment_4_effective_2024_06_01'):('8-11','Official compiled signed amendment text','dated insertion of the named clauses','effective Jun 1 2024'),
}
assert sum(len(c['versions']) for c in cases)==9
rows=[]
for c in cases:
    for v in c['versions']:
        pg,grade,status,qualification=source_pages[(c['id'],v['id'])]
        rows.append({'contract_lineage':c['id'],'version_id':v['id'],'documented_text_vector':''.join(map(str,v['values'])),
        'assertion_type':'enumerated category membership' if c['id'] in ('UT_RADCUBE_LS5017','ID_ALLSTEEL_PA_2023_2024') else 'insertion of named additional clauses',
        'source_url':c['official_url'],'pdf_page_1based':pg,'evidence_role':grade,'governing_source_assessment':status,
        'date_or_scope_qualification':qualification,
        'limitation':'This ledger does not decide legal priority or signatures independently; original bytes not archived in this experiment.'})
with (root/'source_authority_version_ledger.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert len(rows)==9
assert all('unresolved' in r['governing_source_assessment'] for r in rows if r['contract_lineage']=='UT_RADCUBE_LS5017')
assert all('constructed' in r['governing_source_assessment'] for r in rows if r['version_id'].startswith('before_'))
print('PASS nine version-specific source-role entries; RADcube priority kept unresolved, hypothetical pre-amendment comparators labeled')
