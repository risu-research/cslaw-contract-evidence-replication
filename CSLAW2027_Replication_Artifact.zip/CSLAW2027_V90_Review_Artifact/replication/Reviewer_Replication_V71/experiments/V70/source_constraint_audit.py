#!/usr/bin/env python3
"""Lossless *documented-version* constraint synthesis, not legal precedence inference.

Only a finite, source-anchored set of version vectors is evaluated. Select the
smallest set of pairwise equality/positive-implication constraints sufficient to
reconstruct exactly that set. On unsupported finite sets, report no solution.
Preserve version rows, source links, and legal evidence grades separately.
"""
import json, csv, sqlite3
from itertools import product, combinations
from pathlib import Path
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'input_version_vectors.json'

def worlds(n): return [tuple(v) for v in product((0,1), repeat=n)]

def constraints(k):
    c=[]
    for i,j in combinations(range(k),2):
        c.append((f'eq({i},{j})',lambda w,i=i,j=j:w[i]==w[j]))
    for i in range(k):
        for j in range(k):
            if i!=j: c.append((f'implies({i},{j})',lambda w,i=i,j=j:(not w[i]) or bool(w[j])))
    return c

def synthesize(F,k):
    """Exact minimum-cardinality cover of nonexistent worlds, under primitive schema."""
    U=worlds(k); bad=[w for w in U if w not in F]
    C=[(name, frozenset(w for w in bad if not f(w))) for name,f in constraints(k) if all(f(w) for w in F)]
    C=[(name,cover) for name,cover in C if cover]
    if not bad:return {'status':'exact','basis':[],'cost':0,'candidates':len(C)}
    badset=set(bad)
    if set().union(*(cov for _,cov in C))!=badset:
        uncovered=sorted(badset-set().union(*(cov for _,cov in C)))
        return {'status':'not_expressible','unexcluded_worlds':[list(w) for w in uncovered], 'cost':None,'candidates':len(C)}
    # Enumerate candidate subsets by cardinality; stable tie-break, bounded k=5, 3, 2.
    # Compress duplicate constraint masks (same invalid-world exclusion) to first lexical name.
    mask2name={}
    for name,cover in sorted(C): mask2name.setdefault(frozenset(cover),name)
    minimal=sorted([(cover,name) for cover,name in mask2name.items()],key=lambda x:x[1])
    for size in range(1,len(minimal)+1):
        for combo in combinations(minimal,size):
            if set().union(*(cover for cover,_ in combo))==badset:
                chosen=sorted(name for _,name in combo)
                return {'status':'exact','basis':chosen,'cost':size,'candidates':len(C), 'searched_distinct_candidate_masks':len(minimal)}
    raise AssertionError('unreachable')

def sql_reconstruct(k,basis):
    cx=sqlite3.connect(':memory:')
    cols=', '.join(f'x{i} INTEGER' for i in range(k))
    cx.execute(f'CREATE TABLE values_set ({cols})')
    cx.executemany('INSERT INTO values_set VALUES ('+','.join('?' for _ in range(k))+')',worlds(k))
    where=[]
    for rule in basis:
        if rule.startswith('eq('):
            i,j=map(int,rule[3:-1].split(','));where.append(f'x{i}=x{j}')
        else:
            i,j=map(int,rule[8:-1].split(','));where.append(f'(x{i}=0 OR x{j}=1)')
    result={tuple(x) for x in cx.execute('SELECT * FROM values_set WHERE '+' AND '.join(where) if where else 'SELECT * FROM values_set')}
    cx.close()
    return result

def aud(c):
    rows=c['versions'];F={tuple(x['values']) for x in rows}; k=len(c['labels']);assert all(len(t)==k for t in F)
    assert len(F)==len(rows),'repeated version vectors would require provenance-preserving map'
    independent=worlds(k)
    result=synthesize(F,k)
    if result['status']=='exact':
        reconst=sql_reconstruct(k,result['basis']);assert reconst==F
        result['verified_sql']=True
    else:result['verified_sql']=False
    # Marginal view cannot distinguish full joint product from actual finite F.
    marginals=[[w[i] for w in F] for i in range(k)]
    assert all(len(set(v))==2 for v in marginals)
    result.update({'id':c['id'],'name':c['name'],'source_url':c['official_url'],
        'source_version_ids':[v['id'] for v in rows],
        'labels':c['labels'],'documented_worlds':len(F),'marginal_product_worlds':len(independent),
        'unsupported_mixed_worlds':len(independent)-len(F),'source_vectors':[list(w) for w in sorted(F)],
        'example_query':'first_two_same_status',
        'first_two_same_status_documented':len({w[0]==w[1] for w in F})==1 and all(w[0]==w[1] for w in F),
        'first_two_same_status_independent':len({w[0]==w[1] for w in independent})==1,
        'is_documented_version_only':True})
    return result

def main():
    data=json.loads(INPUT.read_text()); results=[aud(c) for c in data['cases']]
    # Deliberately non-pairwise representable control. Every two-coordinate marginal complete.
    parity={w for w in worlds(3) if sum(w)%2==0}
    probe=synthesize(parity,3)
    assert probe['status']=='not_expressible'
    # All primitive constraints chosen are sound for all documented rows.
    assert sum(r['cost'] for r in results)==8
    assert sum(r['unsupported_mixed_worlds'] for r in results)==39
    out={'records':results,'totals':{'contract_lineages':len(results),
          'query_atoms':sum(len(r['labels']) for r in results),
          'documented_vectors':sum(r['documented_worlds'] for r in results),
          'independent_vectors':sum(r['marginal_product_worlds'] for r in results),
          'spurious_vectors':sum(r['unsupported_mixed_worlds'] for r in results),
          'minimum_primitives_total':sum(r['cost'] for r in results)},
         'nonexpressible_control':probe,
         'limitations':['Only version vectors recorded in four document lineages are enumerated; no exhaustive legal-world interpretation is claimed.',
         'The implication/equality basis summarizes observed states but cannot replace source/version provenance, dates, authorities, or signature verification.',
         'Pairwise primitives do not represent every possible finite set of worlds; a version-keyed relation always retains all observed vectors.',
         'No new SQL expressiveness or asymptotic performance superiority is claimed.']}
    (ROOT/'results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    with (ROOT/'constraints_by_contract.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['contract','category_atoms','source_versions','independent_assignments','unsupported_mixed_assignments','minimal_primitives','minimum_constraint_basis','official_source'])
        for r in results:w.writerow([r['name'],len(r['labels']),r['documented_worlds'],r['marginal_product_worlds'],r['unsupported_mixed_worlds'],r['cost'],'; '.join(r['basis']),r['source_url']])
    print(json.dumps(out['totals'],indent=2)); print('MINIMUM RULES:'); print(*[(r['name'],r['basis']) for r in results],sep='\n');print('NONEXPRESSIBLE CONTROL:',probe['status'])
    return out
if __name__=='__main__': main()
