from source_constraint_audit import *
import json,csv
root=Path(__file__).resolve().parent
C=json.loads((root/'input_version_vectors.json').read_text())['cases']
out=[]
for case in C:
    F={tuple(v['values']) for v in case['versions']}; k=len(case['labels']); rules=synthesize(F,k)['basis']
    for rule in rules:
        other=[r for r in rules if r!=rule]; allowed=sql_reconstruct(k,other)
        witness=sorted(allowed-F)[0]
        assert witness not in F
        out.append({'case':case['id'],'removed_rule':rule,'unattested_witness':''.join(map(str,witness)),'complete_source_versions':'; '.join(v['id'] for v in case['versions']),'source_url':case['official_url']})
with (root/'necessity_witnesses.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(f'PASS: {len(out)} irredundant rules, each removal admits a documented-version-unsupported assignment')
