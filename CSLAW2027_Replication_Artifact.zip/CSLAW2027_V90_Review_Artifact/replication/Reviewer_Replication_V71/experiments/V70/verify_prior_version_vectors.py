#!/usr/bin/env python3
"""Compare V70 transcription with preserved V65 and V66 author-coded inputs."""
import ast,json
from pathlib import Path
root=Path(__file__).resolve().parent
pkg=root.parent.parent
C=json.loads((root/'input_version_vectors.json').read_text())['cases']
prior65=(pkg/'experiments/V65/source_coherence.py').read_text()
mod=ast.parse(prior65)
prior_cats=None
for node in mod.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CATS' for t in node.targets):
        prior_cats=list(ast.literal_eval(node.value));break
assert prior_cats==C[0]['labels'],(prior_cats,C[0]['labels'])
assert C[0]['official_url'] in prior65 or C[0]['official_url'] in (pkg/'experiments/V65/source_input_560.csv').read_text()
prior66=json.loads((pkg/'experiments/V66/official_contract_worlds.json').read_text())['cases']
assert len(prior66)==3
for old,new in zip(prior66,C[1:]):
    assert new['id']==old['id']
    assert new['labels']==old['labels']
    assert new['official_url']==old['official_url']
    assert [(v['id'],v['values']) for v in new['versions']]==[(v['id'],v['values']) for v in old['versions']]
print('PASS 4/4 inputs linked to preserved V65/V66 author-coded source-vector files (NOT independent legal verification)')
