# V70 · Source-coherent relation audit

This folder tests the four **documented textual version sets** already transcribed from public contracts in V65–V66. It does not identify the legally governing RADcube Attachment B or validate previously unseen amendments.

From repository root:

```sh
python3 run_v70_checks.py
```

To run only the new experiment:

```sh
cd experiments/V70
python3 source_constraint_audit.py
python3 -m unittest -v test_constraint_audit.py
python3 create_rule_witnesses.py
python3 verify_prior_version_vectors.py
```

Inputs: `input_version_vectors.json`, with official source links, original version identifiers, and narrow category/added-clause text; `verify_prior_version_vectors.py` cross-checks the transcriptions against the original V65 and V66 experiment source files.

Outputs: `results.json`, `constraints_by_contract.csv`, and `necessity_witnesses.csv`.

Proof obligations:

1. Each candidate equality or positive implication holds for all recorded version vectors.
2. The minimum-cardinality set of candidates excludes every version vector absent from the finite source-bounded collection. Exhaustive cardinality-order enumeration proves minimality **only in this restricted language**.
3. An independent SQLite expression recovers exactly the same vectors from the synthesized rules. Original version-keyed SQLite records are an equally exact baseline.
4. Removing any selected constraint introduces a vector absent from all recorded versions; a witness is printed for each constraint.
5. A synthetic even-parity set cannot be reconstructed in the pairwise primitive language. This must return `not_expressible`, with the full version-keyed relation used instead.

**Not proved:** legal priority, completeness of subsequent amendments, legal effect at a specific date, novelty of constraint synthesis as a general database algorithm, or superiority over correctly modeled SQL/OCDS. The constraint basis is an optional *audit summary*. Source and verification-grade records remain necessary for legal claims.

The optional `generate_authority_ledger.py` creates `source_authority_version_ledger.csv`, preserving each of nine source version identifiers, its official document URL, page, evidence role and legal-governance status. This metadata is **not inferred** from the Boolean constraint solver. RADcube remains precedence-unresolved and Washington pre-amendment textual comparators are labeled constructed.
