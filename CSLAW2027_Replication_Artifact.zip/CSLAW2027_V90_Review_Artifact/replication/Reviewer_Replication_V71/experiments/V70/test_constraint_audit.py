import unittest,json,sqlite3,random
from itertools import combinations
from pathlib import Path
import source_constraint_audit as sc
ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'input_version_vectors.json').read_text())['cases']
class TestSourceConstraintAudit(unittest.TestCase):
    def test_source_integrity(self):
        self.assertEqual(len(DATA),4)
        expected={'UT_RADCUBE_LS5017':{(0,)*5,(1,)*5},'ID_ALLSTEEL_PA_2023_2024':{(0,0,0),(1,1,0),(1,1,1)},'WA_MILLERKNOLL_PA_21422':{(0,0),(1,1)},'WA_LANDSCAPE_PA_15122':{(0,0),(1,1)}}
        for c in DATA:self.assertEqual({tuple(v['values']) for v in c['versions']},expected[c['id']])
    def test_exact_reconstruction_both_engines(self):
        for c in DATA:
            F={tuple(v['values']) for v in c['versions']}; k=len(c['labels'])
            with self.subTest(id=c['id']):
                got=sc.synthesize(F,k)
                self.assertEqual(got['status'],'exact')
                self.assertEqual(sc.sql_reconstruct(k,got['basis']),F)
                self.assertEqual(sc.synthesize(F,k)['basis'],got['basis'])
    def test_every_selected_rule_is_necessary(self):
        for c in DATA:
            F={tuple(v['values']) for v in c['versions']}; k=len(c['labels'])
            rules=sc.synthesize(F,k)['basis']
            for ix in range(len(rules)):
                expanded=sc.sql_reconstruct(k,rules[:ix]+rules[ix+1:])
                self.assertTrue(expanded-F, f'{c["id"]}: removing {rules[ix]} should admit at least one mixed vector')
    def test_sql_baseline_same_as_source_key_rows(self):
        for c in DATA:
            db=sqlite3.connect(':memory:')
            db.execute('CREATE TABLE source_rows (instrument TEXT, ver TEXT, atom INTEGER, value INTEGER, PRIMARY KEY(instrument,ver,atom))')
            for v in c['versions']:
                for i,x in enumerate(v['values']): db.execute('INSERT INTO source_rows VALUES (?,?,?,?)',(c['id'],v['id'],i,x))
            rows=db.execute('SELECT ver, GROUP_CONCAT(value, ",") FROM (SELECT ver,atom,value FROM source_rows ORDER BY ver,atom) GROUP BY ver').fetchall()
            got={tuple(int(ch) for ch in vals.split(',')) for _,vals in rows}
            self.assertEqual(got,{tuple(v['values']) for v in c['versions']})
    def test_pairwise_language_not_complete(self):
        parity={w for w in sc.worlds(3) if sum(w)%2==0}
        p=sc.synthesize(parity,3)
        self.assertEqual(p['status'],'not_expressible')
        self.assertTrue(p['unexcluded_worlds'])
    def test_all_boolean_queries_equivalent_as_sets(self):
        # For two-variable lineages, exhaust all 16 Boolean functions.
        for c in DATA[2:]:
            k=2; F={tuple(v['values']) for v in c['versions']}; basis=sc.synthesize(F,k)['basis']; got=sc.sql_reconstruct(k,basis)
            for truth in sc.worlds(4):
                self.assertEqual({truth[2*x[0]+x[1]] for x in F},{truth[2*x[0]+x[1]] for x in got})
        # Sample 1000 deterministic truth functions on actual five-column domain; exact set makes it sufficient for all functions.
        rng=random.Random(20261019); c=DATA[0];F={tuple(v['values']) for v in c['versions']};G=sc.sql_reconstruct(5,sc.synthesize(F,5)['basis']);U=sc.worlds(5)
        for _ in range(1000):
            f={w:rng.getrandbits(1) for w in U}
            self.assertEqual({f[w] for w in F},{f[w] for w in G})
    def test_minimal_by_oracle_on_small_cases(self):
        # Exhaust all compatible primitive subsets on n <= 3 and compare to algorithm output.
        for c in DATA[1:]:
            F={tuple(v['values']) for v in c['versions']}; k=len(c['labels']); opt=sc.synthesize(F,k)
            candidates=[name for name,fn in sc.constraints(k) if all(fn(w) for w in F)]
            minimum=None
            for n in range(len(candidates)+1):
                if any(sc.sql_reconstruct(k,list(combo))==F for combo in combinations(candidates,n)):
                    minimum=n;break
            self.assertEqual(minimum,opt['cost'])
    def test_no_unjustified_claim_of_legal_world_completeness(self):
        text=(ROOT/'input_version_vectors.json').read_text()
        self.assertIn('not legally established operative alternatives',text)

if __name__=='__main__':unittest.main(verbosity=2)
