#!/usr/bin/env python3
"""Illustrative claim-relative decision audit. All legal readings are manually supplied.
This is a reproducibility check of stated conditional cases, not an independent legal judgment.
"""
import csv,json
from pathlib import Path
B=Path(__file__).resolve().parent
records=list(csv.DictReader((B/'source_input_560.csv').open(encoding='utf-8',newline='')))
rad=sorted((r for r in records if r['supplier_slug']=='radcube-llc'),key=lambda r:r['category'])
rest=[r for r in records if r['supplier_slug']!='radcube-llc']
assert len(records)==560 and len(rad)==10 and len(rest)==550
assert len(set(r['supplier_slug'] for r in records))==56

def status(answers, positive_path, negative_path):
    """Question-scoped binary worlds; output only when documentary path is marked adequate."""
    s=set(answers)
    assert s and s<={True,False}
    if s=={True} and positive_path:return 'YES'
    if s=={False} and negative_path:return 'NO'
    return 'REVIEW'

rows=[]
for r in rad:
    cat=r['category']
    five=bool(int(r['signed_yes']))
    # Alternative ten-category schedule includes 5 DSP and 5 VAR, as transcribed in V54.
    ten=True
    assert cat.startswith(('DSP ','VAR '))
    # Both candidate schedules enumerate DSP. The VAR claims diverge.
    case=status([five,ten],positive_path=True,negative_path=False)
    assert case==('YES' if cat.startswith('DSP ') else 'REVIEW')
    rows.append({'supplier':r['supplier_slug'],'master':r['contract_id'],'category':cat,
                 'five_category_B':int(five),'ten_category_B':int(ten),
                 'status_within_two_inspected_B_schedules':case,
                 'source_grade':'Official compiled PDF; legal priority between B generations unresolved',
                 'scope':'Membership relative to the two inspected Attachment B schedules, not all later legal instruments'})
with (B/'RADcube_version_status.csv').open('w',encoding='utf-8',newline='') as fp:
    w=csv.DictWriter(fp,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)

cases=list(csv.DictReader((B/'bounded_claim_cases.csv').open(encoding='utf-8',newline='')))
outputs=[]
for c in cases:
    alt={'T':True,'F':False}
    ans=[alt[x] for x in c['admissible_answers'].split('|')]
    computed=status(ans,c['positive_path']=='1',c['negative_path']=='1')
    assert computed==c['status'], (c['claim_id'],computed,c['status'])
    outputs.append({'id':c['claim_id'],'status':computed,'source_grade':c['source_grade'],
                    'interpretation_set':c['admissible_answers'],'remaining_condition':c['remaining_condition']})
# Additional micro-properties: a consistent TRUE answer still needs a verified witness path;
# a consistent FALSE answer still needs an explicit exclusion or justified closed record.
assert status([True,True],False,False)=='REVIEW'
assert status([False,False],False,False)=='REVIEW'
assert status([False,False],False,True)=='NO'
assert status([True,False],True,True)=='REVIEW'
assert sum(x['status_within_two_inspected_B_schedules']=='YES' for x in rows)==5
assert sum(x['status_within_two_inspected_B_schedules']=='REVIEW' for x in rows)==5
assert sum(r['web_yes']!=r['signed_yes'] for r in rest)==10
assert sum(r['web_yes']=='1' and r['signed_yes']=='0' for r in rest)==1
assert sum(r['web_yes']=='0' and r['signed_yes']=='1' for r in rest)==9
out={'method':'Manually selected interpretations and source grades; arithmetic/logic checks only',
     'radcube':{'candidate_schedules':2,'common_DSP_yes':5,'contested_VAR_review':5},
     'rest':{'suppliers':55,'cells':550,'supported_ledger_differences':10,'web_only':1,'schedule_only':9},
     'bounded_cases':outputs,'microproperties':'4 checked'}
(B/'status_audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2,ensure_ascii=False))
