#!/usr/bin/env python3
"""Reproducible arithmetic on historical source-coded CSV. No independent legal reclassification."""
import csv,json
from collections import Counter
from pathlib import Path
base=Path(__file__).parent
rows=list(csv.DictReader((base/'source_input_560.csv').open(newline='', encoding='utf8')))
assert len(rows)==560
rad=[r for r in rows if r['supplier_slug']=='radcube-llc'];rest=[r for r in rows if r['supplier_slug']!='radcube-llc']
assert len(rad)==10 and len(rest)==550
assert len({r['supplier_slug'] for r in rest})==55
assert len({r['supplier_slug'] for r in rad})==1

def summary(xs):
  return dict(suppliers=len({x['supplier_slug'] for x in xs}),cells=len(xs),web_positive=sum(int(x['web_yes']) for x in xs),contract_positive=sum(int(x['signed_yes']) for x in xs),web_only=sum(x['web_yes']=='1' and x['signed_yes']=='0' for x in xs),contract_only=sum(x['web_yes']=='0' and x['signed_yes']=='1' for x in xs),differences=sum(x['web_yes']!=x['signed_yes'] for x in xs))

def cat_summary(xs,cat):
  ss=[x for x in xs if x['category']==cat]
  web={x['supplier_slug'] for x in ss if x['web_yes']=='1'}
  contract={x['supplier_slug'] for x in ss if x['signed_yes']=='1'}
  return dict(web=len(web),contract=len(contract),intersection=len(web & contract),website_only=sorted(web-contract),contract_only=sorted(contract-web))

out={'provenance':'Original source-coded V53 historical CSV; arithmetic only, not legally adjudicated grades', 'complete_original_five_category':summary(rows), 'radcube_excluded':summary(rest), 'radcube_excluded_var_saas':cat_summary(rest,'VAR SaaS'), 'radcube_excluded_discrepancy_by_supplier':dict(sorted(Counter(x['supplier_slug'] for x in rest if x['web_yes']!=x['signed_yes']).items()))}
assert out['radcube_excluded']==dict(suppliers=55,cells=550,web_positive=308,contract_positive=316,web_only=1,contract_only=9,differences=10)
assert out['radcube_excluded_var_saas']['web']==35 and out['radcube_excluded_var_saas']['contract']==36
assert out['radcube_excluded_var_saas']['contract_only']==['trace3-government-llc']
for r in rad:
    if r['category'].startswith('VAR '):r['signed_yes']='1'
out['complete_alternative_ten_category']=summary(rows)
out['complete_alternative_ten_category_var_saas']=cat_summary(rows,'VAR SaaS')
assert out['complete_alternative_ten_category']['differences']==10
assert out['complete_alternative_ten_category']['contract_positive']==326
(base/'scenario_audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,indent=2))
