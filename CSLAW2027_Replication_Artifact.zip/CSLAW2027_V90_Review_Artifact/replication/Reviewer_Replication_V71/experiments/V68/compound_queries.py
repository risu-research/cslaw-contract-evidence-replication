#!/usr/bin/env python3
"""Strong-Kleene and SQL-NULL tests of claim-relative post-judgment answers."""
from pathlib import Path
import csv,sqlite3,json
P=Path(__file__).resolve().parent
r={x['id']:x for x in csv.DictReader((P/'claims.csv').open(newline='',encoding='utf-8'))}
def neg(x):return {'YES':'NO','NO':'YES','REVIEW':'REVIEW'}[x]
def and3(a,b):
 if 'NO' in (a,b):return 'NO'
 if a==b=='YES':return 'YES'
 return 'REVIEW'
def or3(a,b):
 if 'YES' in (a,b):return 'YES'
 if a==b=='NO':return 'NO'
 return 'REVIEW'
def vals(after):
 col='after_opinion_status' if after else 'source_only_status'
 return r['L02'][col],r['L03'][col],r['L04'][col]
rows=[]
for after in (False,True):
 C,T,I=vals(after)
 labels={'CISG applies AND no binding CIETAC':and3(C,neg(T)),
         'no binding CIETAC AND binding ICC':and3(neg(T),I),
         'binding CIETAC AND binding ICC':and3(T,I),
         'no binding CIETAC OR binding ICC':or3(neg(T),I)}
 # SQLite independently supplies the same 3-valued truth tables.
 db=sqlite3.connect(':memory:')
 conv={'YES':1,'NO':0,'REVIEW':None}
 a,b,c=conv[C],conv[T],conv[I]
 sql={'CISG applies AND no binding CIETAC':'SELECT ? AND NOT ?',
      'no binding CIETAC AND binding ICC':'SELECT NOT ? AND ?',
      'binding CIETAC AND binding ICC':'SELECT ? AND ?',
      'no binding CIETAC OR binding ICC':'SELECT NOT ? OR ?'}
 args={'CISG applies AND no binding CIETAC':(a,b),
      'no binding CIETAC AND binding ICC':(b,c),
      'binding CIETAC AND binding ICC':(b,c),
      'no binding CIETAC OR binding ICC':(b,c)}
 for name,answer in labels.items():
  x=db.execute(sql[name],args[name]).fetchone()[0]
  sql_ans={None:'REVIEW',0:'NO',1:'YES'}[x]
  assert answer==sql_ans,(name,answer,sql_ans)
  rows.append({'evidence_state':'court_opinion_available' if after else 'merits_opinion_withheld','query':name,'answer':answer,'sqlite_answer':sql_ans})
 db.close()
assert [r['answer'] for r in rows[4:]]==['YES','REVIEW','NO','YES']
with (P/'compound_query_results.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('PASS: 8 compound query evaluations, strong Kleene=SQLite; post-court YES/REVIEW/NO/YES')
