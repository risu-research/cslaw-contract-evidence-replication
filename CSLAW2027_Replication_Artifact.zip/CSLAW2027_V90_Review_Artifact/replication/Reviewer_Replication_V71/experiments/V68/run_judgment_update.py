#!/usr/bin/env python3
"""Finite judicial evidence-update diagnostic, NOT an automatic case-law interpreter.

All claim predicates and judicial holdings have been manually mapped to
public judgment locators. The model tests faithful bookkeeping and bounded
three-valued status update, not a blind prediction of judicial outcomes.
"""
from pathlib import Path
import csv, itertools, json, sqlite3
ROOT=Path(__file__).resolve().parent
POS={'YES','NO','REVIEW'}

def read_claims():
    with (ROOT/'claims.csv').open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))

def decide(claim, with_opinion):
    return claim['after_opinion_status'] if with_opinion else claim['source_only_status']

def compile_report():
    rows=read_claims()
    assert len(rows)==11 and len({r['id'] for r in rows})==len(rows)
    for r in rows:
        assert r['source_only_status'] in POS and r['after_opinion_status'] in POS
        assert r['opinion_locator'] and r['note']
        if r['kind']=='TEXT':
            assert r['source_only_status']==r['after_opinion_status']
    data=[{'id':r['id'],'kind':r['kind'],'question':r['question'],
           'source_only':decide(r,False),'opinion_available':decide(r,True),
           'opinion_locator':r['opinion_locator'],'legal_scope':r['note']} for r in rows]
    with (ROOT/'status_crosswalk.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    legal=[r for r in data if r['kind']=='LEGAL'];textual=[r for r in data if r['kind']=='TEXT']
    assert len(legal)==7 and len(textual)==4
    assert sum(r['opinion_available']!='REVIEW' for r in legal)==3
    assert sum(r['opinion_available']=='REVIEW' for r in legal)==4
    assert all(r['source_only']=='REVIEW' for r in legal)
    # Three finite diagnostic booleans are distinct from lawfully admissible worlds.
    # CISG-applies-to-CIETAC, CIETAC-agreement, ICC-agreement.
    all_abstract=[{'cisg_for_cietac':int(c), 'cietac_binding':int(t),'icc_binding':int(i)}
                  for c,t,i in itertools.product((0,1),repeat=3)]
    held=[w for w in all_abstract if w['cisg_for_cietac']==1 and w['cietac_binding']==0]
    assert len(all_abstract)==8 and len(held)==2
    # Textual alternatives stay present after the judicial opinion.
    textual_rows=[{'position':'English export-contract text','cisg_optout_printed':0,'cietac_clause_printed':0},
                  {'position':'Chinese export-contract text','cisg_optout_printed':1,'cietac_clause_printed':1}]
    naive=list(itertools.product((0,1),repeat=2))
    assert len(textual_rows)==2 and len(naive)==4
    assert {(t['cisg_optout_printed'],t['cietac_clause_printed']) for t in textual_rows}=={(0,0),(1,1)}
    # Deny inference via invalid rules: competing text is not binding law.
    assert next(r['opinion_available'] for r in data if r['id']=='T03')=='YES'
    assert next(r['opinion_available'] for r in data if r['id']=='L03')=='NO'
    assert next(r['opinion_available'] for r in data if r['id']=='T04')=='YES'
    assert next(r['opinion_available'] for r in data if r['id']=='L04')=='REVIEW'
    report={'scope':'Retrospective opinion-withholding diagnostic; no blind court-outcome prediction',
            'case':'2022 NY Slip Op 50041(U), Index 907022-21, January 25 2022',
            'source_only':'Court-described text facts disclosed, merits holdings hidden (retrospective construction)',
            'opinion_available':'Add explicit opinion holdings; other matters remain REVIEW',
            'claims_count':len(rows),'text_presence_claims':len(textual),'legal_effect_claims':len(legal),
            'legal_resolved_by_opinion':3,'legal_left_review':4,
            'two_source_textual_positions':textual_rows,
            'naive_independent_text_positions':len(naive),'extra_mixed_textual_positions':2,
            'abstract_boolean_outcomes_before':len(all_abstract),
            'abstract_boolean_outcomes_after_holdings':len(held),
            'abstract_post_outcomes':held,
            'warning':'Abstract Boolean assignments are a didactic completion space, NOT judicially admissible legal worlds; source text positions are not legally admissible alternatives.'}
    (ROOT/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    # Independent SQL implementation of filtering this finite three-claim cube.
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE worlds (cisg INT, cietac INT, icc INT)')
    db.executemany('INSERT INTO worlds VALUES (:cisg_for_cietac,:cietac_binding,:icc_binding)',all_abstract)
    old=db.execute('SELECT COUNT(*) FROM worlds').fetchone()[0]
    new=db.execute('SELECT COUNT(*) FROM worlds WHERE cisg=1 AND cietac=0').fetchone()[0]
    vals=db.execute('SELECT DISTINCT icc FROM worlds WHERE cisg=1 AND cietac=0 ORDER BY icc').fetchall()
    assert old==8 and new==2 and [v[0] for v in vals]==[0,1]
    db.close()
    return report
if __name__=='__main__':
    result=compile_report()
    print('PASS judicial-source ledger:',result['claims_count'],'claims; opinion resolves',result['legal_resolved_by_opinion'],
          'legal claims; leaves',result['legal_left_review'],'for REVIEW; SQL 8->2; textual alternatives remain recorded')
