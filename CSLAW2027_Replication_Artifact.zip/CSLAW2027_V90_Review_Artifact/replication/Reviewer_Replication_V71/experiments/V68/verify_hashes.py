#!/usr/bin/env python3
from pathlib import Path
import hashlib
P=Path(__file__).resolve().parent
manifest=P/'SHA256_MANIFEST.tsv'
assert manifest.exists()
entries=[]
for line in manifest.read_text(encoding='utf-8').splitlines():
 if not line.strip():continue
 hash_,rel=line.split('\t',1)
 path=P/rel
 assert path.is_file(),f'MISSING {rel}'
 actual=hashlib.sha256(path.read_bytes()).hexdigest()
 assert hash_==actual,f'CHANGED {rel}'
 entries.append(rel)
assert len(entries)==len(set(entries))
print(f'PASS {len(entries)}/{len(entries)} protected files SHA-256')
