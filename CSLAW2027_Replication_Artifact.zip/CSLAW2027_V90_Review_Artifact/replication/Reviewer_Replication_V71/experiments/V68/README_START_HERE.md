# V68 — Judicial source-update diagnostic (Rusi, New York 2022)

Research companion to CSLAW V66. **It does not replace or edit V66.**

## Goal
Using the officially published January 25, 2022 New York decision in *Matter of New York State Department of Health (Rusi Technology Co., Ltd.)*, compare what claim-specific evidence can warrant with judicial merits determinations withheld, and what becomes warranted when the court's limited holdings are included. A court-derived retrospective evaluation, **not a prospective case-outcome predictor**.

Official judicial source: https://www.nycourts.gov/reporter/3dseries/2022/2022_50041.htm

## Reproduction

Run with Python 3 standard library only:

```
python3 run_judgment_update.py
python3 compound_queries.py
python3 -m unittest -v test_judgment_update.py
python3 verify_hashes.py
```

- `claims.csv`: eleven claim-level legal/content labels and pinpoint references to opinion.
- `official_source_index.csv`: authoritative judgment, prior instruments as described by court, secondary index.
- `status_crosswalk.csv`: resulting legal statuses with and without the judicial merits source.
- `compound_query_results.csv`: four conjunction/disjunction queries, before and after; SQLite check.
- `results.json`: mathematical counts, explicitly marks didactic hypothetical Boolean assignments as **not legal worlds**.
- `V68_JUDICIAL_UPDATE_AUDIT_KO.md`: detailed source-grade and legal-boundary notes, manuscript-inclusion decision.
- `V68_OPTIONAL_APPENDIX.tex`: **not included in V66**; a tightly bounded optional paragraph.
- `V68_REFERENCE_SNIPPET.tex`: optional direct official case citation.

### Boundary that must be preserved

A printed Chinese clause is present even when the court refuses to enforce it. The court denied binding CIETAC arbitration and held that the CISG was not effectively excluded for the agreement analysis. It **expressly left ICC arbitration binding effect unresolved** in footnote 6. The judgment does not pronounce the English text universally controlling every contractual question.

The three disposition labels come from a manual reading of a public court opinion, not autonomous legal reasoning or a blind holdout. The 2020 signed underlying exhibits were described by the court; their original binary files were not independently fetched. The with-held-opinion state is an intentional **retrospective evidence ablation**, not a preserved contemporaneous 2022 researcher snapshot. The 8-to-2 Boolean count is a didactic completion exercise, never a count of legally admissible alternative contracts.
