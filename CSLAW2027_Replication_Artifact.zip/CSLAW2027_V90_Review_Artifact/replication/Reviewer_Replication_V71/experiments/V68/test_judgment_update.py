#!/usr/bin/env python3
from pathlib import Path
import unittest,csv,json,itertools,sqlite3
import run_judgment_update as m
P=Path(__file__).resolve().parent
class JudicialEvidenceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.report=m.compile_report();cls.rows={x['id']:x for x in m.read_claims()}
 def s(self,k,op=True):return m.decide(self.rows[k],op)
 def test_court_legal_cisg_exclusion(self):self.assertEqual(self.s('L01'),'NO')
 def test_court_limited_cisg_use(self):self.assertEqual(self.s('L02'),'YES')
 def test_court_cietac_rejection(self):self.assertEqual(self.s('L03'),'NO')
 def test_icc_remains_undecided(self):self.assertEqual(self.s('L04'),'REVIEW')
 def test_chinese_general_priority_not_decided(self):self.assertEqual(self.s('L05'),'REVIEW')
 def test_po_general_legal_effect_not_decided(self):self.assertEqual(self.s('L06'),'REVIEW')
 def test_no_arbitration_anywhere_not_inferred(self):self.assertEqual(self.s('L07'),'REVIEW')
 def test_pre_merits_all_seven_review(self):self.assertTrue(all(m.decide(x,False)=='REVIEW' for x in self.rows.values() if x['kind']=='LEGAL'))
 def test_bilingual_priority_text_both_remain(self):self.assertEqual((self.s('T01'),self.s('T02')),('YES','YES'))
 def test_chinese_text_survives_legal_rejection(self):self.assertEqual((self.s('T03'),self.s('L03')),('YES','NO'))
 def test_english_chinese_text_not_four_worlds(self):self.assertEqual(self.report['two_source_textual_positions'][0]['cisg_optout_printed'],0);self.assertEqual(self.report['extra_mixed_textual_positions'],2)
 def test_abstract_post_contains_icc_both(self):self.assertEqual({r['icc_binding'] for r in self.report['abstract_post_outcomes']},{0,1})
 def test_sql_cube(self):self.assertEqual((self.report['abstract_boolean_outcomes_before'],self.report['abstract_boolean_outcomes_after_holdings']),(8,2))
 def test_outcome_source_grade_not_prediction(self):self.assertIn('no blind',self.report['scope'])
 def test_disposition_not_global_contract_rule(self):self.assertEqual(self.s('L05'),'REVIEW')
 def test_textual_facts_constant_under_update(self):self.assertTrue(all(m.decide(x,False)==m.decide(x,True) for x in self.rows.values() if x['kind']=='TEXT'))
 def test_legal_effect_only_holdings_change(self):self.assertEqual({k for k,v in self.rows.items() if m.decide(v,False)!=m.decide(v,True)},{'L01','L02','L03'})
 def test_no_post_opinion_icc_promotion(self):self.assertEqual(self.s('L04'),'REVIEW')
 def test_gold_record_locators_present(self):self.assertTrue(all(v['opinion_locator'] for v in self.rows.values()))
if __name__=='__main__':unittest.main(verbosity=2)
