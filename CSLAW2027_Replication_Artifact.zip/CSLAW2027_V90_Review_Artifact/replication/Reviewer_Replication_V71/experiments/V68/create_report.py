from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, KeepTogether, PageBreak, HRFlowable
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pathlib import Path
import csv,html
P=Path(__file__).resolve().parent
pdf=P/'V68_JUDICIAL_UPDATE_FINDINGS.pdf'
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
if Path(font).exists():pdfmetrics.registerFont(TTFont('DejaVu',font)); base='DejaVu'
else:base='Helvetica'
navy=colors.HexColor('#19334b');gray=colors.HexColor('#5c6773');dark=colors.HexColor('#1f2937')
s=getSampleStyleSheet()
s.add(ParagraphStyle(name='DocTitleX',fontName=base,fontSize=18,leading=24,textColor=navy,spaceAfter=10))
s.add(ParagraphStyle(name='HeadingX',fontName=base,fontSize=11.5,leading=17,textColor=navy,spaceBefore=13,spaceAfter=6))
s.add(ParagraphStyle(name='BodyX',fontName=base,fontSize=8.8,leading=14,spaceAfter=7,textColor=dark))
s.add(ParagraphStyle(name='SmallX',fontName=base,fontSize=7.45,leading=11,spaceAfter=4,textColor=dark))
s.add(ParagraphStyle(name='CaptionX',fontName=base,fontSize=7.3,leading=11,textColor=gray,spaceAfter=7))

def para(t,style='BodyX'):return Paragraph(t,s[style])
rows={r['id']:r for r in csv.DictReader((P/'claims.csv').open(newline='',encoding='utf-8'))}
story=[]
story.append(para('Judicial Evidence Update: A Government Purchase in New York','DocTitleX'))
story.append(para('Research companion to CSLAW V66 | 19 October 2026 | Official judicial decision of 25 January 2022','CaptionX'))
story.append(para('<b>Submission decision.</b> Keep the V66 main paper unchanged. This is a source-anchored external diagnostic for bounded legal conclusions and abstention, not a new adjudication algorithm, new theorem, or blind case-outcome prediction.','BodyX'))
story.append(para('Case and materials','HeadingX'))
story.append(para('In <i>Matter of New York State Department of Health (Rusi Technology Co., Ltd.)</i>, 2022 NY Slip Op 50041(U), No. 907022-21 (N.Y. Sup. Ct., Albany County, Jan. 25, 2022), a government purchase of two million KN-95 masks produced divergent English and Chinese contract clauses. The purchase order also included an ICC arbitration provision. The court applied CISG principles, rejected a binding CIETAC agreement, and did not decide whether the ICC provision was binding.'))
story.append(para('Source: New York State Law Reporting Bureau, https://www.nycourts.gov/reporter/3dseries/2022/2022_50041.htm (Background, Analysis A and B, footnote 6).','SmallX'))
story.append(para('Claim-specific determinations','HeadingX'))
ids=['L01','L02','L03','L04','L05','L06','L07']
short={'L01':'Effective mutual CISG exclusion','L02':'CISG applies to CIETAC formation issue','L03':'Binding CIETAC agreement','L04':'Binding ICC agreement','L05':'Chinese text globally controls','L06':'PO New York law globally controls','L07':'No arbitral agreement of any kind'}
header=[para('Legal proposition','SmallX'),para('Withheld merits','SmallX'),para('Opinion included','SmallX')]
tab=[header]
for k in ids:
 r=rows[k]
 tab.append([para(html.escape(short[k]),'SmallX'),para(r['source_only_status'],'SmallX'),para(r['after_opinion_status'],'SmallX')])
t=Table(tab,colWidths=[310,93,93],repeatRows=1,hAlign='LEFT')
t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e9eff3')),('LINEBELOW',(0,0),(-1,0),.75,colors.HexColor('#9baebd')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d8e0e4')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
story.append(t);story.append(Spacer(1,9))
story.append(para('<b>Outcome:</b> three of seven claim-specific legal-effect questions become determinate; four remain for review. Four distinct propositions about the existence of written terms remain true in both conditions. None of the remaining reviews may be promoted from the mere presence of the disputed clauses.','SmallX'))
story.append(para('Why the statuses differ','HeadingX'))
story.append(para('The court found no sufficiently clear mutual intention to exclude the CISG and no express, unequivocal agreement to arbitrate before CIETAC. This finding does not erase the Chinese-language CIETAC clause as a matter of document content. Likewise, the court did not reach the binding effect of the Purchase Order Appendix B ICC clause (footnote 6). The decision cannot be interpreted as an all-purpose holding that one language or the purchase-order terms govern every issue.'))
story.append(para('Compound questions under strong Kleene logic','HeadingX'))
shortqs={'CISG applies AND no binding CIETAC':'CISG applies AND CIETAC does not bind','no binding CIETAC AND binding ICC':'No CIETAC AND binding ICC','binding CIETAC AND binding ICC':'Binding CIETAC AND binding ICC','no binding CIETAC OR binding ICC':'No CIETAC OR binding ICC'}
xs=list(csv.DictReader((P/'compound_query_results.csv').open(newline='',encoding='utf-8')))
qnames=list(shortqs)
xt=[[para('Compound proposition','SmallX'),para('Withheld','SmallX'),para('Opinion','SmallX')]]
for q in qnames:
 a=next(x['answer'] for x in xs if x['query']==q and x['evidence_state']=='merits_opinion_withheld')
 b=next(x['answer'] for x in xs if x['query']==q and x['evidence_state']=='court_opinion_available')
 xt.append([para(shortqs[q],'SmallX'),para(a,'SmallX'),para(b,'SmallX')])
x=Table(xt,colWidths=[310,93,93],repeatRows=1,hAlign='LEFT');x.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e9eff3')),('LINEBELOW',(0,0),(-1,-1),.25,colors.HexColor('#d8e0e4')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]));story.append(x)
story.append(Spacer(1,6))
story.append(para('These eight evaluations agree with SQLite three-valued Boolean expressions. Even with an unresolved ICC clause, a conjunction that requires binding CIETAC is definitively false; a conjunction requiring binding ICC remains unresolved.','SmallX'))
story.append(para('Formal scope and empirical limits','HeadingX'))
story.append(para('The comparison is <b>retrospective withholding of the opinion’s merits holdings</b>. It is not a time-stamped snapshot from January 24, 2022, nor a blinded legal prediction. The documentary clauses are known here from the court’s published description, not from newly downloaded binary copies of the signed contract, certified translation, or purchase-order exhibits. The legal outcome labels were manually coded from that opinion.'))
story.append(para('The English and Chinese <b>textual</b> clause bundles have two printed forms, versus four if two content flags are falsely treated as independent. These are not legally admissible competing-world counts. As a separate didactic three-variable Boolean completion, eight unconstrained assignments reduce to two when the court’s CISG and CIETAC holdings are imposed; the ICC variable remains open. This calculation illustrates partial constraint propagation and does not count genuine court-permitted alternatives.'))
story.append(para('<b>Assessment:</b> valuable external judicial anchor for content-versus-legal-effect and correct abstention. One retrospective adjudicated case and a manually curated rule ledger do not constitute a new algorithmic or theoretical class jump. Preserve as a standalone study; the optional appendix paragraph is provided separately and is not incorporated into the V66 paper.','BodyX'))
story.append(para('Replication: Python 3 standard library. Run run_judgment_update.py, compound_queries.py, test_judgment_update.py and verify_hashes.py. See claims.csv and official_source_index.csv for exact mappings.','CaptionX'))

def footer(canvas,doc):
 canvas.setFont(base,7);canvas.setFillColor(gray)
 canvas.drawString(49,28,'V68 • Judicial source update • Companion research note')
 canvas.drawRightString(545,28,str(doc.page))
SimpleDocTemplate(str(pdf),pagesize=(595.28,841.89),leftMargin=49,rightMargin=49,topMargin=47,bottomMargin=49,title='V68 Judicial Evidence Update - NYDOH v Rusi').build(story,onFirstPage=footer,onLaterPages=footer)
print(pdf, pdf.stat().st_size)
