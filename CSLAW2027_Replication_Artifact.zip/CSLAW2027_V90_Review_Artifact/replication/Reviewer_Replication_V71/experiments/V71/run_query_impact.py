#!/usr/bin/env python3
"""Question-relative shortlist audit over two published RADcube schedules.

This is an executable counterfactual for tag-keyed lookup on archived, author-coded
source rows, NOT a measurement of NASPO's actual search engine or purchase rights.
No legal governing schedule is selected. Depends on frozen V59/V55 rows and V70
version vectors. Python standard library only.
"""
from collections import defaultdict, Counter
from pathlib import Path
import csv, json, hashlib, sqlite3

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
INP=ROOT/'experiments/V55/source_input_560.csv'
VECTORS=ROOT/'experiments/V70/input_version_vectors.json'
PROOF=ROOT/'experiments/V59/replication/ten_discrepancies_rechecked.csv'

def rows(path):
    with path.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def emit(path,records,fields):
    with (HERE/path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(records)

def main():
    raw=rows(INP)
    assert len(raw)==560 and len({(r['supplier_slug'],r['category']) for r in raw})==560
    cats=sorted({r['category'] for r in raw}); assert len(cats)==10
    providers={r['supplier_slug'] for r in raw};assert len(providers)==56
    vectors=json.loads(VECTORS.read_text())['cases']
    rad_case=next(c for c in vectors if c['id']=='UT_RADCUBE_LS5017')
    versionsets={v['id']:dict(zip(rad_case['labels'],map(int,v['values']))) for v in rad_case['versions']}
    assert len(versionsets)==2
    assert set(versionsets.values().__iter__().__next__())==set(c for c in cats if c.startswith('VAR '))
    assert {tuple(v.values()) for v in versionsets.values()}=={(0,0,0,0,0),(1,1,1,1,1)}
    assert set(x['supplier_slug'] for x in raw if x['supplier_slug'].startswith('radcube'))=={'radcube-llc'}
    per_category=[];worldrows=[];witness=[];proof=rows(PROOF)
    assert len(proof)==10 and {r['case_id'] for r in proof}=={f'D{i:02}' for i in range(1,11)}
    assert all(r['verification']=='WEB_STRUCTURED_TEXT_AND_PDF_VISUAL_VERIFIED' for r in proof)
    badpair={(r['supplier_slug'],r['category']) for r in proof}
    assert len(badpair)==10
    delta_global=set()
    for cat in cats:
        s=[r for r in raw if r['category']==cat]
        web={r['supplier_slug'] for r in s if r['web_yes']=='1'}
        sources={}
        for world,state in versionsets.items():
            sources[world]={r['supplier_slug'] for r in s if (state[cat] if r['supplier_slug']=='radcube-llc' and cat in state else int(r['signed_yes']))}
        certain=set.intersection(*sources.values());possible=set.union(*sources.values())
        always_missing=certain-web
        never_in_source=web-possible
        conditional=possible-certain
        assert len(conditional)==(1 if cat.startswith('VAR ') else 0)
        assert all(x=='radcube-llc' for x in conditional)
        assert all((x,cat) in badpair for x in always_missing|never_in_source)
        for x in always_missing|never_in_source:delta_global.add((x,cat))
        stable_mismatch=bool(always_missing or never_in_source)
        per_category.append(dict(category=cat,web_count=len(web),certain_source_count=len(certain),possible_source_count=len(possible),certain_missing_from_web=len(always_missing),web_entries_excluded_by_both_sources=len(never_in_source),conditional_source_members=len(conditional),guaranteed_membership_mismatch=int(stable_mismatch),min_required_tag_corrections=len(always_missing)+len(never_in_source),max_required_tag_corrections=len(always_missing)+len(never_in_source)+len(conditional),certain_missing_ids='|'.join(sorted(always_missing)),web_excluded_ids='|'.join(sorted(never_in_source)),conditional_ids='|'.join(sorted(conditional))))
        for world,source in sources.items():
            worldrows.append(dict(category=cat,world=world,web_count=len(web),source_count=len(source),web_only=len(web-source),source_only=len(source-web),overlap=len(web&source),symmetric_difference=len(web^source),equal_counts_but_different_membership=int(len(web)==len(source) and web!=source),web_only_ids='|'.join(sorted(web-source)),source_only_ids='|'.join(sorted(source-web))))
        for name, group in [('source_confirmed_but_unlisted',always_missing),('structured_web_listed_but_not_in_either_schedule',never_in_source)]:
            for slug in sorted(group):
                p=next((d for d in proof if d['supplier_slug']==slug and d['category']==cat))
                witness.append({**{'query_category':cat,'finding_type':name},**p})
    assert len(delta_global)==10
    assert len(witness)==10
    assert sum(int(x['guaranteed_membership_mismatch']) for x in per_category)==7
    assert sum(int(x['certain_missing_from_web']) for x in per_category)==9
    assert sum(int(x['web_entries_excluded_by_both_sources']) for x in per_category)==1
    assert sum(int(x['conditional_source_members']) for x in per_category)==5
    assert sum(int(x['min_required_tag_corrections']) for x in per_category)==10
    assert sum(int(x['max_required_tag_corrections']) for x in per_category)==15
    x=next(c for c in per_category if c['category']=='VAR SaaS');assert (int(x['web_count']),int(x['certain_source_count']),int(x['possible_source_count']))==(36,36,37)
    assert sum(int(x['equal_counts_but_different_membership']) for x in worldrows)>=1
    assert all(sum(int(r['symmetric_difference']) for r in worldrows if r['world']==world)==(10 if sum(state.values())==5 else 15) for world,state in versionsets.items())
    # Independent relational implementation of 2 worlds in in-memory SQLite;
    # compare category-level source positives and symmetric differences.
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE lookup (category TEXT, supplier TEXT, web INTEGER, version TEXT, signed INTEGER)')
    db.executemany('INSERT INTO lookup VALUES (?,?,?,?,?)',[(r['category'],r['supplier_slug'],int(r['web_yes']),world, (state[r['category']] if r['supplier_slug']=='radcube-llc' and r['category'] in state else int(r['signed_yes']))) for r in raw for world,state in versionsets.items()])
    sql=db.execute('SELECT category, version, SUM(web), SUM(signed), SUM(web<>signed), SUM(web=1 AND signed=0), SUM(web=0 AND signed=1) FROM lookup GROUP BY category, version').fetchall()
    actual={(r['category'],r['world']):r for r in worldrows}
    assert len(sql)==20
    for category,world,w,s,d,wo,so in sql:
        r=actual[(category,world)]
        assert [w,s,d,wo,so]==[int(r[k]) for k in ('web_count','source_count','symmetric_difference','web_only','source_only')]
    emit('QUERY_ROBUST_SUMMARY.csv',per_category,list(per_category[0]))
    emit('QUERY_TWO_WORLD_OUTCOMES.csv',worldrows,list(worldrows[0]))
    emit('QUERY_TEN_SOURCE_WITNESSES.csv',witness,list(witness[0]))
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [INP,VECTORS,PROOF]}
    result={'scope':'author-coded October 17 2026 supplier-profile frame; two inspected RADcube source readings; October 19 source recheck in frozen V59 proof',
            'queries':10,'supplier_category_cells':560,'source_worlds':2,'categories_with_guaranteed_member_difference':7,'guaranteed_missing_listings':9,'guaranteed_extra_listings':1,'conditional_radcube_memberships':5,'world_dependent_total_edit_range':[10,15],'web_total_positives':318,
            'VAR_SaaS':{'web':36,'certain_source':36,'possible_source':37,'web_missing_certain':['trace3-government-llc'],'web_conditional':['radcube-llc'],'web_and_certain_overlap':35},
            'input_sha256':hashes,'sql_group_checks':len(sql),'note':'These are consequences of explicitly modeled category lookup, not observed live search results, purchasing law violations, or legal selection among the two RADcube schedules.'}
    (HERE/'QUERY_IMPACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
