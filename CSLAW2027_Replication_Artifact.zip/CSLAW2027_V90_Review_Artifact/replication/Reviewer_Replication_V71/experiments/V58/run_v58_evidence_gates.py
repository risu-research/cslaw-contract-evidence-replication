#!/usr/bin/env python3
"""Re-evaluate *verification grade*, not legal execution, for frozen V35 18-query subset.
Source-ledger roles and results were manually coded by the same author in V35.
No PDF parsing, new signature inspection, or independent legal verification occurs here.
"""
import csv, json
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
source=json.loads((HERE/'V35_SOURCE_LEDGER_FROZEN.json').read_text())
bench=json.loads((HERE/'V35_BENCHMARK_FROZEN.json').read_text())
assert bench['total_queries']==66
records={x['id']: x for x in source['records']}
rows=[]
for item in bench['query_outcomes']:
    if not item['id'].startswith(('MFP.amend.','MRO.renew.')):
        continue
    kind=item['answer']
    witnesses=item['witnesses']
    grade='NONE'
    link='NO_CONFIRMED_TYPED_MATCH'
    strict='REVIEW'
    inspected='NO'
    if kind in {'DIRECT_VISUAL_WITNESS','INDEXED_TEXT_WITNESS'}:
        assert len(witnesses)==2,(item['id'],witnesses)
        d=records[witnesses[0]]; p=records[witnesses[1]]
        assert d['role']=='SIGNED_LOCAL_AMENDMENT' and p['role']=='SIGNED_PA'
        assert d['parent']==p['id'] and d['vendor']==p['vendor'] and d['master']==p['master']
        assert d['program']==p['program']
        assert (d['topic']=='pay_equality_warranty' if item['family']=='MFP' else d['topic']=='renewal_executed')
        assert item['id'].split('.')[2]==d['vendor']
        grade=d['grade']
        if kind=='DIRECT_VISUAL_WITNESS':
            assert grade=='VISUAL'
            link='MATCHED_AND_PRIOR_SIGNED_PAGE_INSPECTED'
            strict='YES_PRIOR_VISUAL_EVIDENCE'
            inspected='YES_PRIOR_AUDIT'
        else:
            assert kind=='INDEXED_TEXT_WITNESS' and grade=='INDEXED_ONLY'
            link='MATCHED_INDEXED_REFERENCE_ONLY'
            strict='REVIEW_SIGNATURE_NOT_INDEPENDENTLY_INSPECTED'
            inspected='NO'
    rows.append({
       'query_id':item['id'],'historical_v35_class':kind,'witness_ids':';'.join(witnesses),
       'source_grade':grade,'typed_link':link,'signed_execution_question':strict,
       'signature_image_inspected':inspected,
       'note':'Historical source-coded judgement, NOT new primary-source legal verification'
    })
assert len(rows)==18, len(rows)
counts=Counter(r['typed_link'] for r in rows)
assert counts['MATCHED_AND_PRIOR_SIGNED_PAGE_INSPECTED']==4
assert counts['MATCHED_INDEXED_REFERENCE_ONLY']==2
assert counts['NO_CONFIRMED_TYPED_MATCH']==12
assert {r['query_id'] for r in rows if r['typed_link']=='MATCHED_INDEXED_REFERENCE_ONLY'}=={
    'MRO.renew.Global.2026-06-25','MRO.renew.Global.2026-09-01'
}
out=HERE/'v58_evidence_tiers_18.csv'
with out.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={
 'frozen_evaluation_queries':len(rows),'dated_typed_matches':6,
 'matches_with_signature_pages_inspected_in_prior_work':4,
 'matches_based_on_indexed_text_only':2,
 'florida_bilateral_signatures_independently_inspected_for_renewal':0,
 'stricter_signed_execution_yes':4,
 'stricter_signed_execution_review_among_typed_matches':2,
 'version':'V58 grade-only reclassification of V35 frozen source-coded 18-query panel',
 'limitations':[
  'The prior V35 manual source-grade ledger is imported unchanged.',
  'VISUAL records prior visual inspection; no new independent signature authentication.',
  'INDEXED_ONLY supports a bounded index-report claim, not verified bilateral execution.',
  'No empirical legal accuracy, holdout generalization, or production-system error rate follows.'
 ]}
(HERE/'v58_evidence_tiers_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
