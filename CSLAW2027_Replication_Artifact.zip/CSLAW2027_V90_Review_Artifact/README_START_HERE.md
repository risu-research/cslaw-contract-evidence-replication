# Contract Versions and Claim-Specific Evidence in Public Procurement

Replication materials for the ACM CS&LAW 2027 submission.

The artifact brings together the recorded procurement observations, source-document locators, SQL cross-checks, and executable tests of contract-version coherence. It also includes a query evaluator that retains whole version records and produces checkable counterexamples when independent attribute values admit additional combinations.

## Run the checks

Extract the archive, open this directory, and run:

```bash
python3 RUN_REVIEW.py
```

Python 3.10 or later is sufficient; no packages or network connection are required. To run the additional experiments and tests:

```bash
python3 RUN_REVIEW.py --full
```

The script writes detailed logs to `verification_output/`. The version-model certificates appear in `proof_engine/proofs/` and can also be checked separately:

```bash
python3 proof_engine/verify_certificates.py
```

To evaluate another finite collection of document versions, follow the input structure in `proof_engine/source_vectors.json`:

```bash
python3 proof_engine/version_preservation.py --input YOUR_CASES.json --output YOUR_RESULTS
```

## Find the evidence

- `RESULTS_AT_A_GLANCE.md` connects the paper's principal numbers to executable checks.
- `REVIEWER_EVIDENCE_MAP.md` gives the source page and public contract URL for each of the ten settled supplier-category differences.
- `REVIEWER_RESULT_MAP.md` locates the original data and scripts behind each empirical result.
- `proof_engine/` contains the version-preserving evaluator, generated certificates, independent certificate verifier, and model tests.
- `replication/` contains the archived inputs and checks used to develop the paper's empirical results.

The scripts reproduce calculations from recorded observations. Source pages provide the corresponding documentary evidence, and the paper explains how those records bear on particular legal questions.
