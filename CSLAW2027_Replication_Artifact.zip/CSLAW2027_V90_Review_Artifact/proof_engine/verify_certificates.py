#!/usr/bin/env python3
"""Independent proof checker: reads emitted JSON, with no imports from proof producer."""
import itertools, json, pathlib, sys, hashlib
ROOT=pathlib.Path(__file__).resolve().parent

def test(q,v):
    t=q['type']
    if t=='all_equal': return all(x==v[0] for x in v)
    if t=='exactly':return sum(v)==q['k']
    if t=='at_least':return sum(v)>=q['k']
    if t=='equal':return v[q['i']]==v[q['j']]
    if t=='implies':return not v[q['i']] or bool(v[q['j']])
    if t=='atom':return v[q['i']]==1
    if t=='and':return v[q['i']]*v[q['j']]==1
    if t=='xor':return v[q['i']]!=v[q['j']]
    raise AssertionError(t)

def answer(q,vs):
    truth=[test(q,v) for v in vs]
    if all(truth):return 'YES'
    if not any(truth):return 'NO'
    return 'UNKNOWN'

def accepts(diagram,v):
    nodes=diagram['nodes']; cur=diagram['root']; n=len(v);steps=0;last=-1
    while cur not in (0,1):
        node=nodes[str(cur)];i=node['atom'];assert last<i<n
        last=i;steps+=1;assert steps<=n
        cur=node['high'] if v[i] else node['low']
    return cur==1

def main():
    cases=json.loads((ROOT/'source_vectors.json').read_text())['cases']
    total=0
    for case in cases:
        cert=json.loads((ROOT/'proofs'/(case['id']+'_CERTIFICATE.json')).read_text())
        rows={tuple(v['values']) for v in case['versions']}
        n=len(case['labels'])
        universe=set(itertools.product((0,1),repeat=n))
        reconstructed={v for v in universe if accepts(cert['bdd'],v)}
        assert reconstructed==rows,case['id']
        hull=set(itertools.product(*[sorted({v[i] for v in rows}) for i in range(n)]))
        assert len(hull)==cert['marginal_vectors']
        assert len(hull-rows)==cert['spurious_mixed_vectors']
        assert cert['relation_sha256']==hashlib.sha256(json.dumps(sorted(rows),separators=(',',':')).encode()).hexdigest()
        provenance=cert['source_versions_by_vector']
        for v in case['versions']:
            assert v['id'] in provenance[''.join(str(x) for x in v['values'])]
        for c in cert['query_certificates']:
            q=c['query'];w=tuple(c['marginal_counterexample'])
            assert w in hull and w not in rows
            assert answer(q,rows)==c['coherent_answer']
            assert answer(q,hull)==c['marginal_answer']=='UNKNOWN'
            assert c['coherent_answer'] in ('YES','NO')
            assert test(q,w)!=(c['coherent_answer']=='YES')
            total+=1
        print('PASS',case['id'],'exact relation and',len(cert['query_certificates']),'checked witness certificates')
    summary=json.loads((ROOT/'proofs/SUMMARY.json').read_text())
    assert total==summary['answers_lost_by_projection']==64
    assert summary['questions_checked']==119
    print('PASS',total,'independently checked certificates; all four finite relations exact')

if __name__=='__main__':main()
