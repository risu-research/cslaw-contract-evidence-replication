#!/usr/bin/env python3
"""Version-coherent evidence model with certified finite query judgments.

The universe is a Boolean vector of named, document-observed attributes.
A source reading is an observed vector, *not* a legal-authority decision.

Runs entirely with the Python standard library and never executes document text.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product, combinations
import hashlib
import json
from pathlib import Path
import sqlite3
from typing import Any

MAX_ATOMS = 14


def all_vectors(n):
    return list(product((0, 1), repeat=n))


def validate_case(case):
    labels = case.get('labels')
    versions = case.get('versions')
    if not isinstance(labels, list) or not 1 <= len(labels) <= MAX_ATOMS or not all(isinstance(x, str) and x for x in labels) or len(set(labels)) != len(labels):
        raise ValueError('Unique, nonempty labels required (1..14)')
    if not isinstance(versions, list) or not versions:
        raise ValueError('Nonempty version list required')
    if len(versions) > 200:
        raise ValueError('Too many source versions for reviewer-scale check')
    seen_ids=set()
    for version in versions:
        if not isinstance(version, dict) or not isinstance(version.get('id'), str) or not version['id'] or version['id'] in seen_ids:
            raise ValueError('Each source version must have a unique id')
        seen_ids.add(version['id'])
        v = version.get('values')
        if not isinstance(v, list) or len(v) != len(labels) or any(type(i) is not int or i not in (0,1) for i in v):
            raise ValueError('Version vectors must contain exact binary integer values')
    return tuple(tuple(version['values']) for version in versions)


class ROBDD:
    """Reduced ordered decision diagram for characteristic function of a finite relation."""
    def __init__(self, n, versions):
        self.n=n
        self.unique={}
        self.nodes={}
        self.next_id=2
        self.root=self._build(0, frozenset(versions))

    def _build(self, idx, remaining):
        if not remaining:return 0
        if idx==self.n:return 1
        left=self._build(idx+1, frozenset(x for x in remaining if x[idx]==0))
        right=self._build(idx+1, frozenset(x for x in remaining if x[idx]==1))
        if left==right:return left
        key=(idx,left,right)
        if key not in self.unique:
            self.unique[key]=self.next_id
            self.nodes[self.next_id]=key
            self.next_id+=1
        return self.unique[key]

    def contains(self, assignment):
        node=self.root
        while node>=2:
            index,lo,hi=self.nodes[node]
            node=hi if assignment[index] else lo
        return node==1

    def as_dict(self):
        return {'order':list(range(self.n)),'root':self.root,
                'terminals':{'0':False,'1':True},
                'nodes':{str(k):{'atom':v[0],'low':v[1],'high':v[2]} for k,v in sorted(self.nodes.items())}}


def coordinate_hull(versions):
    # Exact coordinate-wise projection product (not a property of all SQL schemas).
    n=len(next(iter(versions)))
    options=[sorted({v[i] for v in versions}) for i in range(n)]
    return set(product(*options))


def query_family(n):
    queries=[{'type':'all_equal'}]
    queries += [{'type':'exactly','k':k} for k in range(n+1)]
    queries += [{'type':'at_least','k':k} for k in range(1,n+1)]
    queries += [{'type':'equal','i':i,'j':j} for i,j in combinations(range(n),2)]
    queries += [{'type':'implies','i':i,'j':j} for i in range(n) for j in range(n) if i != j]
    queries += [{'type':'atom','i':i} for i in range(n)]
    queries += [{'type':'and','i':i,'j':j} for i,j in combinations(range(n),2)]
    queries += [{'type':'xor','i':i,'j':j} for i,j in combinations(range(n),2)]
    return queries


def evaluates(q,v):
    t=q['type']
    if t=='all_equal':return len(set(v))==1
    if t=='exactly':return sum(v)==q['k']
    if t=='at_least':return sum(v)>=q['k']
    if t=='equal':return v[q['i']]==v[q['j']]
    if t=='implies':return v[q['i']]==0 or v[q['j']]==1
    if t=='atom':return bool(v[q['i']])
    if t=='and':return v[q['i']]==1 and v[q['j']]==1
    if t=='xor':return v[q['i']]!=v[q['j']]
    raise ValueError('Unsupported safe query '+str(t))


def status(q, worlds):
    flags={evaluates(q,v) for v in worlds}
    return 'YES' if flags=={True} else 'NO' if flags=={False} else 'UNKNOWN'


def counterexample(q, coherent, hull):
    expected=status(q,coherent)
    approximate=status(q,hull)
    if expected==approximate:return None
    # Witness that an answer available under source-coherent versions is lost
    # when projecting into separate scalar cell marginals.
    extra=sorted(hull-set(coherent))
    if expected=='YES': witness=next((v for v in extra if not evaluates(q,v)),None)
    elif expected=='NO': witness=next((v for v in extra if evaluates(q,v)),None)
    else: witness=None
    if witness is None:raise AssertionError('Non-monotone relaxation response')
    return {'query':q,'coherent_answer':expected,'marginal_answer':approximate,
            'marginal_counterexample':list(witness),
            'supported_vectors':len(coherent)}


def sqlite_source_and_hull(case):
    n=len(case['labels'])
    coldef=', '.join('a%d INTEGER NOT NULL'%i for i in range(n))
    con=sqlite3.connect(':memory:')
    con.execute('CREATE TABLE source_versions (version_id TEXT PRIMARY KEY, '+coldef+')')
    con.executemany('INSERT INTO source_versions VALUES ('+','.join(['?']*(n+1))+')',
                    [[v['id'],*v['values']] for v in case['versions']])
    real={tuple(row) for row in con.execute('SELECT '+','.join('a%d'%i for i in range(n))+' FROM source_versions')}
    # Truly independent SQL construction of the scalar-marginal product.
    aliases=['t%d'%i for i in range(n)]
    parts=['(SELECT DISTINCT a%d AS val FROM source_versions) AS %s'%(i, aliases[i]) for i in range(n)]
    statement='SELECT '+','.join(alias+'.val' for alias in aliases)+' FROM '+' CROSS JOIN '.join(parts)
    hull={tuple(row) for row in con.execute(statement)}
    con.close()
    return real,hull


def result_for(case):
    vectors=validate_case(case)
    F=set(vectors)
    H=coordinate_hull(F)
    bdd=ROBDD(len(case['labels']),F)
    U=all_vectors(len(case['labels']))
    assert {v for v in U if bdd.contains(v)}==F
    sqlF,sqlH=sqlite_source_and_hull(case)
    assert F==sqlF and H==sqlH
    queries=query_family(len(case['labels']))
    certs=[]
    for q in queries:
        c=counterexample(q,F,H)
        if c:certs.append(c)
        # Coherent-world answers must never become opposite definite answers.
        a,b=status(q,F),status(q,H)
        assert a==b or (a in ('YES','NO') and b=='UNKNOWN')
    provenance={''.join(map(str,v)):sorted(version['id'] for version in case['versions'] if tuple(version['values'])==v) for v in F}
    return {'id':case['id'],'source_url':case.get('official_url'),'labels':case['labels'],
            'version_rows':len(vectors),'distinct_source_vectors':len(F),
            'marginal_vectors':len(H),'spurious_mixed_vectors':len(H-F),
            'source_versions_by_vector':provenance,'bdd':bdd.as_dict(),
            'queries_executed':len(queries),'answers_lost_under_scalar_projection':len(certs),
            'query_certificates':certs,'sql_oracle_equal':True,'exhaustive_membership_equal':True,
            'relation_sha256':hashlib.sha256(json.dumps(sorted(F),separators=(',',':')).encode()).hexdigest()}


def run(source,outdir):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    data=json.loads(Path(source).read_text(encoding='utf-8'))
    if not isinstance(data.get('cases'),list):raise ValueError('Missing cases array')
    results=[]
    for case in data['cases']:
        r=result_for(case)
        results.append(r)
        (outdir/(case['id']+'_CERTIFICATE.json')).write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    summary={'cases':len(results), 'distinct_source_vectors':sum(r['distinct_source_vectors'] for r in results),
             'marginal_vectors':sum(r['marginal_vectors'] for r in results),
             'spurious_mixed_vectors':sum(r['spurious_mixed_vectors'] for r in results),
             'questions_checked':sum(r['queries_executed'] for r in results),
             'answers_lost_by_projection':sum(r['answers_lost_under_scalar_projection'] for r in results),
             'validated_with_sql_and_bdd':True,
             'by_case':[{'id':r['id'],'recorded':r['distinct_source_vectors'],'product':r['marginal_vectors'],
                         'query_count':r['queries_executed'],'lost_answer_count':r['answers_lost_under_scalar_projection'],
                         'decision_nodes':len(r['bdd']['nodes'])} for r in results]}
    (outdir/'SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    return summary


if __name__=='__main__':
    import argparse
    cli=argparse.ArgumentParser(description='Offline evidence-preserving version checker')
    cli.add_argument('--input',required=True,help='JSON with cases/labels/versions/official_url')
    cli.add_argument('--output',required=True)
    args=cli.parse_args()
    run(args.input,args.output)
