#!/usr/bin/env python3
"""Deterministic one-command build of counterexample and provenance certificates."""
from pathlib import Path
from version_preservation import run
import unittest
import sys
root=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.discover(str(root),pattern='test_model.py')
result=unittest.TextTestRunner(verbosity=1).run(suite)
if not result.wasSuccessful():sys.exit(1)
run(root/'source_vectors.json',root/'proofs')
print('PASS exhaustive relational tests, independent SQLite cross-checks, and query certificates')
