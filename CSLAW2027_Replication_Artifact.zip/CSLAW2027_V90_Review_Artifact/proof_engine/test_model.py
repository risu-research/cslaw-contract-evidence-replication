#!/usr/bin/env python3
"""Exhaustive and metamorphic validation of a generic finite version model."""
import json
from itertools import product
from pathlib import Path
import random
import sqlite3
import unittest
from version_preservation import ROBDD, coordinate_hull, query_family, evaluates, status, result_for, all_vectors, validate_case

class ModelTests(unittest.TestCase):
    def test_exhaustive_three_variable_relations(self):
        # Every Boolean relation on three atoms, including the empty/full relation.
        U=all_vectors(3)
        for mask in range(256):
            F={v for i,v in enumerate(U) if (mask>>i)&1}
            d=ROBDD(3,F)
            self.assertEqual(F,{v for v in U if d.contains(v)})
            self.assertEqual(d.as_dict()['nodes'],ROBDD(3, list(reversed(sorted(F)))).as_dict()['nodes'])
            if F:
                H=coordinate_hull(F)
                self.assertTrue(F<=H)
                for q in query_family(3):
                    a,b=status(q,F),status(q,H)
                    self.assertTrue(a==b or (a in ('YES','NO') and b=='UNKNOWN'))

    def test_randomized_larger_relations(self):
        rng=random.Random(20261020)
        for n in (4,5,6,7,8):
            U=all_vectors(n)
            for _ in range(35):
                F=set(rng.sample(U,rng.randint(1,min(24,len(U)))))
                b=ROBDD(n,F)
                self.assertEqual(F,{v for v in U if b.contains(v)})
                H=coordinate_hull(F)
                for q in query_family(n):
                    a,rel=status(q,F),status(q,H)
                    self.assertTrue(a==rel or (a in ('YES','NO') and rel=='UNKNOWN'))

    def test_unrepresentable_pairwise_control(self):
        # Even parity has complete pairwise marginal projections yet a real joint constraint.
        U=all_vectors(3)
        F={x for x in U if sum(x)%2==0}
        self.assertEqual(len(F),4)
        self.assertEqual(len(coordinate_hull(F)),8)
        for i in range(3):
            for j in range(i+1,3):
                self.assertEqual({(x[i],x[j]) for x in F},set(product((0,1),repeat=2)))
        b=ROBDD(3,F)
        self.assertEqual({x for x in U if b.contains(x)},F)

    def test_input_validation(self):
        a={'id':'x','labels':['a','b'],'versions':[{'id':'v','values':[0,1]}]}
        self.assertEqual(validate_case(a),((0,1),))
        for corrupt in [dict(a,labels=['a','a']),dict(a,versions=[{'id':'v','values':[0,2]}]),dict(a,versions=[{'id':'v','values':[False,1]}]),dict(a,versions=[])]:
            with self.assertRaises(ValueError):validate_case(corrupt)

    def test_provenance_and_permutation(self):
        path=Path(__file__).resolve().parent/'source_vectors.json'
        cases=json.loads(path.read_text())['cases']
        for c in cases:
            r=result_for(c)
            self.assertTrue(r['sql_oracle_equal'])
            self.assertEqual(sum(map(len,r['source_versions_by_vector'].values())),len(c['versions']))
            swap=list(range(len(c['labels'])))[::-1]
            changed={**c,'labels':[c['labels'][i] for i in swap],
                     'versions':[{**v,'values':[v['values'][i] for i in swap]} for v in c['versions']]}
            z=result_for(changed)
            self.assertEqual((r['distinct_source_vectors'],r['marginal_vectors'],r['spurious_mixed_vectors']),
                             (z['distinct_source_vectors'],z['marginal_vectors'],z['spurious_mixed_vectors']))
            # Adding a separately documented version with the same values must not change semantic membership.
            extra={**c,'versions':c['versions']+[{'id':'test_duplicate_version','values':c['versions'][0]['values'][:]}]}
            x=result_for(extra)
            self.assertEqual(x['distinct_source_vectors'],r['distinct_source_vectors'])
            self.assertEqual(x['source_versions_by_vector'][''.join(map(str,c['versions'][0]['values']))].__len__(),
                             len(r['source_versions_by_vector'][''.join(map(str,c['versions'][0]['values']))])+1)

if __name__=='__main__':unittest.main()
