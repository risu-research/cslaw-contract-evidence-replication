# Data and evidence

## Procurement profiles and contract schedules

The comparison uses 56 NASPO supplier profiles and ten role-category fields per supplier. Source-coded observations are preserved in the dataset. The five RADcube VAR entries retain their disputed status; the other 555 fields include 312 matching positive values, 233 matching negative values, one web-only value, and nine contract-only values. The ten settled differences involve five suppliers. `REVIEWER_EVIDENCE_MAP.md` identifies their public source pages.

The seven-category lookup result is calculated from the recorded supplier-profile fields and compared with the contract-schedule fields. It reports differences in this defined reconstruction.

## Document versions and dated evidence

The RADcube case compares two Attachment B texts in the inspected Utah packet. Their five VAR fields form two complete recorded vectors, `00000` and `11111`. Taking the five fields independently produces 32 combinations, including 30 that occur in neither inspected schedule. The computation does not assign contractual priority to either schedule.

The dated evidence check covers 18 specified query-date pairs and finds six typed document matches. Supporting source records and the evidence grades used for those matches are preserved in the included ledgers.

## Reproduction

The scripts check tabular counts, version relations, query outcomes, SQL joins, and source-to-result consistency. The model's larger query panels and synthetic controls test its behavior on specified finite inputs. Document links and PDF page locations make the underlying records available for direct inspection. The package includes locally executable code and data; public contracts remain at their original source URLs.
