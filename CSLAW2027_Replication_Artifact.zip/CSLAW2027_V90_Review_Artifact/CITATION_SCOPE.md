# Reading the evidence and the model

The supplier classifications are transcriptions of public procurement profiles and contract records. `REVIEWER_EVIDENCE_MAP.md` supplies the profile URLs and contract-page locators for the ten settled differences.

For each contract lineage, a **version vector** records whether specified categories or clauses occur in one identified document version. The **version relation** contains the complete recorded vectors. Its **marginal product** combines observed values attribute by attribute, without retaining which values occurred together.

A **query certificate** identifies a question with a definite answer over the recorded version relation and a different possible answer over its marginal product. An explicit added vector demonstrates the difference. The certificate verifier checks the result separately from the program that generated it.

The model evaluates the information preserved by these representations. The documentary and legal analysis in the paper addresses which instruments may govern a particular transaction.
