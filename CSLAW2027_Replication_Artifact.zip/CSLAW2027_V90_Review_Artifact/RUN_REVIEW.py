#!/usr/bin/env python3
"""CSLAW reviewer entry point: no external libraries, no network."""
import argparse, pathlib, subprocess, sys, json, time
root=pathlib.Path(__file__).resolve().parent
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--full',action='store_true',help='Also execute additional archived research diagnostics')
args=cli.parse_args()
steps=[('model_property_tests_and_certificates',[sys.executable,'proof_engine/run_proof_suite.py']),
       ('independent_certificate_verifier',[sys.executable,'proof_engine/verify_certificates.py']),
       ('original_experiment_checks',[sys.executable,'RUN_CHECKS.py']+(['--extended'] if args.full else []))]
for name,command in steps:
    print('RUN',name,flush=True)
    cp=subprocess.run(command,cwd=root,check=False)
    if cp.returncode:raise SystemExit('FAIL '+name+' exit '+str(cp.returncode))
    print('PASS',name,flush=True)
print('PASS completed reviewer workflow. See proof_engine/proofs/ and verification_output/.',flush=True)
