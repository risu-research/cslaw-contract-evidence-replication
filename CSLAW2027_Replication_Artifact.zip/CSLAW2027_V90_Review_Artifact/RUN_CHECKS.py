#!/usr/bin/env python3
"""Run V90 reviewer checks against frozen prior-version experiment inputs (stdlib)."""
import argparse, hashlib, json, pathlib, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
ex=root/'replication'/'Reviewer_Replication_V71'/'experiments'
output=root/'verification_output'
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--extended',action='store_true',help='Run additional tests/diagnostics')
args=p.parse_args()
assert sys.version_info>=(3,10),'Python 3.10+ needed'
expected=json.loads((root/'FROZEN_INPUT_SHA256.json').read_text())
for rel,digest in expected.items():
    found=hashlib.sha256((root/rel).read_bytes()).hexdigest()
    if found!=digest: raise SystemExit('FAIL: frozen input changed: '+rel)
print(f'PASS {len(expected)} frozen input SHA256 checks',flush=True)
checks=[
 ('census_560',ex, ['V61_verify_census.py']),
 ('source_discrepancies_10',ex/'V57',['verify_ten.py']),
 ('claim_statuses',ex/'V55',['claim_status_audit.py']),
 ('evidence_grade_18',ex/'V58',['run_v58_evidence_gates.py']),
 ('radcube_joint_states',ex/'V65',['source_coherence.py']),
 ('radcube_unit_tests',ex/'V65',['-m','unittest','-q','test_source_coherence.py']),
 ('external_version_sets',ex/'V66',['cross_contract_versions.py']),
 ('external_version_tests',ex/'V66',['-m','unittest','-q','test_cross_contract_versions.py']),
 ('minimum_constraints',ex/'V70',['source_constraint_audit.py']),
 ('constraint_unit_tests',ex/'V70',['-m','unittest','-q','test_constraint_audit.py']),
 ('necessity_witnesses',ex/'V70',['create_rule_witnesses.py']),
 ('source_vector_alignment',ex/'V70',['verify_prior_version_vectors.py']),
 ('category_lookup_two_worlds',ex/'V71',['run_query_impact.py']),
]
if args.extended:
 checks += [
 ('contract_collision_unit_tests',ex/'V28',['-m','unittest','-q','tests/test_determinacy.py']),
 ('typed_join_unit_tests',ex/'V33',['-m','unittest','-q','tests/test_scope_safe.py']),
 ('stress_panel_66',ex/'V35',['src/transfer_audit.py']),
 ('stress_panel_tests',ex/'V35',['-m','unittest','-q','tests/test_transfer.py']),
 ('judicial_update',ex/'V68',['run_judgment_update.py']),
 ('judicial_compound_sql',ex/'V68',['compound_queries.py']),
 ('judicial_update_unit_tests',ex/'V68',['-m','unittest','-q','test_judgment_update.py']),
 ('MRO_independent_counterpart',root/'replication'/'INDEPENDENT_MRO_V72',['run_independent_mro_audit.py']),
 ]
output.mkdir(exist_ok=True)
results=[]
for name,cwd,arguments in checks:
    t=time.perf_counter()
    cmd=[sys.executable,*arguments]
    cp=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True)
    path=output/(name+'.log')
    path.write_text('COMMAND '+repr(cmd)+'\n'+'CWD '+str(cwd.relative_to(root))+'\n'+cp.stdout+'\nSTDERR\n'+cp.stderr)
    row={'name':name,'status':'PASS' if cp.returncode==0 else 'FAIL','returncode':cp.returncode,
         'duration_sec':round(time.perf_counter()-t,3),'log':str(path.relative_to(root))}
    results.append(row)
    print(row['status'],name,flush=True)
    if cp.returncode:
        (output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
        raise SystemExit('FAIL '+name+': see '+str(path))
# defend the paper-aligned headline counts in freshly recomputed outputs
q=json.loads((ex/'V71/QUERY_IMPACT_RESULTS.json').read_text())
a=json.loads((ex/'V70/results.json').read_text())
c=json.loads((ex/'V61_census_summary.json').read_text())
e=json.loads((ex/'V58/v58_evidence_tiers_summary.json').read_text())
v=json.loads((ex/'V65/results.json').read_text())
assert (q['supplier_category_cells'],q['categories_with_guaranteed_member_difference'],q['guaranteed_missing_listings'],q['guaranteed_extra_listings'])==(560,7,9,1)
assert q['world_dependent_total_edit_range']==[10,15] and q['web_total_positives']==318
assert a['totals']['contract_lineages']==4 and a['totals']['documented_vectors']==9 and a['totals']['independent_vectors']==48 and a['totals']['spurious_vectors']==39 and a['totals']['minimum_primitives_total']==8
assert (c['suppliers_total'],c['radcube_review_cells'])==(56,5)
assert (e['frozen_evaluation_queries'],e['dated_typed_matches'],e['matches_with_signature_pages_inspected_in_prior_work'],e['matches_based_on_indexed_text_only'])==(18,6,4,2)
assert (v['source_coherent_assignment_count'],v['independent_assignment_count'],v['spurious_mixed_assignments'])==(2,32,30)
results.append({'name':'V90_manuscript_numbers','status':'PASS','returncode':0,'log':'computed JSON files'})
(output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
(output/'summary.txt').write_text('V90 conditional numerical reproduction: ALL CHECKS PASSED\n'+'\n'.join(x['name']+': '+x['status'] for x in results)+'\n')
print('PASS V90 manuscript alignment. All tests passed. See verification_output/summary.json',flush=True)
