# Results and independently checkable witnesses

| Evidence / calculation | Paper-aligned outcome | Executable route |
|---|---:|---|
| Fixed procurement census | 56 suppliers × 10 categories = **560 comparisons** | `RUN_CHECKS.py` / `V61_verify_census.py` |
| Settled supplier/category profile differences | **10**, involving five suppliers | `V57/verify_ten.py`, `REVIEWER_EVIDENCE_MAP.md` |
| Category-level reconstructed lookup differences | **7 of 10 categories** | `V71/run_query_impact.py` with SQLite cross-check |
| Utah RADcube documented readings | **2** jointly coherent vectors vs **32** coordinate-product vectors | `proof_engine/run_proof_suite.py` |
| Across four independently sourced contract lineages | **9** documented vectors, **48** marginal-product vectors, **39** extra mixtures | `V70/source_constraint_audit.py` and `proof_engine/` |
| Equality/implication constraint representation | **8** selected primitive constraints across four lineages | `V70/source_constraint_audit.py` exhaustive minimal-basis check |
| Typed query/date document connections | **18** tested with evidence status | `V58/run_v58_evidence_gates.py` |
| Generic version-coherent query evaluator | **119** generated test queries; **64** lost determinate answers with exact counterexamples | `proof_engine/proofs/*CERTIFICATE.json` |
| General-purpose model checks | **all 256** three-attribute relations, plus seeded larger relations | `proof_engine/test_model.py` |

**Interpretation.** The query tests are a generated diagnostic suite over the
four documented version sets, not new contracts or independently observed
purchases. Each certificate preserves the source-version identifiers and
presents an explicit coordinate-product assignment that alters the query
answer. `proof_engine/verify_certificates.py` checks each certificate using an
independent implementation; SQLite separately checks relational membership.

## Concrete examples worth inspecting

- **RADcube** — all five VAR category statuses agree within each inspected
  Attachment B schedule. Treating the five scalar answers independently
  admits 30 additional mixed patterns. The query *"are all five statuses
  equal?"* moves from definite YES to UNKNOWN under the marginal product.
- **Idaho–Allsteel** — the recorded three successive PA texts produce
  `000`, `110`, `111`, whereas three independent category fields admit all
  eight Boolean patterns. This result describes version-text preservation,
  without changing the documented timeline or amendment priority.
- **Washington–MillerKnoll and Washington–Landscape Structures** — each
  signed amendment inserts two named clauses together. The version-coherent
  relation preserves that joint occurrence; independent fields do not.
- **Expressiveness control** — an even-parity relation is reproduced exactly
  by the decision-diagram model, although no pairwise-equality/implication
  conjunction represents it. This is a synthetic functional validation, not
  a finding about a fifth contract.
