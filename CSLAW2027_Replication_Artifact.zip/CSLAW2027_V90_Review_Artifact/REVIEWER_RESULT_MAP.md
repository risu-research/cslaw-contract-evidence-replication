# V90 result-to-code map

| V90 claim | Primary files | Verified output or check |
|---|---|---|
| 56 profiles × 10 categories = 560 | `replication/Reviewer_Replication_V71/experiments/V55/source_input_560.csv` | `V61_verify_census.py`, `V57/verify_ten.py` |
| 10 settled profile/schedule differences, five suppliers, 9 source-only / 1 web-only | `V57/ten_discrepancies_rechecked.csv` and frozen 560 ledger | `V57/verify_ten.py`; `V71/run_query_impact.py` |
| RADcube joint 2 vs 32; 30 unsupported mixed patterns | `V65/source_coherence.py`, `V70/input_version_vectors.json` | `V65` tests and `V70/source_constraint_audit.py` |
| Four contract lineages; 9 recorded vectors, 48 independent combinations, 39 excess, 8 constraints | `V70/input_version_vectors.json` | `V70/source_constraint_audit.py` + `test_constraint_audit.py` + `create_rule_witnesses.py` |
| 7 of 10 category supplier-set disagreements; 10–15 differences across the two RADcube readings | `V71/run_query_impact.py` | `V71/QUERY_IMPACT_RESULTS.json` and SQLite cross-check |
| 18 dated linkage queries; six typed matches, four signature-page-grade and two indexed-only | `V58/V35_BENCHMARK_FROZEN.json`, `V58/V35_SOURCE_LEDGER_FROZEN.json` | `V58/run_v58_evidence_gates.py` |
| Clause-grounded projection collisions and negative-evidence gates | `V28/src/claim_determinacy.py`, `V55/claim_status_audit.py` | V28 unit tests (extended), V55 checks |
| Alternative signed source-version lineages | `V66/official_contract_worlds.json` | `V66/cross_contract_versions.py` and tests |
| Historical 66-question constructed documentary stress panel | `V35/src/transfer_audit.py` | V35 tests (extended) |

Paths without `replication/Reviewer_Replication_V71/experiments/` prefixes
refer to locations beneath that directory. `RUN_CHECKS.py` drives the main checks.
The paper is the normative description; files with older V-numbers are archived
experiment provenance, not older paper submissions.
